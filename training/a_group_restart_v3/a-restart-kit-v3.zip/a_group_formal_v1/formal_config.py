"""Formal training overrides and numeric-only C/formal configuration comparison."""
from __future__ import annotations

import argparse
from collections.abc import Mapping
from copy import deepcopy
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'a_group_c_v1'))
import c_config as c

TOTAL = 100
SAVE = 5
MILESTONES = (25, 50, 75, 100)
SPACE_FLOOR = 150_000_000_000
PROFILE = os.environ.get('EDU_FORMAL_PROFILE', 'four')
if PROFILE not in ('four', 'six_v2', 'restart_v3'):
    raise ValueError('unsupported formal training profile')
RESTART = PROFILE == 'restart_v3'
SPEED = PROFILE in ('six_v2', 'restart_v3')
OPTIMIZER_OFFLOAD = os.environ.get('EDU_RESTART_OPTIMIZER_OFFLOAD', 'false') if RESTART else 'true'
if OPTIMIZER_OFFLOAD not in ('true', 'false'):
    raise ValueError('unsupported optimizer placement')
OPTIMIZER_OFFLOAD = OPTIMIZER_OFFLOAD == 'true'
TUTOR_COUNT = 4 if SPEED else 2
ROLLOUT_TP = 1 if SPEED else 2
SERIES_NAMES = {'four': 'formal_a_v1', 'six_v2': 'formal_a_speed_v2', 'restart_v3': 'formal_a_restart_v3'}
SERIES = c.ROOT / SERIES_NAMES[PROFILE]
FAST_PYTHON = c.ROOT / 'envs' / 'env-a100-fast-v2' / 'bin' / 'python'
KERNEL_MODE = os.environ.get('EDU_FORMAL_KERNEL', 'baseline') if SPEED else 'baseline'
if KERNEL_MODE not in ('baseline', 'fast'):
    raise ValueError('unsupported formal kernel profile')
TRAINER_PYTHON = FAST_PYTHON if KERNEL_MODE == 'fast' else c.PYTHON
C_WORK = c.ROOT / 'pilots' / 'c_paper_v1'
C_LOAD = ['model', 'extra']
FULL_LOAD = ['model', 'optimizer', 'extra']
CKPT = SERIES / 'checkpoints'


def overrides(work, raytmp, student_name, interaction, step=None, *, speed=SPEED, restart=RESTART):
    values = c.training_overrides(work, raytmp, student_name, interaction)
    profile = 'restart_v3' if restart else 'six_v2' if speed else 'four'
    folder = c.ROOT / SERIES_NAMES[profile] / 'checkpoints'
    replacement = {
        'trainer.total_training_steps': str(TOTAL),
        'trainer.resume_mode': 'disable' if step is None else 'resume_path',
    }
    if speed:
        replacement.update({'trainer.n_gpus_per_node': '4',
                            'actor_rollout_ref.actor.fsdp_config.fsdp_size': '4'})
    values = [f'{key}={replacement[key]}' if key in replacement else setting
              for setting in values for key in [setting.partition('=')[0]]]
    values.extend([
        f'trainer.save_freq={SAVE}',
        'trainer.max_actor_ckpt_to_keep=null',
        'trainer.del_local_ckpt_after_load=false',
        'actor_rollout_ref.actor.checkpoint.load_contents=[model,optimizer,extra]',
        f'trainer.default_local_dir={folder}',
    ])
    if speed:
        values.extend([
            'actor_rollout_ref.rollout.tensor_model_parallel_size=1',
            '+ray_kwargs.ray_init.runtime_env.worker_process_setup_hook=queue_metrics.install',
            f'+ray_kwargs.ray_init.runtime_env.env_vars.EDU_QUEUE_METRICS_DIR={work}/queue-metrics',
        ])
    if restart:
        values.extend([
            'actor_rollout_ref.actor.fsdp_config.param_offload=false',
            f'actor_rollout_ref.actor.fsdp_config.optimizer_offload={str(OPTIMIZER_OFFLOAD).lower()}',
        ])
    if step is not None:
        values.append(f'trainer.resume_from_path={folder}/global_step_{step}')
    return values


def pin_composed(config, work, student_name, interaction, step=None):
    trainer = config['trainer']
    actor_rollout = config['actor_rollout_ref']
    actor_checkpoint = actor_rollout['actor']['checkpoint']
    c._expect(trainer, {
        'total_training_steps': TOTAL, 'save_freq': SAVE, 'test_freq': 25,
        'max_actor_ckpt_to_keep': None, 'del_local_ckpt_after_load': False,
        'resume_mode': 'disable' if step is None else 'resume_path',
        'resume_from_path': None if step is None else str(CKPT / f'global_step_{step}'),
        'default_local_dir': str(CKPT), 'n_gpus_per_node': TUTOR_COUNT,
    })
    c._expect(actor_rollout['actor']['fsdp_config'], {'fsdp_size': TUTOR_COUNT, 'optimizer_offload': OPTIMIZER_OFFLOAD})
    if RESTART:
        c._expect(actor_rollout['actor']['fsdp_config'], {'param_offload': False})
        c._expect(actor_rollout['model'], {'enable_gradient_checkpointing': True, 'use_remove_padding': True})
    c._expect(actor_rollout['actor'], {'ppo_micro_batch_size_per_gpu': 1, 'use_dynamic_bsz': False})
    c._expect(actor_rollout['rollout'], {'tensor_model_parallel_size': ROLLOUT_TP,
                 'data_parallel_size': 1, 'pipeline_model_parallel_size': 1})
    if SPEED:
        ray_env = config['ray_kwargs']['ray_init']['runtime_env']
        c._expect(ray_env, {'worker_process_setup_hook': 'queue_metrics.install'})
        c._expect(ray_env['env_vars'], {'EDU_QUEUE_METRICS_DIR': str(work / 'queue-metrics')})
    c._expect(actor_checkpoint, {'load_contents': FULL_LOAD, 'save_contents': FULL_LOAD})
    if actor_checkpoint.get('async_save') or config['trainer'].get('default_hdfs_dir') is not None:
        raise ValueError('formal checkpoint requires synchronous local save')
    normal = deepcopy(config)
    normal['trainer'].update(total_training_steps=1, save_freq=25, max_actor_ckpt_to_keep=5,
                             resume_mode='disable', default_local_dir=str(work / 'verl_ckpts' / c.EXPERIMENT),
                             n_gpus_per_node=2)
    normal['actor_rollout_ref']['actor']['fsdp_config']['fsdp_size'] = 2
    normal['actor_rollout_ref']['rollout']['tensor_model_parallel_size'] = 2
    c.check_composed(normal, work, student_name, interaction)


def preflight_env(work):
    return dict(os.environ, CUDA_VISIBLE_DEVICES='', CUDA_DEVICE_ORDER='PCI_BUS_ID',
                PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(c.REPO), WORK_DIR=str(work),
                EDUARDO_RECIPE_DIR=str(c.REPO / 'eduardo'), MODEL_PATH=str(c.TUTOR),
                EXPERIMENT=c.EXPERIMENT, USER=os.environ.get('USER') or 'root',
                SERVING_API_KEY='placeholder', STUDENT_API_BASE=c.STUDENT_API_BASE,
                JUDGE_API_BASE=c.JUDGE_API_BASE, WANDB_MODE='disabled',
                HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
                RAY_USAGE_STATS_ENABLED='0')


def compose(entry, work, settings, *, check_only=False):
    args = [str(TRAINER_PYTHON), '-B', str(entry)]
    if check_only:
        args.append('--check-only')
    args.extend(['--config-path', str(c.REPO / 'eduardo/configs'), '--config-name', 'eduardo_base'])
    args.extend(settings)
    if not check_only:
        args.extend(['--cfg', 'job', '--resolve'])
    else:
        args.extend([f'hydra.run.dir={work}/hydra-preflight', 'hydra.output_subdir=null'])
    proc = subprocess.run(args, env=preflight_env(work), capture_output=True, text=True, timeout=180)
    if proc.returncode:
        raise ValueError('Hydra 预检失败')
    if check_only:
        if 'FORMAL_PRECHECK_OK' not in proc.stdout.splitlines():
            raise ValueError('正式预检缺少确认标记')
        return
    from omegaconf import OmegaConf
    return OmegaConf.to_container(OmegaConf.create(proc.stdout))


def flatten(value, path=''):
    if isinstance(value, Mapping) and value:
        for key, item in value.items():
            yield from flatten(item, f'{path}.{key}' if path else str(key))
    else:
        yield path, value


def diff(left, right):
    first, second = dict(flatten(left)), dict(flatten(right))
    return [(key, first.get(key), second.get(key)) for key in sorted(first.keys() | second.keys())
            if key not in first or key not in second or first[key] != second[key]]


DISPLAY = {
    'trainer.total_training_steps': ('1', '100', '总步数'),
    'trainer.save_freq': ('25（C 最后一步写盘）', '5', '保存间隔'),
    'trainer.max_actor_ckpt_to_keep': ('5', '交给正式控制器保留 2 个', '完整检查点保留'),
    'actor_rollout_ref.actor.checkpoint.load_contents': ('model, extra', 'model, optimizer, extra', '恢复内容'),
    'trainer.del_local_ckpt_after_load': ('默认', 'false', '恢复后保留源检查点'),
}
OPERATIONAL = {'vars.work_dir', 'trainer.default_local_dir', 'ray_kwargs.ray_init._temp_dir',
               'actor_rollout_ref.rollout.multi_turn.interaction_config_path'}
PUBLIC_KEYS = set(DISPLAY) | OPERATIONAL


def archived_config(fallback):
    """Hydra saved the actual C input before veRL's native reward migration."""
    from unittest.mock import patch
    from omegaconf import OmegaConf

    paths = list((C_WORK / 'outputs').glob('*/*/.hydra/config.yaml'))
    path = C_WORK / '.hydra' / 'config.yaml'
    if path.is_file():
        paths.append(path)
    if len(paths) > 1:
        raise ValueError('C Hydra 存档不唯一')
    if not paths:
        return fallback, '冻结启动器重建；未找到实际 Hydra 存档'
    with patch.dict(os.environ, preflight_env(C_WORK)):
        saved = OmegaConf.to_container(OmegaConf.load(paths[0]), resolve=True)
    return saved, '实际 C Hydra 存档'


def compare():
    import yaml

    student = 'Llama-3.1-8B-Instruct-' + (os.environ.get('USER') or 'root')
    c_interaction = C_WORK / 'interaction_b.yaml'
    c_ray = Path((C_WORK / 'ray_tmp_path.txt').read_text().strip())
    formal_work = c.ROOT / 'pilots' / 'a_formal_v1'
    formal_interaction = formal_work / 'interaction_b.yaml'
    original = compose(HERE.parent / 'a_group_c_v1' / 'c_trainer_entry.py', C_WORK,
                       c.training_overrides(C_WORK, c_ray, student, c_interaction))
    actual, evidence = archived_config(original)
    print('C 配置证据', evidence)
    c.check_composed(actual, C_WORK, student, c_interaction)
    # Configuration objects are compared locally. Print only approved field labels and values.
    candidate = compose(HERE / 'formal_trainer.py', formal_work,
                        overrides(formal_work, c.ROOT / 'r000000', student, formal_interaction))
    pin_composed(candidate, formal_work, student, formal_interaction)
    if actual['actor_rollout_ref']['actor']['checkpoint']['load_contents'] != C_LOAD:
        raise ValueError('C 恢复字段与已冻结配方不同')
    source = c.REPO / 'eduardo' / 'eduardo_interaction_config.yaml'
    expected = yaml.safe_load(source.read_text())
    expected['interaction'][0]['config'].update(student_concurrency=16, student_model=student,
                                               student_api_base=c.STUDENT_API_BASE)
    if yaml.safe_load(c_interaction.read_text()) != expected:
        raise ValueError('C 学生交互配置与正式配方不同')
    rows = diff(actual, candidate)
    print('| 有变化的字段 | C | 正式 |')
    print('|---|---|---|')
    for key, _, _ in rows:
        if key in DISPLAY:
            before, after, _ = DISPLAY[key]
            print(f'| {key} | {before} | {after} |')
        elif key in OPERATIONAL:
            print(f'| {key} | C 工作区 | 正式工作区 |')
    unexpected = sum(key not in PUBLIC_KEYS for key, _, _ in rows)
    print('其他差异字段数', unexpected)
    if unexpected:
        # Only field counts are exported for non-allowlisted fields.
        raise ValueError('存在已知清单之外的配置差异')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--compare', action='store_true', required=True)
    parser.parse_args()
    try:
        compare()
        return 0
    except Exception as exc:
        print('配置核对未完成', type(exc).__name__)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
