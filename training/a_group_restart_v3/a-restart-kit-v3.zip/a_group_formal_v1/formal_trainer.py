"""Use native veRL training with monitors scoped to its synchronous batch boundaries."""
from __future__ import annotations

from functools import partial
import math
from numbers import Real
import os
from pathlib import Path
import shutil
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'a_group_c_v1'))
sys.path.insert(0, str(HERE.parent / 'a_group_b_native_v1'))
DIAGNOSTICS = HERE.parent / 'deep_stage0'
if not DIAGNOSTICS.is_dir():
    DIAGNOSTICS = HERE.parent / 'a_group_diagnostics' / 'deep_stage0'
sys.path.insert(0, str(DIAGNOSTICS))

import formal_config as config
from c_trainer_entry import keep_teacher_budgets
from checkpoints import CheckpointFailure, Store, cpu_merge, position, write_json
from monitor import MonitoringFailure, RunMonitor
from prior_numbers import ACTOR_KEYS, PROBABILITY_KEYS, TIMING_KEYS
from trajectories import IdentityFailure, Rows, expected

if config.SPEED:
    sys.path.insert(0, str(HERE.parent / 'a_group_speed_v2'))
    import queue_metrics
    from speed_checks import SpeedFailure, assess_first_step, baseline_row
if config.RESTART:
    sys.path.insert(0, str(HERE.parent / 'a_group_restart_v3'))
    from step_review import peak_window, restart_comparison


def numeric_metrics(data):
    return {key: float(data[key]) for key in (*ACTOR_KEYS, *PROBABILITY_KEYS, *TIMING_KEYS)
            if isinstance(data.get(key), Real) and math.isfinite(data[key])}


def bound_trainer(native):
    """Leave fit, all reward paths, and optimizer logic with native veRL."""
    class ObservedTrainer(native):
        def fit(self):
            import verl.utils.tracking as tracking
            self.formal_work = Path(os.environ['WORK_DIR'])
            self.formal_monitor = RunMonitor(self.formal_work, Path(os.environ['RAY_TMPDIR']))
            self.formal_store = Store()
            self.formal_rows = Rows(self.formal_work)
            self.formal_validation = None
            self.formal_train = None
            self.formal_saved = None
            self.formal_strip = None
            self.formal_tokenizer = None
            self.formal_start = int(os.environ['FORMAL_START'])
            if config.SPEED:
                count = len(self.async_rollout_manager.rollout_replicas)
                write_json(self.formal_work / 'rollout-layout.json',
                           {'replicas': count, 'tensor_parallel': config.ROLLOUT_TP})
                if count != config.TUTOR_COUNT:
                    error = '六卡候选未建立四个独立生成副本'
                    write_json(self.formal_work / 'failure.json', {'reason': error})
                    raise MonitoringFailure(error)
            original_tracking = tracking.Tracking
            observed = self

            class Tracking(original_tracking):
                def log(self, data, step):
                    super().log(data, step)
                    observed.report_step(data, step)

            tracking.Tracking = Tracking
            try:
                return super().fit()
            except (MonitoringFailure, IdentityFailure, CheckpointFailure) as exc:
                failure = {'reason': str(exc)}
                if isinstance(exc, MonitoringFailure) and exc.counts is not None:
                    failure.update(step=self.global_steps, counts=exc.counts)
                write_json(self.formal_work / 'failure.json', failure)
                raise
            finally:
                tracking.Tracking = original_tracking

        def _load_checkpoint(self):
            result = super()._load_checkpoint()
            wanted = self.formal_start
            if self.global_steps != wanted:
                raise CheckpointFailure('veRL 恢复的全局步号与选定回执不一致')
            data_step = position(self.train_dataloader.state_dict()) if wanted else 0
            if data_step != wanted:
                raise CheckpointFailure('veRL 恢复的数据加载位置与选定回执不一致')
            recovered_report = self.formal_store.receipts
            for path in sorted(recovered_report.glob('step_*.json'),
                               key=lambda file: int(file.stem.split('_')[-1])):
                report = self.formal_store.record(int(path.stem.split('_')[-1]))
                append_diagnostics(report)
            write_json(self.formal_work / 'restore.json',
                       {'global_step': self.global_steps, 'data_batches': data_step})
            return result

        def _get_gen_batch(self, batch):
            if self.formal_validation is not None:
                self.formal_validation.update(expected(batch, 1, 'val'))
            else:
                self.formal_train = expected(batch, 16, 'train')
                if sum(self.formal_train.values()) != 256:
                    raise IdentityFailure('训练批次轨迹数与冻结设置不符')
                self.formal_window = self.formal_monitor.begin()
                if config.SPEED:
                    self.formal_queue_start = time.monotonic_ns()
                if config.RESTART:
                    self.formal_step_wall = time.time()
            return super()._get_gen_batch(batch)

        def _update_actor(self, batch):
            audit_start = time.monotonic_ns()
            vote = self.formal_monitor.end(self.formal_window)
            step = self.global_steps
            collect = step % config.SAVE == 0 or step == 2 or step == config.TOTAL
            if collect and not config.RESTART and self.formal_strip is None:
                from visibility import author_strip, load_tokenizer
                self.formal_strip = author_strip()
                self.formal_tokenizer, _ = load_tokenizer()
            self.formal_visibility = [] if config.RESTART and collect else None
            rows = self.formal_rows.completed_phase(self.formal_train,
                        self.formal_strip if collect and not config.RESTART else None,
                        self.formal_tokenizer if collect and not config.RESTART else None,
                        deferred_visibility=self.formal_visibility)
            verify_judge_coverage(vote, rows)
            batches = position(self.train_dataloader.state_dict())
            if batches != step:
                raise IdentityFailure('训练批次与原生数据加载位置不一致')
            self.formal_training_report = dict(vote, **rows, data_batches=batches)
            if config.SPEED:
                self.formal_queue_end = audit_start
                if config.RESTART and step == 2 and os.environ.get('EDU_RESTART_PROFILE_STEP2') == '1':
                    write_json(self.formal_work / 'profile-step2-ready.json', {'monotonic': time.monotonic()})
                model_start = time.monotonic_ns()
                result = super()._update_actor(batch)
                self.formal_training_report.update(
                    actor_audit_s=(model_start - audit_start) / 1e9,
                    actor_rpc_s=(time.monotonic_ns() - model_start) / 1e9,
                )
                return result
            return super()._update_actor(batch)

        def _validate(self, merged=False):
            from collections import Counter
            self.formal_validation = Counter()
            snapshot = self.formal_monitor.begin()
            try:
                result = super()._validate(merged=merged)
                vote = self.formal_monitor.end(snapshot, enforce=False)
                if sum(self.formal_validation.values()) != 100:
                    raise IdentityFailure('验证批次来源总数不符')
                rows = self.formal_rows.completed_phase(self.formal_validation)
                verify_judge_coverage(vote, rows)
                self.formal_validation_report = dict(vote, **rows)
                return result
            finally:
                self.formal_validation = None

        def _save_checkpoint(self):
            self.formal_store.before_save(self.global_steps)
            result = super()._save_checkpoint()
            self.formal_saved = self.global_steps
            return result

        def report_step(self, data, step):
            if step < 1 or step != self.global_steps or int(data.get('training/global_step', -1)) != step:
                raise IdentityFailure('veRL 指标步号不一致')
            self.formal_monitor.poll()
            row = dict(self.formal_training_report)
            row.update(step=step, metrics=numeric_metrics(data))
            first_step = None
            step_comparison = None
            if config.RESTART:
                row['window_start_at'] = self.formal_step_wall
                row['window_end_at'] = time.time()
                row['gpu_peaks'] = peak_window(self.formal_work / 'gpu-protection.jsonl',
                                               row['window_start_at'], row['window_end_at'])
                if self.formal_visibility is not None:
                    if self.formal_strip is None:
                        from visibility import author_strip, load_tokenizer
                        self.formal_strip = author_strip()
                        self.formal_tokenizer, _ = load_tokenizer()
                    from collections import Counter
                    visibility = Counter()
                    for item in self.formal_visibility:
                        self.formal_rows.visibility(item, visibility, self.formal_strip, self.formal_tokenizer)
                    row.update(visibility)
                    self.formal_visibility = None
                if step == 2:
                    import json
                    first_row = json.loads((self.formal_work / 'step-statistics/1.json').read_text())
                    try:
                        step_comparison = restart_comparison(first_row, row)
                    except ValueError as exc:
                        raise MonitoringFailure(str(exc)) from None
            if config.SPEED and step <= 2 and (config.RESTART or step == 1):
                row['queues'] = queue_metrics.summarize(self.formal_work / 'queue-metrics',
                                                        self.formal_queue_start, self.formal_queue_end)
                if step == 1:
                    try:
                        first_step = assess_first_step(baseline_row(config.c.ROOT)['metrics'],
                                                       row['metrics'], row['queues'])
                    except SpeedFailure as exc:
                        raise MonitoringFailure(str(exc)) from None
            if step % 25 == 0 or step == config.TOTAL:
                row['validation'] = self.formal_validation_report
            row['disk_free_gb'] = round(shutil.disk_usage(self.formal_work).free / 1e9, 2)
            if self.formal_saved == step:
                # The native save has completed, and validation, if due, has been attributed separately.
                import torch
                data_state = torch.load(self.formal_store.checkpoint(step) / 'data.pt',
                                        map_location='cpu', weights_only=False)
                if position(data_state) != step:
                    raise CheckpointFailure('落盘的数据加载位置不完整')
                self.formal_store.verified(step, row['data_batches'], row,
                                          partial(cpu_merge, self.formal_work))
                append_diagnostics(row)
            steps = self.formal_work / 'step-statistics'
            steps.mkdir(exist_ok=True)
            write_json(steps / f'{step}.json', row)
            if step == 2:
                write_json(self.formal_work / 'step-2.json', row)
            write_json(self.formal_work / 'latest-step.json', row)
            if first_step is not None:
                write_json(self.formal_work / 'six-card-first-step.json', first_step)
                if not config.RESTART and not first_step['accepted']:
                    raise MonitoringFailure('六卡首步未提速')
            if step_comparison is not None:
                write_json(self.formal_work / 'restart-step2-comparison.json', step_comparison)
                if step_comparison['slowdown']:
                    raise MonitoringFailure('第2步原生Tutor更新明显变慢')
    return ObservedTrainer


def verify_judge_coverage(vote, rows):
    if vote['requests'] < 6 * rows['judgeable']:
        raise MonitoringFailure('裁判访问日志少于应有回复数', vote)


def diagnostics_row(row):
    n = row['rows']
    turns = row.get('retokenized', 0)
    invisible = f"{100 * row['invisible'] / n:.2f}%" if n and 'invisible' in row else '未知'
    at_cap = f"{100 * row.get('at_cap', 0) / turns:.2f}%" if turns else '未知'
    metrics = row['metrics']
    return (row['step'], row['passed'], invisible, at_cap, row['requests'], row['parse'], row['recovery'],
            metrics.get('actor/grad_norm', '未知'), metrics.get('actor/pg_loss', '未知'),
            metrics.get('timing_s/step', '未知'), row['disk_free_gb'])


def append_diagnostics(row):
    # Each checkpoint contributes one fixed-width report row across all attempts.
    path = config.SERIES / '检查点汇总.md'
    head = ('| 步 | 放行 | 教师全程无可见发言 | 回合约达 662 | 裁判请求 | 解析失败 | 正则恢复 | grad_norm | pg_loss | step 秒 | 剩余 GB |\n'
            '|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n')
    text = path.read_text(encoding='utf-8') if path.exists() else head
    if any(line.startswith(f"| {row['step']} | ") for line in text.splitlines()):
        return
    # Atomically replace the cumulative text so an interrupted append is repairable
    # from checkpoint receipts without creating a duplicate or partial row.
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile(mode='w', dir=path.parent, encoding='utf-8', delete=False) as out:
        name = Path(out.name)
        out.write(text + '| ' + ' | '.join(map(str, diagnostics_row(row))) + ' |\n')
        out.flush()
        os.fsync(out.fileno())
    try:
        name.replace(path)
    finally:
        name.unlink(missing_ok=True)


def run(check_only):
    import hydra
    import ray
    from omegaconf import OmegaConf
    from verl.experimental.reward_loop import migrate_legacy_reward_impl
    from verl.trainer import main_ppo
    from verl.utils.device import auto_set_device

    class TaskRunner(main_ppo.TaskRunner):
        def run(self, cfg):
            native = main_ppo.RayPPOTrainer
            main_ppo.RayPPOTrainer = bound_trainer(native)
            try:
                return super().run(cfg)
            finally:
                main_ppo.RayPPOTrainer = native

    @hydra.main(config_path=None, config_name=None, version_base=None)
    def execute(cfg):
        work = Path(os.environ['WORK_DIR'])
        start = int(os.environ.get('FORMAL_START', '0')) or None
        config.pin_composed(OmegaConf.to_container(cfg, resolve=True), work, cfg.vars.student_model_name,
                            cfg.actor_rollout_ref.rollout.multi_turn.interaction_config_path, start)
        auto_set_device(cfg)
        cfg = migrate_legacy_reward_impl(cfg)
        keep_teacher_budgets(cfg)
        if check_only:
            print('FORMAL_PRECHECK_OK')
            return
        main_ppo.run_ppo(cfg, task_runner_class=ray.remote(num_cpus=1)(TaskRunner))

    def stop(_signal, _frame):
        raise SystemExit('控制器停止信号')

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        execute()
    finally:
        if ray.is_initialized():
            ray.shutdown()


if __name__ == '__main__':
    check = '--check-only' in sys.argv
    if check:
        sys.argv.remove('--check-only')
    run(check)
