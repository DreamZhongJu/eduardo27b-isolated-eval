import fcntl
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from gpu_guard import GPUGuard, GPUProtection
import restart_control as gate


class TerminalGateTests(unittest.TestCase):
    def setUp(self):
        scratch = tempfile.TemporaryDirectory()
        self.addCleanup(scratch.cleanup)
        folder = Path(scratch.name)
        self.root, self.kit, self.proc = (folder / name for name in ('root', 'kit', 'proc'))
        self.proc.mkdir()
        self.work = self.root / 'pilots' / gate.switch.RUN
        self.work.mkdir(parents=True)
        self.store = self.root / 'formal_a_v1'
        self.pid = 707
        self.write_terminal('失败')
        self.write_metrics(4)
        (self.root / '.pilot.lock').touch()
        launcher = self.kit / 'a_group_formal_v1/start_formal.sh'
        launcher.parent.mkdir(parents=True)
        launcher.touch()
        self.gpus = {
            i: {'uuid': f'GPU-{i}', 'name': 'A100-SXM4-80GB',
                'total': 81920, 'free': 81050, 'util': 0, 'apps': []}
            for i in range(6)
        }

    def write_terminal(self, phase):
        (self.work / 'orchestration.json').write_text(
            json.dumps({'controller_pid': self.pid, 'phase': phase}))

    def write_metrics(self, step):
        (self.work / 'latest-step.json').write_text(json.dumps({'step': step, 'data_batches': step}))
        (self.work / 'trainer.log').write_text(f'step:{step} - training/global_step:{step} timing_s/step:11.0\n')

    def write_process(self, pid, args, state='S'):
        folder = self.proc / str(pid)
        folder.mkdir(exist_ok=True)
        fields = [state, *(['0'] * 18), '42']
        (folder / 'stat').write_text(f'{pid} (fixture) ' + ' '.join(fields))
        (folder / 'cmdline').write_bytes(b'\0'.join(map(os.fsencode, args)) + b'\0')

    @staticmethod
    def eligible(card):
        return card['total'] - card['free'] <= 1024 and card['util'] == 0 and not card['apps']

    def options(self, snapshot=None):
        cards = SimpleNamespace(snapshot=snapshot or (lambda: self.gpus), eligible=self.eligible)
        return {'load_cards': lambda: cards, 'sleep': lambda _: None, 'check_ports': lambda: None}

    def preflight(self, **options):
        return gate.preflight(self.root, self.proc, self.kit, **(options or self.options()))

    def record(self, **approval):
        return gate.record_start(self.root, self.proc, self.kit, **self.options(), **approval)

    def test_terminal_only_and_read_only(self):
        before = {path: path.read_bytes() for path in self.root.rglob('*') if path.is_file()}
        ready = self.preflight()
        self.assertEqual(ready, gate.Ready(4, 4, 0, tuple(range(6))))
        self.assertEqual(before, {path: path.read_bytes() for path in self.root.rglob('*') if path.is_file()})
        self.write_terminal('训练中')
        with self.assertRaisesRegex(gate.switch.SwitchRefused, '终止态'):
            self.preflight()

    def test_reused_unrelated_pid_is_ignored_and_retained(self):
        self.write_process(self.pid, ('/bin/sleep', '60'))
        self.assertEqual(self.preflight().completed, 4)
        self.assertTrue((self.proc / str(self.pid)).exists())

    def test_refuses_old_controller_or_resource_guard_even_with_new_pid(self):
        for relative in ('a_group_formal_v1/formal_stage.py',
                         'a_group_b_native_v1/parent_guard.py',
                         'a_group_b_native_v1/resources.py'):
            with self.subTest(script=relative):
                self.write_process(self.pid + 1, ('python', str(self.kit / relative)))
                with self.assertRaisesRegex(gate.switch.SwitchRefused, '仍在运行'):
                    self.preflight()
        self.write_process(self.pid + 1, ('python', str(self.kit / relative)), state='Z')
        self.assertEqual(self.preflight().completed, 4)

    def test_refuses_active_27b(self):
        self.write_process(self.pid, ('python', '/workspace/eduardo27b-dual/app/offline_eval.py'))
        with self.assertRaisesRegex(gate.switch.SwitchRefused, '27B'):
            self.preflight()

    def test_refuses_held_controller_lock(self):
        with (self.root / '.pilot.lock').open('wb') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaisesRegex(gate.switch.SwitchRefused, '锁'):
                self.preflight()

    def test_whole_student_and_stable_identity(self):
        busy = dict(self.gpus[5], free=77000, apps=[(11, 4500)])
        second = dict(self.gpus)
        second[5] = busy
        card = SimpleNamespace(eligible=self.eligible)
        self.assertTrue(gate.resources.is_eligible(card, 'student', busy))
        self.assertFalse(gate.resources.is_eligible(card, 'student', busy, student_full=True))
        for row in (busy, dict(self.gpus[5], uuid='GPU-changed')):
            with self.subTest(row=row):
                second[5] = row
                samples = iter((self.gpus, second))
                with self.assertRaisesRegex(gate.switch.SwitchRefused, '仅核实5张'):
                    self.preflight(**self.options(snapshot=lambda: next(samples)))

    def test_four_tutor_cards_and_services_handoff_after_stable_snapshots(self):
        resources = gate.resources
        class SimulatedClock:
            elapsed = 0
            def now(self):
                return self.elapsed
            def sleep(self, seconds):
                self.elapsed += seconds

        class Holder:
            pid = 0
            dead = False
            def __init__(self, binding):
                self.binding = binding
                self.acquired_wall = clock.now()
                self.acquired_mono = clock.now()
                self.amount_mib = 79092
                self.process = SimpleNamespace(pid=binding.index + 200)
            def alive(self):
                return not self.dead
            def release(self):
                self.dead = True

        class Callbacks:
            def launch_service(self, role, binding):
                handoff.append((role, binding.index))
                return SimpleNamespace(poll=lambda: None)
            def service_ready(self, role, _binding, _proc):
                healthy.add(role)
                return True
            def launch_tutor(self, bindings):
                self_outer.assertEqual(healthy, {'judge', 'student'})
                handoff.extend((binding.role, binding.index) for binding in bindings)
                return object()

        self_outer = self
        clock = SimulatedClock()
        healthy, handoff = set(), []
        cards = SimpleNamespace(eligible=self.eligible, own_lock=lambda: os.open('/dev/null', os.O_RDONLY))
        manager = resources.GPUResources(
            self.work, stage_a=cards, snapshot=lambda: self.gpus,
            spawn=lambda binding, _: Holder(binding), monotonic=clock.now,
            wall=clock.now, sleep=clock.sleep, tutor_count=4, student_full=True)
        manager.acquire_lock()
        self.addCleanup(manager.close)
        manager.acquire_and_handoff(Callbacks())
        self.assertEqual([role for role, _ in handoff],
                         ['judge', 'student', 'tutor_1', 'tutor_2', 'tutor_3', 'tutor_4'])
        self.assertEqual({gpu for _, gpu in handoff}, set(range(6)))
        self.assertFalse(manager.holders)

    def test_six_card_shortage_refuses_before_any_holder(self):
        calls = []
        stage = SimpleNamespace(eligible=self.eligible, own_lock=lambda: os.open('/dev/null', os.O_RDONLY))
        coordinator = gate.resources.GPUResources(
            self.work, stage_a=stage, snapshot=lambda: {i: self.gpus[i] for i in range(5)},
            spawn=lambda *args: calls.append(args), sleep=lambda _: None, tutor_count=4,
            student_full=True, require_full_set=True)
        coordinator.acquire_lock()
        self.addCleanup(coordinator.close)
        with self.assertRaisesRegex(gate.resources.ResourceError, '六张'):
            coordinator.acquire()
        self.assertEqual(calls, [])

    def test_verified_step5_can_precede_step_receipt_and_is_preserved(self):
        step = 5
        folder = self.store / 'checkpoints' / f'global_step_{step}'
        actor = folder / 'actor'
        (actor / 'huggingface').mkdir(parents=True)
        (actor / 'huggingface/config.json').write_text('{}')
        (actor / 'fsdp_config.json').write_text('{"world_size":2}')
        (folder / 'data.pt').write_bytes(b'test')
        for kind in ('model', 'optim', 'extra_state'):
            for rank in range(2):
                (actor / f'{kind}_world_size_2_rank_{rank}.pt').write_bytes(b'test')
        self.assertEqual(self.preflight().rollback, 0)
        (self.store / 'verified').mkdir()
        (self.store / 'verified/step_5.json').write_text(json.dumps({'step': step, 'data_batches': step}))
        self.assertEqual(self.preflight(), gate.Ready(4, 5, 5, tuple(range(6))))
        (actor / 'optim_world_size_2_rank_1.pt').unlink()
        with self.assertRaisesRegex(gate.switch.SwitchRefused, '不完整'):
            self.preflight()

    def test_cutoff_even_after_process_exits(self):
        self.write_metrics(20)
        with self.assertRaisesRegex(gate.switch.SwitchRefused, '第20步'):
            self.preflight()

    def test_approval_is_required_and_one_shot(self):
        with self.assertRaisesRegex(gate.switch.SwitchRefused, '批准'):
            self.record(confirm=gate.CONFIRM)
        self.assertFalse((self.root / gate.RECEIPT).exists())
        self.record(confirm=gate.CONFIRM, deferred=True)
        state = json.loads((self.root / gate.RECEIPT).read_text())
        self.assertEqual(state['rollback_step'], 0)
        self.assertEqual(state['completed_step'], 4)
        self.assertTrue(state['27b_deferred_confirmed'])
        with self.assertRaisesRegex(gate.switch.SwitchRefused, '一次性'):
            self.record(confirm=gate.CONFIRM, deferred=True)


class GPUProtectionTests(unittest.TestCase):
    def setUp(self):
        scratch = tempfile.TemporaryDirectory()
        self.addCleanup(scratch.cleanup)
        self.work = Path(scratch.name)
        self.clock = 0
        self.curr = {0: {'free': 40960}, 1: {'free': 8192}, 2: {'free': 9000}}
        self.bindings = {'student': [0], 'judge': [1], 'tutor': [2]}
        self.guard = GPUGuard(lambda: self.curr, self.work, self.bindings,
                              monotonic=lambda: self.clock, wall=lambda: self.clock)

    def tick(self):
        self.guard.check()
        self.clock += 10

    def logs(self):
        return [json.loads(line) for line in self.guard.path.read_text().splitlines()]

    def test_known_low_student_is_immediate_for_all_roles(self):
        self.tick()
        self.assertEqual(self.logs()[-1]['state'], '正常')
        self.curr[0]['free'] = 8191
        with self.assertRaises(GPUProtection) as failure:
            self.tick()
        self.assertEqual(failure.exception.gpu, 0)
        self.assertEqual(self.logs()[-1]['free_mib'], {'0': 8191, '1': 8192, '2': 9000})

    def test_judge_and_tutor_low_also_stop_and_log_ownership(self):
        for gpu in (1, 2):
            with self.subTest(gpu=gpu):
                self.curr[gpu] = {'free': 8000, 'apps': [(952, 200), (981, 775)]}
                self.guard.proc_snapshot = lambda: {
                    2: {'ppid': 1, 'hostpid': 952, 'start': 5},
                    3: {'ppid': 1, 'hostpid': 981, 'start': 9},
                }
                self.guard.roots = lambda: ((2, 5),)
                with self.assertRaises(GPUProtection) as failure:
                    self.tick()
                self.assertEqual(failure.exception.gpu, gpu)
                self.assertEqual(self.logs()[-1]['cards'][str(gpu)]['external_processes'], 1)
                self.assertEqual(self.logs()[-1]['cards'][str(gpu)]['free_mib'], 8000)
                self.curr[gpu]['free'] = 9500
                self.clock += 10

    def test_alternating_missing_cards_do_not_trigger(self):
        for gpu in (0, 1, 0, 1, 0, 1):
            old = self.curr.pop(gpu)
            self.tick()
            self.curr[gpu] = old
            self.assertEqual(self.logs()[-1]['consecutive_bad'], 1)

    def test_admission_during_gap_keeps_10_second_cadence(self):
        self.tick()
        self.clock = 9
        self.guard.check()
        self.assertEqual(len(self.logs()), 1)
        self.clock = 10
        self.tick()
        self.assertEqual(len(self.logs()), 2)

    def test_invalid_samples_three_consecutive_and_clean_sample_resets(self):
        self.curr[1] = {'free': True}
        self.tick()
        self.tick()
        self.curr[1] = {'free': 8192}
        self.tick()
        del self.curr[1]
        self.tick()
        self.tick()
        with self.assertRaisesRegex(GPUProtection, '连续3次') as failure:
            self.tick()
        self.assertEqual(failure.exception.gpu, 1)
        self.assertEqual([r['consecutive_bad'] for r in self.logs()], [1, 2, 0, 1, 2, 3])

    def test_snapshot_failure_is_sanitized(self):
        def raises():
            raise OSError('some raw output')
        self.guard.snapshot = raises
        self.tick()
        self.assertEqual(self.logs()[-1]['unreadable_gpu'], [0, 1, 2])
        self.assertNotIn('some raw output', self.guard.path.read_text())


if __name__ == '__main__':
    unittest.main()
