"""Protect this run using read-only samples and fixed, aggregate diagnostics."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import time


class GPUProtection(RuntimeError):
    def __init__(self, reason, gpu=None):
        super().__init__(reason)
        self.gpu = gpu


def ownership(apps, proc_rows, roots):
    if not isinstance(apps, list):
        return None, None
    if not apps:
        return 0, 0
    if not roots or not all(proc_rows.get(pid, {}).get('start') == start for pid, start in roots):
        return None, len(apps)
    descendants = {pid for pid, _ in roots}
    while True:
        children = {pid for pid, row in proc_rows.items() if row['ppid'] in descendants}
        if children <= descendants:
            break
        descendants.update(children)
    by_host = defaultdict(list)
    for pid, row in proc_rows.items():
        if row['hostpid'] is not None:
            by_host[row['hostpid']].append(pid)
    external = unknown = 0
    for host_pid, _ in apps:
        matches = by_host[host_pid]
        if len(matches) != 1:
            unknown += 1
        elif matches[0] not in descendants:
            external += 1
    return external if not unknown else None, unknown


class GPUGuard:
    def __init__(self, snapshot, work: Path, bindings, *, minimum_roles=None,
                 minimum_mib=8192, bad_limit=3, interval=10, monotonic=time.monotonic,
                 wall=time.time, proc_snapshot=lambda: {}, roots=lambda: ()):
        self.snapshot = snapshot
        self.path = work / 'gpu-protection.jsonl'
        self.bindings = bindings
        self.minimum_roles = None if minimum_roles is None else frozenset(minimum_roles)
        self.minimum_mib = minimum_mib
        self.bad_limit = bad_limit
        self.interval = interval
        self.monotonic = monotonic
        self.wall = wall
        self.proc_snapshot = proc_snapshot
        self.roots = roots
        self.next_sample = 0
        self.bad_by_gpu = Counter()

    def check(self):
        now = self.monotonic()
        observed = {gpu for cards in self.bindings.values() for gpu in cards}
        if not observed or now < self.next_sample:
            return
        self.next_sample = now + self.interval
        guarded = {gpu for role, cards in self.bindings.items()
                   if self.minimum_roles is None or role in self.minimum_roles for gpu in cards}
        try:
            snapshot = self.snapshot()
        except Exception:
            snapshot = {}
        try:
            proc_rows, roots = self.proc_snapshot(), self.roots()
        except Exception:
            proc_rows, roots = {}, ()
        if not isinstance(snapshot, dict):
            snapshot = {}
        free, info = {}, {}
        for gpu in sorted(observed):
            row = snapshot.get(gpu)
            entry = row if isinstance(row, dict) else {}
            amount = entry.get('free')
            free[gpu] = amount if type(amount) is int and amount >= 0 else None
            self.bad_by_gpu[gpu] = self.bad_by_gpu[gpu] + 1 if free[gpu] is None else 0
            external, unknown = ownership(entry.get('apps'), proc_rows, roots)
            info[gpu] = {'free_mib': free[gpu], 'total_mib': entry.get('total'),
                         'util_percent': entry.get('util'), 'external_processes': external,
                         'unknown_processes': unknown, 'unreadable_streak': self.bad_by_gpu[gpu]}
        for gpu in self.bad_by_gpu.keys() - observed:
            del self.bad_by_gpu[gpu]
        unreadable = [gpu for gpu, amount in free.items() if amount is None]
        low = [gpu for gpu in sorted(guarded)
               if free[gpu] is not None and free[gpu] < self.minimum_mib]
        invalid = [gpu for gpu in unreadable if self.bad_by_gpu[gpu] >= self.bad_limit]
        phase = '低显存' if low else '采样异常' if unreadable else '正常'
        with self.path.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps({
                'time': self.wall(), 'state': phase, 'free_mib': free, 'cards': info,
                'guarded_gpu': sorted(guarded), 'minimum_mib': self.minimum_mib,
                'unreadable_gpu': unreadable, 'low_gpu': low,
                'consecutive_bad': max(self.bad_by_gpu.values()),
            }, ensure_ascii=False) + '\n')
        if low:
            raise GPUProtection('本任务显卡剩余显存低于保护阈值', low[0])
        if invalid:
            raise GPUProtection('本任务显卡状态连续3次采样异常', invalid[0])
