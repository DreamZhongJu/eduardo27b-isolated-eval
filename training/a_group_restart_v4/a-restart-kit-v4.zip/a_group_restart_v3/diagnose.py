"""Read the four-card attempt without printing log content or touching a GPU."""

import argparse
import ast
from collections import Counter, defaultdict
from collections.abc import Mapping
import importlib
from importlib import metadata
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path('/workspace/A_group_repro_20261117')
OLD_KIT = Path('/workspace/a-formal-kit-v1')
UNKNOWN = '未知'
STEPS = (1, 2, 3, 4, 5, 25)
TIMES = ('timing_s/step', 'timing_s/gen', 'timing_s/update_actor')
PERF = ('perf/max_memory_allocated_gb', 'perf/max_memory_reserved_gb',
        'perf/cpu_memory_used_gb', 'perf/total_num_tokens', 'perf/throughput',
        'response_length/mean', 'timing_s/old_log_prob')
PACKAGES = ('transformers', 'flash-attn', 'flash-linear-attention', 'fla-core', 'causal-conv1d')
CONFIG = ('actor_rollout_ref.actor.fsdp_config.param_offload',
          'actor_rollout_ref.actor.fsdp_config.optimizer_offload',
          'actor_rollout_ref.model.enable_gradient_checkpointing',
          'actor_rollout_ref.model.use_remove_padding',
          'actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu')
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
STEP_LOG = re.compile(r'(?<!\S)step:(\d+)\s+-\s')
GLOBAL_STEP = re.compile(r'(?:^|\s-\s)training/global_step:(\d+)(?=\s|$)')
SCALAR = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
METRIC_LOG = re.compile(
    r'(?:^|\s-\s)(' + '|'.join(map(re.escape, (*TIMES, *PERF))) +
    rf'):(?:(?:np|numpy)\.(?:float(?:16|32|64)|int(?:32|64))\(({SCALAR})\)|({SCALAR}))(?=\s|$)'
)
TASK_RUNNER = re.compile(r'^\(TaskRunner pid=(\d+)\) ?')
FALLBACK = b'The fast path is not available because one of the required library is not installed'


def read_text(path):
    try:
        return path.read_text(encoding='utf-8')
    except (OSError, UnicodeError):
        return ''


def object_from(text):
    try:
        value = json.loads(text)
    except ValueError:
        return {}
    return value if isinstance(value, dict) else {}


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def number(value):
    if not finite(value):
        return '无'
    return str(value) if type(value) is int else f'{value:.8g}'


def table(title, headers, rows):
    print('\n' + title)
    print('| ' + ' | '.join(headers) + ' |')
    print('| ' + ' | '.join('---' for _ in headers) + ' |')
    for row in rows:
        print('| ' + ' | '.join(map(str, row)) + ' |')


def selected_config(config):
    values = {}
    for index, key in enumerate(CONFIG):
        value = config
        for part in key.split('.'):
            value = value.get(part) if isinstance(value, Mapping) else None
        if type(value) is (bool if index < 4 else int):
            values[key] = value
    return values


def read_trainer(path):
    """Read step metrics and veRL v0.7.1's initial resolved TaskRunner config."""
    values = defaultdict(lambda: defaultdict(set))
    configs = []
    runner = None
    chunks = []
    size = 0
    try:
        with path.open(encoding='utf-8', errors='replace') as stream:
            for raw in stream:
                line = ANSI.sub('', raw).rstrip('\r\n')
                header = STEP_LOG.findall(line)
                if len(header) == 1 and header == GLOBAL_STEP.findall(line):
                    step = int(header[0])
                    if step in STEPS:
                        for key, wrapped, bare in METRIC_LOG.findall(line):
                            value = float(wrapped or bare)
                            if math.isfinite(value):
                                values[step][key].add(value)

                prefix = TASK_RUNNER.match(line)
                pid = prefix[1] if prefix else ''
                content = line[prefix.end():] if prefix else line
                if content.startswith('TaskRunner hostname:') and not chunks:
                    runner = pid
                elif runner is not None and pid == runner:
                    if not chunks and not content.startswith("{'actor_rollout_ref':"):
                        runner = None
                        continue
                    size += len(content)
                    if size > 512_000:
                        runner = None
                        chunks.clear()
                        size = 0
                        continue
                    chunks.append(content)
                    if content.endswith('}'):
                        # Nested dicts may close earlier. literal_eval accepts only
                        # a complete literal and never executes text from the log.
                        try:
                            candidate = ast.literal_eval('\n'.join(chunks))
                        except (SyntaxError, ValueError, RecursionError):
                            continue
                        config = selected_config(candidate)
                        if config:
                            configs.append(config)
                        runner = None
                        chunks.clear()
                        size = 0
    except OSError:
        pass
    metrics = {step: {key: next(iter(found)) for key, found in group.items() if len(found) == 1}
               for step, group in values.items()}
    return metrics, configs[0] if configs and all(x == configs[0] for x in configs) else {}


def progress(work, log_metrics):
    metrics = {}
    windows = {}
    previous_end = 0
    for step in STEPS:
        path = work / 'step-statistics' / f'{step}.json'
        row = object_from(read_text(path))
        metric = dict(log_metrics.get(step, {}))
        if row.get('step') == step and row.get('data_batches') == step:
            if isinstance(row.get('metrics'), dict):
                metric.update({k: v for k, v in row['metrics'].items() if finite(v)})
            start, end = row.get('window_start_at'), row.get('window_end_at')
            method = '记录的起止时间'
            if not finite(start) or not finite(end):
                try:
                    end = path.stat().st_mtime
                except OSError:
                    end = None
                duration = metric.get('timing_s/step')
                start = end - duration if finite(end) and finite(duration) else None
                method = '回执时间减步用时（近似）'
            if finite(start) and finite(end) and 0 < start < end:
                # Avoid assigning a sample to two steps. The old receipt is at or
                # after the corresponding step ends, so the boundary is approximate.
                start = max(start, previous_end)
                if start < end:
                    windows[step] = (start, end, method)
                    previous_end = end
        metrics[step] = metric
    return metrics, windows


def history(work, windows, cards):
    counts = defaultdict(Counter)
    try:
        with (work / 'gpu_samples.jsonl').open(encoding='utf-8', errors='replace') as stream:
            for line in stream:
                row = object_from(line)
                timestamp = row.get('time')
                if not finite(timestamp):
                    continue
                matching_step = next((step for step, bounds in windows.items()
                                      if bounds[0] <= timestamp < bounds[1]), None)
                gpus = row.get('gpus')
                if matching_step is None or not isinstance(gpus, dict):
                    continue
                for _, gpu in cards:
                    card = gpus.get(str(gpu))
                    if not isinstance(card, dict):
                        continue
                    bucket = counts[matching_step, gpu]
                    bucket['samples'] += 1
                    bucket['verified'] += card.get('verified') is True
                    # The original records lack external ownership and utilization.
                    # An unmapped PID or a low ownership coverage does not imply
                    # another user's process.
                    external = card.get('external_process_count')
                    utilization = card.get('utilization')
                    if type(external) is int and external >= 0:
                        bucket['external_known'] += 1
                        bucket['external_busy'] += external > 0
                    if finite(utilization) and 0 <= utilization <= 100:
                        bucket['util_count'] += 1
                        bucket['util_total'] += utilization
                        bucket['util_peak'] = max(bucket['util_peak'], utilization)
    except OSError:
        return None
    return counts


def query(*argv):
    try:
        result = subprocess.run(argv, env=dict(os.environ, LC_ALL='C'), capture_output=True,
                                text=True, encoding='utf-8', errors='replace', timeout=15)
        if result.returncode == 0:
            return result.stdout
    except (OSError, subprocess.SubprocessError):
        pass
    return ''


def digit_values(text, count):
    fields = text.split()
    if len(fields) != count or any(re.fullmatch(r'\d+', field) is None for field in fields):
        return [UNKNOWN] * count
    return list(map(int, fields))


def cgroup_directory(proc, mount):
    mapping = re.findall(r'^0::(/[^\r\n]*)$', read_text(proc / 'self/cgroup'), re.M)
    if len(mapping) != 1:
        return None
    for line in read_text(proc / 'self/mountinfo').splitlines():
        left, sep, right = line.partition(' - ')
        fields = left.split()
        if not sep or len(fields) < 5 or fields[4] != str(mount) or not right.startswith('cgroup2 '):
            continue
        try:
            relative = Path(mapping[0]).relative_to(fields[3])
            target = (mount / relative).resolve(strict=True)
            target.relative_to(mount.resolve())
            if target.is_dir():
                return target
        except (OSError, ValueError):
            continue
    return None


def snapshot_host():
    mem = swap = ''
    for line in query('free', '-g').splitlines():
        if line.startswith('Mem:'):
            mem = line.partition(':')[2]
        if line.startswith('Swap:'):
            swap = line.partition(':')[2]
    memory_keys = ('总量', '已用', '空闲', '共享', '缓存', '可用')
    rows = [(f'内存 {key} GiB', val) for key, val in zip(memory_keys, digit_values(mem, 6))]
    rows.extend((f'swap {key} GiB', val)
                for key, val in zip(('总量', '已用', '空闲'), digit_values(swap, 3)))
    meminfo = read_text(Path('/proc/meminfo'))
    swaps = {key: int(value) for key, value in
             re.findall(r'^(SwapTotal|SwapFree):\s+(\d+)\s+kB$', meminfo, re.M)}
    rows.append(('swap 已用 KiB', swaps['SwapTotal'] - swaps['SwapFree']
                 if len(swaps) == 2 else UNKNOWN))
    cg = cgroup_directory(Path('/proc'), Path('/sys/fs/cgroup'))
    for key in ('memory.max', 'memory.current'):
        value = read_text(cg / key).strip() if cg else ''
        normalized = '不限' if key == 'memory.max' and value == 'max' else digit_values(value, 1)[0]
        rows.append((f'cgroup {key}（字节）', normalized))
    for filename, keys in (('memory.events', ('high', 'max', 'oom_kill')),
                           ('memory.stat', ('pgmajfault',))):
        content = read_text(cg / filename) if cg else ''
        counters = dict(re.findall(r'^(\w+) (\d+)$', content, re.M))
        rows.extend((f'cgroup {filename} {key}', counters.get(key, UNKNOWN)) for key in keys)
    rows.append(('nproc', digit_values(query('nproc'), 1)[0]))
    load = re.search(r'load average[s]?:\s*([\d.]+),\s*([\d.]+),\s*([\d.]+)', query('uptime'))
    rows.append(('uptime 1 / 5 / 15 分钟负载', ' / '.join(load.groups()) if load else UNKNOWN))
    table('当前 CPU、内存与容器 cgroup v2', ('项目', '数值'), rows)
    print('以上为当前查询和 cgroup 累计计数，历史训练步的主机状态需当时的采样。')


def proc_identity(path):
    stat = read_text(path / 'stat').rpartition(') ')[2].split()
    if len(stat) < 20 or stat[0] == 'Z':
        return None
    try:
        return int(stat[1]), int(stat[19])
    except ValueError:
        return None


def process_args(path):
    try:
        return (path / 'cmdline').read_bytes().rstrip(b'\0').split(b'\0')
    except OSError:
        return []


def allocator_value(raw):
    valid = re.fullmatch(
        rb'(?:[A-Za-z_][A-Za-z_0-9]*:(?:-?\d+(?:\.\d+)?|True|False|native|cudaMallocAsync|'
        rb'\[\d+:\d+(?:,\d+:\d+)*(?:,>:\d+)?\]))'
        rb'(?:,[A-Za-z_][A-Za-z_0-9]*:(?:-?\d+(?:\.\d+)?|True|False|native|cudaMallocAsync|'
        rb'\[\d+:\d+(?:,\d+:\d+)*(?:,>:\d+)?\]))*', raw,
    )
    known = {
        b'backend', b'max_split_size_mb', b'roundup_power2_divisions',
        b'max_non_split_rounding_mb', b'garbage_collection_threshold',
        b'expandable_segments', b'pinned_use_cuda_host_register',
        b'pinned_num_register_threads', b'pinned_use_background_threads',
        b'graph_capture_record_stream_reuse', b'per_process_memory_fraction',
    }
    return raw.decode() if valid and set(re.findall(rb'(?<![\d>])([A-Za-z_][A-Za-z_0-9]*):', raw)) <= known else UNKNOWN


def live_allocator(state, kit):
    """Accept only the original run's exact live trainer descended from its controller."""
    pid = state.get('controller_pid')
    if type(pid) is not int or pid <= 0:
        return UNKNOWN
    proc = Path('/proc')
    controller = proc / str(pid)
    identity = proc_identity(controller)
    args = process_args(controller)
    stage = os.fsencode(kit / 'a_group_formal_v1/formal_stage.py')
    trainer = os.fsencode(kit / 'a_group_formal_v1/formal_trainer.py')
    if identity is None or stage not in args[:3] or b'a_formal_v1' not in args:
        return UNKNOWN
    values = []
    for child in proc.iterdir():
        if not child.name.isascii() or not child.name.isdigit() or trainer not in process_args(child)[:3]:
            continue
        expected = proc_identity(child)
        cursor = expected
        while cursor and cursor[0] > 1 and cursor[0] != pid:
            parent = proc_identity(proc / str(cursor[0]))
            if not parent or parent[1] > cursor[1]:
                break
            cursor = parent
        if not cursor or cursor[0] != pid:
            continue
        try:
            raw = (child / 'environ').read_bytes().split(b'\0')
        except OSError:
            continue
        if (proc_identity(child) != expected or proc_identity(controller) != identity
                or trainer not in process_args(child)[:3]):
            continue
        prefix = b'PYTORCH_CUDA_ALLOC_CONF='
        settings = [part[len(prefix):] for part in raw if part.startswith(prefix)]
        if len(settings) == 1:
            values.append(allocator_value(settings[0]) if settings[0] else '空值')
        elif not settings:
            values.append('未设置')
    return values[0] if len(values) == 1 else UNKNOWN


def recorded_yaml(work):
    candidates = [work / '.hydra/config.yaml', *work.glob('outputs/*/*/.hydra/config.yaml')]
    paths = [p for p in candidates if p.is_file() and not p.is_symlink()]
    if len(paths) != 1:
        return {}
    try:
        from omegaconf import OmegaConf
        config = OmegaConf.load(paths[0])
        return {key: value for index, key in enumerate(CONFIG)
                if type(value := OmegaConf.select(config, key)) is (bool if index < 4 else int)}
    except Exception:
        return {}


def frozen_recipe(root, kit, work):
    """Resolve the previously deployed four-card recipe, not the new checkout."""
    try:
        config = importlib.import_module('formal_config')
        if (Path(config.__file__).resolve().parent != kit / 'a_group_formal_v1'
                or config.c.ROOT.resolve() != root or config.TUTOR_COUNT != 2):
            return {}
        ray = Path(read_text(work / 'ray_tmp_path.txt').strip()).resolve(strict=True)
        if ray.parent != root or not re.fullmatch(r'r[0-9a-f]{6}', ray.name):
            return {}
        interaction = work / 'interaction_b.yaml'
        if not interaction.is_file():
            return {}
        resolved = config.compose(kit / 'a_group_formal_v1/formal_trainer.py', work,
                                  config.overrides(work, ray, 'llama-student', interaction))
        return selected_config(resolved)
    except Exception:
        return {}


def checkpoint_table(root, kit):
    checkpoint = root / 'formal_a_v1/checkpoints/global_step_5'
    receipt = root / 'formal_a_v1/verified/step_5.json'
    latest = UNKNOWN
    try:
        module = importlib.import_module('checkpoints')
        if Path(module.__file__).resolve().parent != kit / 'a_group_formal_v1':
            raise ImportError
        store = module.Store(root / 'formal_a_v1')
        checkpoint, receipt = store.checkpoint(5), store.receipt(5)
        accepted = store.accepted()
        if accepted:
            store.check_existing()
            store.input(accepted[-1])
            latest = accepted[-1]
        else:
            latest = '无'
    except Exception:
        pass
    return [('第5步目录', '存在' if checkpoint.is_dir() else '未发现'),
            ('第5步验收回执', '存在' if receipt.is_file() else '未发现'),
            ('最近通过文件核对的正式检查点', latest)]


def warnings(root, kit, work):
    versions = []
    for package in PACKAGES:
        try:
            version = metadata.version(package)
            version = version if re.fullmatch(r'[0-9A-Za-z][0-9A-Za-z.+!_-]{0,100}', version) else UNKNOWN
        except metadata.PackageNotFoundError:
            version = '未发现'
        versions.append((package, version))
    table('当前诊断解释器中的包版本', ('包', '版本'), versions)
    workers = []
    try:
        audit = importlib.import_module('audit_posthoc')
        if Path(audit.__file__).resolve().parent == kit / 'a_group_b_native_v1':
            workers, _, _ = audit.ray_logs(root, work)
    except Exception:
        pass
    output = []
    for title, paths in (('训练器', [work / 'trainer.log']), ('Ray worker', workers)):
        files = hits = 0
        for path in paths:
            try:
                with path.open('rb') as file:
                    hits += sum(FALLBACK in line for line in file)
                files += 1
            except OSError:
                continue
        output.append((title, files, hits if files else UNKNOWN))
    table('训练文件已有线性注意力回退警告', ('来源', '成功读取文件', '警告行数'), output)


def current_gpus(kit):
    try:
        resources = importlib.import_module('resources')
        if Path(resources.__file__).resolve().parent != kit / 'a_group_b_native_v1':
            raise ImportError
        monitor = resources.load_stage_a()
        cards = monitor.snapshot()
        rows = [(index, card['free'], len(card['apps']), '是' if monitor.eligible(card) else '否')
                for index, card in sorted(cards.items())]
    except Exception:
        rows = [(UNKNOWN,) * 4]
    table('当前显卡整卡条件', ('GPU', '空闲显存 MiB', '计算进程数', '满足整卡条件'), rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--old-kit', type=Path, default=OLD_KIT)
    args = parser.parse_args()
    root, kit = args.root.resolve(), args.old_kit.resolve()
    work = root / 'pilots/a_formal_v1'
    os.environ['EDU_FORMAL_PROFILE'] = 'four'
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    sys.path[:0] = [str(kit / 'a_group_formal_v1'), str(kit / 'a_group_b_native_v1')]
    state = object_from(read_text(work / 'orchestration.json'))
    phase = state.get('phase')
    phase = phase if phase in ('准备', '配置预检', '凑卡', '训练中', '失败', '完成', '服务收尾', 'CPU合并') else UNKNOWN
    trigger = state.get('protected_gpu')
    reason = state.get('reason')
    category = reason if reason in ('学生共享卡显存保护触发或状态未知', '本任务服务异常退出',
                                    '训练进程退出失败', '收到停止信号') else ('无' if reason == '' else UNKNOWN)
    table('四卡正式尝试', ('项目', '状态'), [
        ('阶段', phase), ('原因类别', category), ('保护触发卡', trigger if type(trigger) is int else UNKNOWN),
        *checkpoint_table(root, kit),
    ])
    marks, config = read_trainer(work / 'trainer.log')
    metrics, windows = progress(work, marks)
    table('每步计时（秒）', ('步', *TIMES),
          [(step, *(number(metrics[step].get(key)) for key in TIMES)) for step in STEPS])
    table('第 1–4 步 actor、内存与 token 指标', ('指标', '第1步', '第2步', '第3步', '第4步'),
          [(key, *(number(metrics[step].get(key)) for step in range(1, 5))) for key in PERF])
    warnings(root, kit, work)
    snapshot_host()
    gpu_bindings = state.get('bindings')
    cards = [(role, gpu) for role in ('tutor', 'student')
             for gpu in (gpu_bindings.get(role, []) if isinstance(gpu_bindings, dict)
                         and isinstance(gpu_bindings.get(role), list) else [])
             if type(gpu) is int and gpu >= 0]
    history_counts = history(work, windows, cards)
    gpu_rows = []
    for step in range(1, 5):
        window = windows.get(step)
        for role, gpu in cards:
            count = history_counts[step, gpu] if history_counts is not None else Counter()
            sampled = history_counts is not None and window is not None
            possible = count['samples']
            busy = count['external_busy'] if possible and count['external_known'] == possible else UNKNOWN
            utilization = count['util_count']
            gpu_rows.append((step, {'tutor': 'Tutor', 'student': '学生'}[role], gpu,
                             window[2] if window else UNKNOWN, possible if sampled else UNKNOWN,
                             count['verified'] if sampled else UNKNOWN, busy,
                             utilization if sampled else UNKNOWN,
                             round(count['util_total'] / utilization, 2) if utilization else UNKNOWN,
                             count['util_peak'] if utilization else UNKNOWN))
    table('历史每 10 秒 GPU 采样', ('步', '角色', 'GPU', '窗口来源', '采样数',
          '归属可核验数', '其他进程出现次数', '利用率样本数', '平均利用率%', '峰值利用率%'),
          gpu_rows or [(UNKNOWN,) * 10])
    print('其他进程出现次数按采样时点统计。原始记录若只保存本任务归属和显存，外部进程与利用率记为未知。')
    yaml = recorded_yaml(work) if not all(key in config for key in CONFIG) else {}
    frozen = frozen_recipe(root, kit, work) if not all(key in config or key in yaml for key in CONFIG) else {}
    config_rows = []
    for key in CONFIG:
        value, source = UNKNOWN, '历史文件中未找到'
        for candidate, label in ((config, 'veRL TaskRunner 实际解析配置'), (yaml, '本次 Hydra 文件'),
                                 (frozen, '旧包当前重算，历史实参未存')):
            if key in candidate:
                value, source = candidate[key], label
                break
        config_rows.append((key, str(value).lower() if type(value) is bool else value, source))
    allocator = live_allocator(state, kit)
    config_rows.append(('PYTORCH_CUDA_ALLOC_CONF', allocator,
                        '原四卡训练进程已核对' if allocator != UNKNOWN else '原进程环境无可核验证据'))
    table('四卡训练配置', ('项目', '值', '证据'), config_rows)
    current_gpus(kit)


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    main()
