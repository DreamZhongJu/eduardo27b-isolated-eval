"""Check a stopped four-card run and record approval for a new six-card run."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import fcntl
import json
import os
from pathlib import Path
import re
import socket
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'a_group_speed_v2'))
sys.path.insert(0, str(HERE.parent / 'a_group_b_native_v1'))

import resources
import switch


ROOT = switch.ROOT
PROC = switch.PROC
OLD_KIT = switch.OLD_KIT
CONFIRM = 'RESTART6'
RECEIPT = 'a-restart-v3-start.json'
CANDIDATE_RUN = 'a_restart_v3'
CANDIDATE_SERIES = 'formal_a_restart_v3'
VERIFIED_NAME = re.compile(r'step_([1-9][0-9]*)\.json\Z')


@dataclass(frozen=True)
class Ready:
    completed: int
    evidence: int
    rollback: int
    cards: tuple[int, ...]


def processes_idle(root, proc, kit):
    # On a shared filesystem flock(LOCK_EX) can require a writable descriptor.
    # An existing lock is opened without creating, truncating or writing it.
    try:
        lock = os.open(root / '.pilot.lock', os.O_RDWR | os.O_NOFOLLOW)
    except OSError:
        raise switch.SwitchRefused('A组控制器锁不可读取') from None
    try:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise switch.SwitchRefused('A组锁仍有控制器持有') from None
    finally:
        os.close(lock)
    old_scripts = {
        str(kit / 'a_group_formal_v1/formal_stage.py'),
        str(kit / 'a_group_b_native_v1/parent_guard.py'),
        str(kit / 'a_group_b_native_v1/resources.py'),
    }
    try:
        for folder in proc.iterdir():
            if not folder.name.isdecimal():
                continue
            identity = switch.process(proc, int(folder.name))
            if (identity is not None and identity.status not in ('Z', 'X', 'x')
                    and old_scripts.intersection(identity.argv)):
                raise switch.SwitchRefused('原四卡控制器、守护或占位进程仍在运行')
    except OSError:
        raise switch.SwitchRefused('当前容器进程不可核验') from None
    if switch.running_known_evaluations(proc):
        raise switch.SwitchRefused('发现仍在运行的27B评测进程')


def ports_idle():
    for port in (18861, 18862):
        try:
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', port))
        except OSError:
            raise switch.SwitchRefused('原学生或裁判端口仍在使用') from None


def preflight(root=ROOT, proc=PROC, kit=OLD_KIT, *, load_cards=resources.load_stage_a,
              sleep=time.sleep, check_ports=ports_idle):
    work = root / 'pilots' / switch.RUN
    if work.is_symlink() or (root / 'pilots').is_symlink():
        raise switch.SwitchRefused('原运行或试点目录身份异常')
    if not (kit / 'a_group_formal_v1/start_formal.sh').is_file():
        raise switch.SwitchRefused('原四卡冻结启动器缺失')
    candidate_paths = (root / 'pilots' / CANDIDATE_RUN, root / CANDIDATE_SERIES,
                       root / RECEIPT, root / switch.RECEIPT)
    if any(path.exists() or path.is_symlink() for path in candidate_paths):
        raise switch.SwitchRefused('已有候选运行、系列或一次性切换记录')
    state = switch.read_object(work / 'orchestration.json')
    pid = state.get('controller_pid')
    if state.get('phase') not in ('失败', '已停止') or type(pid) is not int or pid < 2:
        raise switch.SwitchRefused('原四卡未记录为已停止的终止态')
    processes_idle(root, proc, kit)
    check_ports()

    store = root / 'formal_a_v1'
    verified = store / 'verified'
    if verified.is_symlink():
        raise switch.SwitchRefused('已验收检查点目录身份异常')
    completed, evidence = switch.observed_steps(work, store)
    published = max((int(match[1]) for path in verified.glob('step_*.json')
                     if (match := VERIFIED_NAME.fullmatch(path.name))), default=0)
    if max(evidence, published) >= switch.CUTOFF:
        raise switch.SwitchRefused('原正式训练已达到第20步边界')
    if published > evidence:
        raise switch.SwitchRefused('已验收检查点缺少对应步号或目录证据')
    rollback = switch.rollback_checkpoint(store, max(completed, published))
    if rollback < published:
        raise switch.SwitchRefused('最新已验收检查点目录缺失')

    stage_a = load_cards()
    first = stage_a.snapshot()
    sleep(5)
    second = stage_a.snapshot()
    cards = tuple(binding.index for binding in resources.choose_candidates(
        stage_a, 'student', first, second, set(), student_full=True))
    distinct = {second[i]['uuid'] for i in cards}
    if len(distinct) < 6:
        raise switch.SwitchRefused(f'仅核实{len(distinct)}张空闲整卡，需6张')
    processes_idle(root, proc, kit)
    check_ports()
    return Ready(completed, evidence, rollback, tuple(sorted(cards)))


def record_start(root=ROOT, proc=PROC, kit=OLD_KIT, *, confirm=None, deferred=False,
                 launch_options=None, **preflight_options):
    if confirm != CONFIRM or not deferred:
        raise switch.SwitchRefused('需要明确批准六卡重启及确认27B评测延期')
    options = launch_options or {}
    if options and (set(options) != {'optimizer_offload', 'kernel', 'profile_step2'}
                    or options['kernel'] not in ('baseline', 'fast')
                    or type(options['optimizer_offload']) is not bool
                    or type(options['profile_step2']) is not bool):
        raise switch.SwitchRefused('六卡重启选项无效')
    lock = os.open(root / '.a-restart-v3-gate.lock',
                   os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise switch.SwitchRefused('另一六卡重启操作正在核验') from None
        ready = preflight(root, proc, kit, **preflight_options)
        path = root / RECEIPT
        with path.open('x', encoding='utf-8') as stream:
            json.dump({
                'phase': '原正式训练已退出',
                'kind': '终止态六卡重启',
                'completed_step': ready.completed,
                'latest_step_evidence': ready.evidence,
                'rollback_step': ready.rollback,
                'eligible_gpu': ready.cards,
                '27b_deferred_confirmed': True,
                **options,
            }, stream, ensure_ascii=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        return ready
    finally:
        os.close(lock)


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--check', action='store_true')
    action.add_argument('--record-start', action='store_true')
    parser.add_argument('--confirm')
    parser.add_argument('--confirm-27b-deferred', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    try:
        if args.check:
            ready = preflight()
        else:
            ready = record_start(confirm=args.confirm, deferred=args.confirm_27b_deferred)
    except (switch.SwitchRefused, resources.ResourceError) as exc:
        print('预检未通过', str(exc), file=sys.stderr)
        return 1
    except (OSError, RuntimeError, TypeError, ValueError):
        print('预检未通过：进程、回执或显卡状态无法核实', file=sys.stderr)
        return 1
    print('原四卡最近完成步', ready.completed)
    print('四卡回退检查点步', ready.rollback)
    print('当前空闲整卡', ' '.join(map(str, ready.cards)))
    print('六卡重启批准已记录' if args.record_start else '只读预检通过，等待批准')
    return 0


if __name__ == '__main__':
    sys.exit(main())
