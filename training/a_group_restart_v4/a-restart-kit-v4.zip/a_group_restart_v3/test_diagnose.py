from contextlib import redirect_stdout
from io import StringIO
import json
import os
from pathlib import Path
from pprint import pformat
import tempfile
import unittest
from unittest.mock import patch

import diagnose as diag


class DiagnoseTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)

    def test_native_step_line_and_resolved_config(self):
        path = self.root / 'trainer.log'
        config = {
            'actor_rollout_ref': {
                'actor': {'fsdp_config': {'param_offload': False, 'optimizer_offload': True},
                          'ppo_micro_batch_size_per_gpu': 1},
                'model': {'enable_gradient_checkpointing': True, 'use_remove_padding': True},
            },
            'vars': {'secret': 'NOT-FOR-OUTPUT' * 8},
        }
        prefix = '\x1b[36m(TaskRunner pid=123)\x1b[0m '
        fragments = [
            'TaskRunner hostname: private-host, PID: 123',
            *pformat(config).splitlines(),
            'step:1 - timing_s/step:11.25 - perf/throughput:np.float64(10.5) - training/global_step:1',
            'step:1 - perf/total_num_tokens:np.int64(801) - training/global_step:1',
            'step:1 - timing_s/gen:191 - training/global_step:2',
            'step:2 - timing_s/gen:4 - training/global_step:2',
            'step:2 - timing_s/gen:5 - training/global_step:2',
            'step:3 - timing_s/update_actor:nan - training/global_step:3',
            'step:4 - timing_s/step:25 - training/global_step:4',
        ]
        path.write_text('\n'.join(prefix + line for line in fragments))
        metrics, found = diag.read_trainer(path)
        self.assertEqual(metrics[1], {'timing_s/step': 11.25, 'perf/throughput': 10.5,
                                      'perf/total_num_tokens': 801})
        self.assertEqual(metrics[2], {})
        self.assertNotIn(3, metrics)
        self.assertEqual(metrics[4]['timing_s/step'], 25)
        self.assertEqual(list(found.values()), [False, True, True, True, 1])
        self.assertNotIn('NOT-FOR-OUTPUT', repr(found))

    def test_step_bounds_exclude_adjacent_windows_and_mismatched_receipts(self):
        d = self.root / 'step-statistics'
        d.mkdir()
        row = {'step': 1, 'data_batches': 1, 'metrics': {'timing_s/step': 40}, 'unrelated': 'PRIVATE'}
        one = d / '1.json'
        one.write_text(json.dumps(row))
        os.utime(one, (100, 100))
        two = d / '2.json'
        row.update(step=2, data_batches=2, window_start_at=103, window_end_at=170)
        two.write_text(json.dumps(row))
        row.update(step=3, data_batches=4)
        (d / '3.json').write_text(json.dumps(row))
        metrics, windows = diag.progress(self.root, {1: {'perf/total_num_tokens': 128}})
        self.assertEqual(windows[1][:2], (60, 100))
        self.assertEqual(windows[2][:2], (103, 170))
        self.assertNotIn(3, windows)
        self.assertEqual(metrics[1]['perf/total_num_tokens'], 128)
        self.assertNotIn('unrelated', metrics[1])

        old_sample = {'verified': False, 'known_lower_bound_mib': 40000, 'unmapped_pids': [8]}
        samples = [
            {'time': 60, 'gpus': {'5': old_sample}},
            {'time': 95, 'gpus': {'5': {'verified': True, 'mib': 55000}}},
            {'time': 100, 'gpus': {'5': old_sample}},
            {'time': 102, 'gpus': {'5': old_sample}},
            {'time': 103, 'gpus': {'5': {'verified': True, 'external_process_count': 1, 'utilization': 90}}},
            {'time': 168, 'gpus': {'5': {'verified': True, 'external_process_count': 0, 'utilization': 80}}},
            {'time': 170, 'gpus': {'5': old_sample}},
        ]
        file = self.root / 'gpu_samples.jsonl'
        file.write_text('\n'.join(map(json.dumps, samples)))
        stats = diag.history(self.root, windows, [('student', 5)])
        self.assertEqual(stats[1, 5]['samples'], 2)
        self.assertEqual(stats[1, 5]['verified'], 1)
        self.assertEqual(stats[1, 5]['external_known'], 0)
        self.assertEqual(stats[1, 5]['util_count'], 0)
        self.assertEqual(stats[2, 5]['samples'], 2)
        self.assertEqual(stats[2, 5]['external_known'], 2)
        self.assertEqual(stats[2, 5]['external_busy'], 1)
        self.assertEqual(stats[2, 5]['util_total'], 170)
        file.unlink()
        self.assertIsNone(diag.history(self.root, windows, [('student', 5)]))

    def test_cgroup_mount_binding(self):
        proc = self.root / 'proc'
        mount = self.root / 'cg'
        (proc / 'self').mkdir(parents=True)
        (mount / 'bound').mkdir(parents=True)
        (proc / 'self/mountinfo').write_text(f'9 8 0:4 /scope {mount} rw - cgroup2 cgroup rw\n')
        (proc / 'self/cgroup').write_text('0::/scope/bound\n')
        self.assertEqual(diag.cgroup_directory(proc, mount), mount / 'bound')
        (proc / 'self/cgroup').write_text('0::/other/bound\n')
        self.assertIsNone(diag.cgroup_directory(proc, mount))

    def test_allocator_only_validated_known_value(self):
        self.assertEqual(diag.allocator_value(b'backend:native,expandable_segments:True'),
                         'backend:native,expandable_segments:True')
        self.assertEqual(diag.allocator_value(b'roundup_power2_divisions:[256:1,512:2,>:8]'),
                         'roundup_power2_divisions:[256:1,512:2,>:8]')
        self.assertEqual(diag.allocator_value(b'unknown:1'), diag.UNKNOWN)
        self.assertEqual(diag.allocator_value(b'backend:PRIVATE_TOKEN'), diag.UNKNOWN)

    def test_terminal_output_uses_allowlisted_values(self):
        work = self.root / 'pilots/a_formal_v1'
        work.mkdir(parents=True)
        state = {'phase': 'PRIVATE_LOG', 'reason': 'SECRET_REASON', 'protected_gpu': 5}
        (work / 'orchestration.json').write_text(json.dumps(state))
        buffer = StringIO()
        argv = ['diagnose.py', '--root', str(self.root), '--old-kit', str(self.root / 'kit')]
        with patch.object(diag.sys, 'argv', argv), patch.object(diag, 'snapshot_host'), redirect_stdout(buffer):
            diag.main()
        result = buffer.getvalue()
        self.assertIn('| 保护触发卡 | 5 |', result)
        self.assertNotIn('PRIVATE_LOG', result)
        self.assertNotIn('SECRET_REASON', result)


if __name__ == '__main__':
    unittest.main()
