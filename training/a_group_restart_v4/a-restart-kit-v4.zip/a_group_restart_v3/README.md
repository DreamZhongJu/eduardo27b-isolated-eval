# A 组六卡重启候选

压缩包放到容器 `/workspace/a-restart-kit-v3.zip`，校验后解到 `/workspace/a-restart-kit-v3`。使用既有 Python。只读诊断默认检查四卡旧目录。

```bash
r=/workspace/A_group_repro_20261117
p=/workspace/a-restart-kit-v3/a_group_restart_v3
py="$r/envs/env-candidate-vllm0191/bin/python"
"$py" -B "$p/diagnose.py"
"$py" -B "$p/restart.py" --check
```

批准后且六张整卡就绪，通过下列单独命令从步 0 启动。若旧诊断无法识别瓶颈，批准时追加 `--profile-step2`。只有同批 GPU 对照通过，才使用 `--kernel fast`。

```bash
/workspace/A_group_repro_20261117/envs/env-candidate-vllm0191/bin/python -B \
  /workspace/a-restart-kit-v3/a_group_restart_v3/restart.py \
  --start --confirm RESTART6 --confirm-27b-deferred
```

同一程序加 `--status` 可看两步计时和逐卡峰值。当前宿主机和其他容器的并行作业情况须在审批时核对。运行及评估数据保存在站内。
