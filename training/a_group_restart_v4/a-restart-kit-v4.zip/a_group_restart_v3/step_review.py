"""Numeric first-two-step reports and conservative degradation detection."""
import json
import math


def restart_comparison(first, second):
    before, after = first.get('actor_rpc_s'), second.get('actor_rpc_s')
    if not all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in (before, after)):
        raise ValueError('第1和2步缺少可比较的原生 actor 计时')
    # Both a relative and an absolute increase must be meaningful.
    return {'first_actor_rpc_s': before, 'second_actor_rpc_s': after, 'ratio': after / before,
            'increase_s': after - before, 'slowdown': after >= 1.25 * before and after - before >= 300}


def peak_window(path, start, end):
    high, counts = {}, {}
    try:
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                try:
                    row = json.loads(line)
                    if not start <= row['time'] <= end:
                        continue
                    for gpu, card in row.get('cards', {}).items():
                        total, free = card.get('total_mib'), card.get('free_mib')
                        if type(total) is int and type(free) is int and 0 <= free <= total:
                            high[gpu] = max(high.get(gpu, 0), total - free)
                            counts[gpu] = counts.get(gpu, 0) + 1
                except (TypeError, ValueError, KeyError, AttributeError):
                    continue
    except OSError:
        pass
    return {gpu: {'peak_mib': value, 'samples': counts[gpu]} for gpu, value in high.items()}
