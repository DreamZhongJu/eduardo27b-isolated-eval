"""Optional 30-second system profile during the second actor update."""
import json
import os
from pathlib import Path
import subprocess
import threading
import time


def counters(path, names):
    try:
        rows = dict(line.split()[:2] for line in path.read_text().splitlines() if len(line.split()) >= 2)
        return {name: int(rows[name]) for name in names if name in rows}
    except (OSError, ValueError):
        return {}


def nvml(gpus):
    args = ['nvidia-smi', '--query-gpu=index,memory.used,utilization.gpu,utilization.memory',
            '--format=csv,noheader,nounits']
    try:
        result = subprocess.run(args, text=True, capture_output=True, timeout=3, check=True)
        rows = [line.split(',') for line in result.stdout.splitlines()]
        return {int(row[0]): list(map(int, row[1:])) for row in rows
                if len(row) == 4 and int(row[0]) in gpus}
    except (OSError, ValueError, subprocess.SubprocessError):
        return {}


def sample_profile(path, gpus, end):
    with path.open('x', encoding='utf-8') as stream:
        while time.monotonic() < end:
            row = {
                'time': time.time(), 'gpu': nvml(gpus), 'load': os.getloadavg(),
                'cpu': counters(Path('/sys/fs/cgroup/cpu.stat'), ('usage_usec', 'throttled_usec')),
                'memory': counters(Path('/sys/fs/cgroup/memory.stat'), ('anon', 'pgmajfault')),
                'vm': counters(Path('/proc/vmstat'), ('pswpin', 'pswpout')),
            }
            stream.write(json.dumps(row) + '\n')
            stream.flush()
            time.sleep(1)


def start_if_due(work, gpus):
    if not gpus or (work / 'step-statistics/2.json').exists():
        return None
    try:
        marker = json.loads((work / 'profile-step2-ready.json').read_text())
        started = marker['monotonic']
    except (OSError, ValueError, KeyError, TypeError):
        return None
    now = time.monotonic()
    if type(started) not in (int, float) or not 0 <= now - started <= 35:
        return None
    thread = threading.Thread(target=sample_profile, args=(work / 'step2-system-profile.jsonl', tuple(gpus), now + 30),
                              daemon=True)
    thread.start()
    return thread
