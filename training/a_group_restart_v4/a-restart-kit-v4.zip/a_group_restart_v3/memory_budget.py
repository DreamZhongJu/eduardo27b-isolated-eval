"""CPU estimate of the minimum whole-card layout for this candidate."""
from dataclasses import dataclass
import math

GIB = 1024 ** 3
MODEL_PARAMETERS = 4_659_865_088
VOCAB = 248_320
HIDDEN = 2560
LAYERS = 32
MAX_SEQUENCE = 10240
TUTOR_FRACTION = 0.58
JUDGE_FRACTION = 0.86
STUDENT_FRACTION = 0.4
RUNTIME_RESERVE = 8.0
UNMEASURED_ALLOWANCE = 10.0


@dataclass(frozen=True)
class Budget:
    update: float
    rollout: float
    weight_sync: float

    @property
    def peak(self):
        return max(self.update, self.rollout, self.weight_sync)


def estimate(device_gib, optimizer_offload):
    if not math.isfinite(device_gib) or device_gib <= 0:
        raise ValueError('显存总量异常')
    master = MODEL_PARAMETERS * 4 / (4 * GIB)
    model_bf16 = MODEL_PARAMETERS * 2 / GIB
    adam = 2 * master
    logits = MAX_SEQUENCE * VOCAB * 4 / GIB
    saved_hidden = MAX_SEQUENCE * HIDDEN * LAYERS * 2 / GIB
    update = master + master + adam + model_bf16 + 2 * logits + saved_hidden
    rollout = master + (0 if optimizer_offload else adam) + TUTOR_FRACTION * device_gib
    # Sleep level 2 remaps weights before its transfer and KV after the transfer.
    weight_sync = master + (0 if optimizer_offload else adam) + 2 * model_bf16 + 6
    return Budget(*(value + UNMEASURED_ALLOWANCE for value in (update, rollout, weight_sync)))


def choose_optimizer_offload(device_gib):
    for offload in (False, True):
        if device_gib - estimate(device_gib, offload).peak >= RUNTIME_RESERVE:
            return offload
    raise ValueError('显存估算无法满足 8 GiB 余量')


def print_budget(device_gib, offload):
    numbers = estimate(device_gib, offload)
    print('Tutor 每卡显存 GiB', f'更新 {numbers.update:.2f}', f'rollout {numbers.rollout:.2f}',
          f'权重同步 {numbers.weight_sync:.2f}', f'估算余量 {device_gib - numbers.peak:.2f}')
    print('优化器 CPU 卸载', '开' if offload else '关')
    print('裁判 vLLM 预算比例', JUDGE_FRACTION, '学生 vLLM 预算比例', STUDENT_FRACTION,
          '显存保护余量 GiB', RUNTIME_RESERVE)
