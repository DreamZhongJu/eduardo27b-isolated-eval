"""Explicitly approved six-card restart from step zero."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
for folder in ('a_group_speed_v2', 'a_group_formal_v1', 'a_group_b_native_v1'):
    sys.path.insert(0, str(HERE.parent / folder))

import memory_budget as memory
import restart_control as gate
import switch

WORK = gate.ROOT / 'pilots' / gate.CANDIDATE_RUN
OLD_WORK = gate.ROOT / 'pilots' / switch.RUN
FORMAL = HERE.parent / 'a_group_formal_v1'


def output(ready):
    print('原四卡最近完成步', ready.completed)
    print('最近通过文件校验的四卡检查点', ready.rollback or '无')
    print('两次采样均为空闲的整卡', ' '.join(map(str, ready.cards)))


def check(args):
    ready = gate.preflight()
    output(ready)
    if shutil.disk_usage(gate.ROOT).free < 150_000_000_000:
        raise switch.SwitchRefused('可用磁盘少于150 GB')
    # Resource validation admits only totals of at least 78,000 MiB. A
    # different valid card may be selected if availability changes.
    capacity = 78_000 / 1024
    offload = memory.choose_optimizer_offload(capacity)
    memory.print_budget(capacity, offload)
    os.environ.update(EDU_FORMAL_PROFILE='restart_v3', EDU_FORMAL_KERNEL=args.kernel,
                      EDU_RESTART_OPTIMIZER_OFFLOAD=str(offload).lower(),
                      EDU_RESTART_PROFILE_STEP2=str(int(args.profile_step2)))
    import formal_config as cfg
    import speed_checks

    student = 'Llama-3.1-8B-Instruct-' + (os.environ.get('USER') or 'root')
    interaction = WORK / 'interaction_b.yaml'
    raytmp = gate.ROOT / 'r000000'
    settings = [cfg.overrides(WORK, raytmp, student, interaction, speed=False, restart=False),
                cfg.overrides(WORK, raytmp, student, interaction)]
    baseline, candidate = (cfg.compose(FORMAL / 'formal_trainer.py', WORK, flags) for flags in settings)
    cfg.pin_composed(candidate, WORK, student, interaction)
    changes = {key for key, _, _ in cfg.diff(baseline, candidate)}
    allowed = set(speed_checks.PROFILE_KEYS)
    if not offload:
        allowed.add('actor_rollout_ref.actor.fsdp_config.optimizer_offload')
    if changes != allowed:
        raise switch.SwitchRefused('六卡配置存在计划外差异')
    print('Hydra 核验通过，实际差异项目数', len(changes))
    speed_checks.baseline_row(gate.ROOT)
    if args.kernel == 'fast':
        speed_checks.verify_fast_environment()
    return {'optimizer_offload': offload, 'kernel': args.kernel, 'profile_step2': args.profile_step2}, cfg.c.PYTHON


def status():
    state = switch.read_object(WORK / 'orchestration.json', missing={})
    phase = state.get('phase')
    print('六卡阶段', phase if phase in ('准备', '凑卡', '训练中', '失败', '服务收尾', '完成') else '暂无')
    protected = state.get('protected_gpu')
    print('保护触发卡', protected if type(protected) is int else '—')
    known_reasons = ('第2步原生Tutor更新明显变慢', '本任务显卡剩余显存低于保护阈值',
                     '本任务显卡状态连续3次采样异常', '六张空闲整卡未同时到位',
                     '六张整卡预留发生竞争')
    failure = switch.read_object(WORK / 'failure.json', missing={})
    reason = failure.get('reason') or state.get('reason')
    if phase == '失败':
        print('原因', reason if reason in known_reasons else '查看站内固定异常分类')
    layout = switch.read_object(WORK / 'rollout-layout.json', missing={})
    print('rollout TP / 副本', layout.get('tensor_parallel', '—'), layout.get('replicas', '—'))
    tutors = state.get('bindings', {}).get('tutor', [])
    print('| 步 | step 秒 | gen 秒 | update_actor 秒 | 原生更新秒 | Tutor 各卡整卡峰值 MiB（样本数） |')
    print('|---:|---:|---:|---:|---:|:---|')
    def number(x):
        return f'{x:.2f}' if type(x) in (int, float) else '—'
    for step in (1, 2):
        row = switch.read_object(WORK / f'step-statistics/{step}.json', missing={})
        metrics = row.get('metrics', {})
        peaks = row.get('gpu_peaks', {})
        cells = []
        for gpu in tutors:
            card = peaks.get(str(gpu), {})
            cells.append(f'GPU {gpu} {card["peak_mib"]}（{card["samples"]}）' if card else f'GPU {gpu} —')
        numbers = [number(metrics.get(f'timing_s/{key}')) for key in ('step', 'gen', 'update_actor')]
        columns = [str(step), *numbers, number(row.get('actor_rpc_s')), '、'.join(cells) or '—']
        print('| ' + ' | '.join(columns) + ' |')
    comparison = switch.read_object(WORK / 'restart-step2-comparison.json', missing={})
    if comparison:
        print('第2步原生更新减慢', '达到停止条件' if comparison['slowdown'] else '未达停止条件',
              '倍数', number(comparison.get('ratio')))
    profile = WORK / 'step2-system-profile.jsonl'
    if profile.is_file():
        with profile.open('rb') as stream:
            print('第2步系统采样条数', sum(1 for _ in stream))


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--check', action='store_true')
    action.add_argument('--start', action='store_true')
    action.add_argument('--status', action='store_true')
    parser.add_argument('--kernel', choices=('baseline', 'fast'), default='baseline')
    parser.add_argument('--profile-step2', action='store_true')
    parser.add_argument('--confirm')
    parser.add_argument('--confirm-27b-deferred', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    try:
        if args.status:
            status()
            return 0
        if args.start and (args.confirm != gate.CONFIRM or not args.confirm_27b_deferred):
            raise switch.SwitchRefused('启动需要用户批准并确认27B评测延期')
        options, original_python = check(args)
        if args.check:
            print('只读检查结束，等待启动批准')
            return 0
        gate.record_start(confirm=args.confirm, deferred=args.confirm_27b_deferred, launch_options=options)
        with WORK.with_name(f'{WORK.name}-launch.log').open('xb') as log:
            subprocess.Popen([str(original_python), '-B', str(FORMAL / 'formal_stage.py'),
                              '--run', '--name', gate.CANDIDATE_RUN],
                             stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                             start_new_session=True)
        print('六卡启动器已提交后台，等待整卡交接和第1步回执')
        return 0
    except switch.SwitchRefused as exc:
        print('六卡重启未提交', str(exc))
    except Exception as exc:
        print('六卡重启未提交', type(exc).__name__)
    return 1


if __name__ == '__main__':
    sys.exit(main())
