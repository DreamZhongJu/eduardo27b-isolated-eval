import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import memory_budget as m
from step_review import peak_window, restart_comparison


class MemoryBudgetTests(unittest.TestCase):
    def test_80g_rollout_is_the_peak(self):
        v = m.estimate(80, False)
        self.assertAlmostEqual(v.rollout, 69.42, places=2)
        self.assertEqual(v.peak, v.rollout)
        self.assertGreater(80 - v.peak, 8)
        self.assertFalse(m.choose_optimizer_offload(80))

    def test_offload_retained_when_margin_requires_it(self):
        self.assertTrue(m.choose_optimizer_offload(70))
        with self.assertRaisesRegex(ValueError, '余量'):
            m.choose_optimizer_offload(60)

    def test_guard_minimum_candidate_and_judge_budget(self):
        cap = 78_000 / 1024
        self.assertFalse(m.choose_optimizer_offload(cap))
        self.assertGreater(cap * (1 - m.JUDGE_FRACTION), m.RUNTIME_RESERVE)


class StepReviewTest(unittest.TestCase):
    def test_slowdown_uses_native_rpc_and_both_margins(self):
        r = lambda n: {'actor_rpc_s': n}
        self.assertFalse(restart_comparison(r(1800), r(1900))['slowdown'])
        self.assertFalse(restart_comparison(r(400), r(650))['slowdown'])
        self.assertFalse(restart_comparison(r(1700), r(2070))['slowdown'])
        self.assertTrue(restart_comparison(r(1700), r(2200))['slowdown'])
        with self.assertRaisesRegex(ValueError, '计时'):
            restart_comparison(r(1700), {})

    def test_peak_respects_time_window_and_sample_coverage(self):
        with TemporaryDirectory() as d:
            path = Path(d) / 'gpu.jsonl'
            rows = [
                {'time': t, 'cards': {'7': {'free_mib': free, 'total_mib': 81920}}}
                for t, free in [(1, 1), (10, 50000), (20, 30000), (30, None), (90, 1)]
            ]
            path.write_text('\n'.join(map(json.dumps, rows)))
            self.assertEqual(peak_window(path, 5, 40), {'7': {'peak_mib': 51920, 'samples': 2}})
