"""Read package metadata or verify an already built training-only environment."""
import argparse
from importlib import metadata
from pathlib import Path
import platform
import sys


PACKAGES = ('transformers', 'flash-attn', 'flash-linear-attention', 'fla-core', 'causal-conv1d')
NEEDLE = b'The fast path is not available because one of the required library is not installed'


def probe(work):
    for name in PACKAGES:
        try:
            version = metadata.version(name)
        except metadata.PackageNotFoundError:
            version = '未发现安装包'
        print(name, version)
    workers = []
    try:
        ray = Path((work / 'ray_tmp_path.txt').read_text().strip())
        folder = ray / 'session_latest' / 'logs'
        workers = sorted({*folder.glob('worker-*.out'), *folder.glob('worker-*.err')})
    except OSError:
        pass
    for label, paths in (('训练器日志', [work / 'trainer.log']), ('Ray worker 日志', workers)):
        readable = hits = 0
        for path in paths:
            try:
                with path.open('rb') as source:
                    hits += sum(NEEDLE in line for line in source)
            except OSError:
                continue
            readable += 1
        print(label, '可读文件', readable, '警告行', hits if readable else '未知')


def progress(work):
    import json
    import math

    keys = ('timing_s/step', 'timing_s/gen', 'timing_s/update_actor')
    print('| 步 | step 秒 | gen 秒 | update_actor 秒 |')
    print('|---:|---:|---:|---:|')
    for step in (1, 2, 3, 4, 25):
        try:
            row = json.loads((work / 'step-statistics' / f'{step}.json').read_text())
            metrics = row['metrics'] if row['step'] == step else {}
        except (OSError, ValueError, TypeError, KeyError):
            metrics = {}
        values = [metrics.get(key) for key in keys]
        rendered = [f'{x:.2f}' if type(x) in (int, float) and math.isfinite(x) else '暂无' for x in values]
        print(f"| {step} | " + ' | '.join(rendered) + ' |')


def verified_fast():
    # CPU-only check of the environment sealed in the real single-GPU receipt.
    import torch

    good_version = (sys.version_info[:2] == (3, 12) and platform.machine() == 'x86_64'
                    and torch.__version__.split('+')[0] == '2.10.0' and torch.version.cuda == '12.8'
                    and torch.compiled_with_cxx11_abi() and metadata.version('transformers') == '5.7.0'
                    and metadata.version('flash-linear-attention') == '0.5.2'
                    and metadata.version('fla-core') == '0.5.2'
                    and metadata.version('causal-conv1d').split('+')[0] == '1.6.2.post1')
    if not good_version:
        return 1
    print('FAST_IMPORT_OK')
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--work', type=Path, default=Path('/workspace/A_group_repro_20261117/pilots/a_formal_v1'))
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--verify-fast', action='store_true')
    action.add_argument('--progress', action='store_true')
    args = parser.parse_args()
    try:
        if args.verify_fast:
            sys.exit(verified_fast())
        if args.progress:
            progress(args.work)
        else:
            probe(args.work)
    except Exception as e:
        print('只读核查异常', type(e).__name__)
        sys.exit(1)
