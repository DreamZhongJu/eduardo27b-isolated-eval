"""Read-only comparisons and acceptance checks for the six-card candidate."""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
from numbers import Real
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'a_group_formal_v1'))
sys.path.insert(0, str(HERE.parent / 'a_group_b_native_v1'))

import formal_config as cfg


TIME_KEYS = ('timing_s/step', 'timing_s/gen', 'timing_s/update_actor')
QUEUE_GROUPS = ('student_interaction', 'student_final', 'judge')
PROFILE_KEYS = {
    'trainer.n_gpus_per_node',
    'actor_rollout_ref.rollout.n_gpus_per_node',
    'actor_rollout_ref.actor.fsdp_config.fsdp_size',
    'actor_rollout_ref.rollout.tensor_model_parallel_size',
    'trainer.default_local_dir',
    'ray_kwargs.ray_init.runtime_env.worker_process_setup_hook',
    'ray_kwargs.ray_init.runtime_env.env_vars.EDU_QUEUE_METRICS_DIR',
}


class SpeedFailure(RuntimeError):
    pass


def baseline_row(root):
    path = root / 'pilots' / 'a_formal_v1' / 'step-statistics' / '1.json'
    try:
        raw = json.loads(path.read_text())
        if raw.get('step') != 1 or raw.get('data_batches') != 1:
            raise ValueError
        timings(raw['metrics'])
        return raw
    except (OSError, ValueError, KeyError, TypeError):
        raise SpeedFailure('四卡首步原始数值回执缺失') from None


def timings(metrics):
    values = {}
    for key in TIME_KEYS:
        v = metrics.get(key)
        if isinstance(v, bool) or not isinstance(v, Real) or not math.isfinite(v) or v <= 0:
            raise SpeedFailure('首步缺少有效的分段计时')
        values[key] = float(v)
    return values


def assess_first_step(baseline, candidate, queues):
    before, after = timings(baseline), timings(candidate)
    groups = queues.get('groups') or {}
    available = set(groups) == set(QUEUE_GROUPS)
    if available:
        coverage = all(groups[k].get('calls', 0) > 0 for k in ('student_interaction', 'judge'))
        complete = all(queues.get(k) == 0 for k in ('malformed_rows', 'unreadable_files', 'crossing_window'))
        available = coverage and complete
    faster = after[TIME_KEYS[0]] < before[TIME_KEYS[0]]
    return {
        'baseline': before, 'candidate': after, 'queue': queues,
        'step_delta_s': after[TIME_KEYS[0]] - before[TIME_KEYS[0]],
        'faster': faster, 'queue_available': available, 'accepted': faster,
    }


def compare_configs(baseline, candidate):
    changes = cfg.diff(baseline, candidate)
    if {key for key, _, _ in changes} != PROFILE_KEYS:
        raise SpeedFailure('六卡候选的解析配置超出了已批准改项')
    return changes


def compare_composed(work):
    import os
    student = 'Llama-3.1-8B-Instruct-' + (os.environ.get('USER') or 'root')
    interaction = work / 'interaction_b.yaml'
    raytmp = cfg.c.ROOT / 'r000000'
    entry = HERE.parent / 'a_group_formal_v1' / 'formal_trainer.py'
    baseline = cfg.compose(entry, work, cfg.overrides(work, raytmp, student, interaction, speed=False))
    candidate = cfg.compose(entry, work, cfg.overrides(work, raytmp, student, interaction, speed=True))
    cfg.pin_composed(candidate, work, student, interaction)
    for key, old, new in compare_configs(baseline, candidate):
        if type(old) is int and type(new) is int:
            print(key, old, new)
        else:
            print(key, '运行目录或队列监控设置')
    baseline_row(cfg.c.ROOT)


def verify_fast_environment():
    """Use a single-node tested comparison receipt before selecting fast kernels."""
    import subprocess

    path = cfg.FAST_PYTHON.parents[1] / 'kernel_equivalence.json'
    try:
        receipt = json.loads(path.read_text())
        numeric = ('logprob', 'loss', 'grad_norm')
        if (receipt.get('protocol') != 'qwen35_one_card_fixed_batch_v1' or
                receipt.get('environment') != str(cfg.FAST_PYTHON.parents[1]) or
                receipt.get('fast_kernel_verified') is not True or
                not all(within_repeat(receipt['comparisons'][key]) for key in numeric)):
            raise ValueError
        command = [str(cfg.FAST_PYTHON), '-B', str(HERE / 'kernel_probe.py'), '--verify-fast']
        proc = subprocess.run(command, env=dict(os.environ, CUDA_VISIBLE_DEVICES=''),
                              capture_output=True, text=True, timeout=90, check=False)
        if proc.returncode or 'FAST_IMPORT_OK' not in proc.stdout.splitlines():
            raise ValueError
    except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired):
        raise SpeedFailure('快路径尚无本站数值等价与内核验证') from None


def within_repeat(comparison):
    baseline, fast = comparison['slow_repeat_abs_diff'], comparison['fast_slow_abs_diff']
    return (all(type(value) in (float, int) and math.isfinite(value) and value >= 0 for value in (baseline, fast))
            and fast <= baseline)
