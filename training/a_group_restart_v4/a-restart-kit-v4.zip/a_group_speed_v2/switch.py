"""Inspect or stop only the installed four-card formal run before the cutoff."""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import fcntl
import json
import os
from pathlib import Path, PurePosixPath
import re
import select
import signal
import sys
import time


ROOT = Path('/workspace/A_group_repro_20261117')
PROC = Path('/proc')
OLD_KIT = Path('/workspace/a-formal-kit-v1')
RUN = 'a_formal_v1'
CONFIRM = 'SWITCH6'
CUTOFF = 20
RECEIPT = 'a-speed-v2-switch.json'
STEP_NAME = re.compile(r'([1-9][0-9]*)\.json\Z')
CHECKPOINT_NAME = re.compile(r'global_step_([1-9][0-9]*)\Z')
METRIC_STEP = re.compile(rb'(?:^|\s)step:([0-9]+)\s+-\s.*?\btraining/global_step:([0-9]+)(?=\s|$)')
EVAL_ENTRIES = {
    ('app', 'offline_eval.py'),
    ('app', 'launch.py'),
    ('agnes_eval_v2', 'run.sh'),
    ('parallel_eval_v3', 'coordinator.py'),
    ('parallel_eval_v3', 'lane_launch.py'),
    ('parallel_eval_v4', 'coordinator.py'),
    ('parallel_eval_v4', 'lane_launch.py'),
    ('parallel_shared_eval', 'supervisor.py'),
    ('parallel_shared_eval', 'evaluator_guard.py'),
}


class SwitchRefused(RuntimeError):
    """A fixed reason that can be printed without exposing operating data."""


@dataclass(frozen=True)
class Process:
    pid: int
    start: int
    argv: tuple[str, ...]
    uid: int
    status: str = field(compare=False)


@dataclass(frozen=True)
class Snapshot:
    controller: Process
    completed: int
    evidence: int
    rollback: int
    evaluation: int


def read_object(path, missing=None):
    if path.is_symlink():
        raise SwitchRefused('运行回执文件身份异常')
    try:
        value = json.loads(path.read_bytes())
    except FileNotFoundError:
        if missing is not None:
            return missing
        raise SwitchRefused('运行回执缺失') from None
    except (OSError, ValueError):
        raise SwitchRefused('运行回执不可读取') from None
    if not isinstance(value, dict):
        raise SwitchRefused('运行回执格式异常')
    return value


def process(proc, pid):
    folder = proc / str(pid)
    try:
        fields = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
        argv = tuple(os.fsdecode(arg) for arg in (folder / 'cmdline').read_bytes().split(b'\0') if arg)
        # A process may exit and reuse its PID while /proc is being read.
        second = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
        if fields[19] != second[19]:
            return None
        return Process(pid, int(fields[19]), argv, folder.stat().st_uid, second[0])
    except (FileNotFoundError, ProcessLookupError):
        return None
    except (OSError, IndexError, ValueError):
        raise SwitchRefused('进程身份不可读取') from None


def known_evaluation(argv):
    if '--status' in argv or '--help' in argv:
        return False
    for arg in argv:
        if not arg.startswith('/workspace/'):
            continue
        parts = PurePosixPath(arg).parts
        if parts[-2:] in EVAL_ENTRIES and any(part.startswith('eduardo27b') for part in parts):
            return True
        if any(part.lower() == 'eduardo-27b-3bbf17e' for part in parts):
            return True
    return False


def running_known_evaluations(proc):
    count = 0
    try:
        dirs = list(proc.iterdir())
        for folder in dirs:
            if not folder.name.isdecimal():
                continue
            try:
                parts = (folder / 'cmdline').read_bytes().split(b'\0')
            except (FileNotFoundError, ProcessLookupError):
                continue
            count += known_evaluation(tuple(os.fsdecode(arg) for arg in parts if arg))
    except OSError:
        raise SwitchRefused('当前容器进程不可核验') from None
    return count


def observed_steps(work, store):
    latest = read_object(work / 'latest-step.json', missing={})
    step = latest.get('step', 0)
    if type(step) is not int or step < 0 or (latest and latest.get('data_batches') != step):
        raise SwitchRefused('最近完成步回执不一致')
    steps_dir = work / 'step-statistics'
    if steps_dir.is_symlink():
        raise SwitchRefused('训练步回执目录身份异常')
    receipts = [int(match[1]) for path in steps_dir.glob('*.json')
                if (match := STEP_NAME.fullmatch(path.name))]
    if receipts:
        recent = max(receipts)
        row = read_object(steps_dir / f'{recent}.json')
        if row.get('step') != recent or row.get('data_batches') != recent:
            raise SwitchRefused('训练步回执不一致')
        step = max(step, recent)

    native = 0
    log = work / 'trainer.log'
    if log.is_symlink():
        raise SwitchRefused('训练日志身份异常')
    try:
        with log.open('rb') as stream:
            stream.seek(max(0, os.fstat(stream.fileno()).st_size - 2 * 1024**2))
            for line in stream:
                match = METRIC_STEP.search(line)
                if match and match[1] == match[2]:
                    native = max(native, int(match[1]))
    except OSError:
        raise SwitchRefused('训练计时日志不可读') from None

    checkpoint = 0
    for path in (store / 'checkpoints').glob('global_step_*'):
        if match := CHECKPOINT_NAME.fullmatch(path.name):
            checkpoint = max(checkpoint, int(match[1]))
    return step, max(step, native, checkpoint)


def rollback_checkpoint(store, completed):
    checkpoints = store / 'checkpoints'
    verified = store / 'verified'
    if any(path.is_symlink() for path in (store, checkpoints, verified)):
        raise SwitchRefused('现有检查点目录身份异常')
    accepted = []
    for folder in checkpoints.glob('global_step_*'):
        match = CHECKPOINT_NAME.fullmatch(folder.name)
        if not match:
            continue
        step = int(match[1])
        marker = verified / f'step_{step}.json'
        if not marker.exists() and not marker.is_symlink():
            continue
        row = read_object(marker)
        if row.get('step') != step or row.get('data_batches') != step or step > completed:
            raise SwitchRefused('已验收检查点步号不一致')
        accepted.append(step)
    if not accepted:
        if completed >= 5:
            raise SwitchRefused('完成步已达到 5，但缺少可回退检查点')
        return 0

    step = max(accepted)
    folder = checkpoints / f'global_step_{step}'
    actor = folder / 'actor'
    if folder.is_symlink() or actor.is_symlink():
        raise SwitchRefused('现有检查点目录身份异常')
    config = read_object(actor / 'fsdp_config.json')
    files = [folder / 'data.pt', actor / 'huggingface' / 'config.json']
    files.extend(actor / f'{kind}_world_size_2_rank_{rank}.pt'
                 for kind in ('model', 'optim', 'extra_state') for rank in range(2))
    if config.get('world_size') != 2 or any(not path.is_file() or path.is_symlink() or path.stat().st_size == 0
                                           for path in files):
        raise SwitchRefused('最新可回退检查点不完整')
    return step


def snapshot(root=ROOT, proc=PROC, kit=OLD_KIT):
    work = root / 'pilots' / RUN
    if work.is_symlink():
        raise SwitchRefused('现有运行目录身份异常')
    state = read_object(work / 'orchestration.json')
    pid = state.get('controller_pid')
    if type(pid) is not int or pid < 2 or state.get('phase') != '训练中':
        raise SwitchRefused('原正式训练未处于可切换的训练阶段')
    expected = (str(root / 'envs/env-candidate-vllm0191/bin/python'), '-B',
                str(kit / 'a_group_formal_v1/formal_stage.py'), '--run', '--name', RUN)
    identity = process(proc, pid)
    if (identity is None or identity.status in ('Z', 'X', 'x') or
            identity.uid != os.geteuid() or identity.argv != expected):
        raise SwitchRefused('原正式控制器进程身份不匹配')
    store = root / 'formal_a_v1'
    completed, evidence = observed_steps(work, store)
    evaluation = running_known_evaluations(proc)
    # Report the cutoff before inspecting rollback receipts at step >= 20.
    rollback = rollback_checkpoint(store, completed) if evidence < CUTOFF - 1 else 0
    return Snapshot(identity, completed, evidence, rollback, evaluation)


def check_window(state):
    if state.evaluation:
        raise SwitchRefused('发现仍在运行的 27B 评测')
    if state.evidence >= CUTOFF - 1:
        # Frozen v1 records completed steps only. After step 19 the next step
        # can already be running even without a receipt.
        raise SwitchRefused('第 20 步可能已开始，保留原正式训练')


def lock_probe(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        raise SwitchRefused('原训练控制器锁不可读取') from None
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    finally:
        os.close(fd)


def old_guards_running(proc, kit, parent):
    marker = str(kit / 'a_group_b_native_v1/parent_guard.py')
    for folder in proc.iterdir():
        if not folder.name.isdecimal():
            continue
        try:
            parts = tuple(os.fsdecode(arg) for arg in (folder / 'cmdline').read_bytes().split(b'\0') if arg)
        except (FileNotFoundError, ProcessLookupError):
            continue
        if marker in parts and ('--parent', str(parent)) == parts[parts.index(marker) + 1:parts.index(marker) + 3]:
            return True
    return False


def wait_for_exit(fd, root, proc, kit, parent):
    deadline = time.monotonic() + 180
    wait = select.poll()
    wait.register(fd, select.POLLIN)
    if not wait.poll(180_000):
        raise SwitchRefused('原正式控制器退出超时')
    while time.monotonic() < deadline:
        if lock_probe(root / '.pilot.lock') and not old_guards_running(proc, kit, parent):
            return
        time.sleep(1)
    raise SwitchRefused('原任务尚未释放锁或守护进程仍在退出')


def switch_receipt(path, phase, state, *, create=False):
    payload = {'phase': phase, 'completed_step': state.completed, 'rollback_step': state.rollback}
    if create:
        with path.open('x', encoding='utf-8') as stream:
            json.dump(payload, stream, ensure_ascii=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        return
    temporary = path.with_suffix('.tmp')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(payload, stream, ensure_ascii=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def stop_for_switch(root=ROOT, proc=PROC, kit=OLD_KIT):
    if not hasattr(os, 'pidfd_open') or not hasattr(signal, 'pidfd_send_signal'):
        raise SwitchRefused('当前环境不支持按 pidfd 发出停止信号')
    switch_lock = root / '.a-speed-v2-switch.lock'
    lock = os.open(switch_lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SwitchRefused('另一切换操作正在运行') from None
        path = root / RECEIPT
        if path.exists() or path.is_symlink():
            raise SwitchRefused('已有一次切换操作记录')
        old = snapshot(root, proc, kit)
        check_window(old)
        pid = old.controller.pid
        fd = os.pidfd_open(pid)
        try:
            verifiable = snapshot(root, proc, kit)
            if verifiable.controller != old.controller:
                raise SwitchRefused('原正式训练控制器身份已变化')
            check_window(verifiable)
            if lock_probe(root / '.pilot.lock'):
                raise SwitchRefused('验证不到原正在运行的训练锁')
            # Recheck progress close to the signal, including checkpoint write
            # activity that can precede the step receipt.
            work = root / 'pilots' / RUN
            _, latest = observed_steps(work, root / 'formal_a_v1')
            if latest != verifiable.evidence:
                raise SwitchRefused('训练刚完成新一步，请重新审阅切换状态')
            if running_known_evaluations(proc):
                raise SwitchRefused('发现仍在运行的 27B 评测')
            switch_receipt(path, '已申请停止原正式训练', verifiable, create=True)
            signal.pidfd_send_signal(fd, signal.SIGTERM)
            wait_for_exit(fd, root, proc, kit, pid)
            switch_receipt(path, '原正式训练已退出', verifiable)
            return verifiable
        finally:
            os.close(fd)
    except ProcessLookupError:
        raise SwitchRefused('原正式训练进程已经退出') from None
    finally:
        os.close(lock)


def print_state(state):
    print('旧正式训练最近完成步', state.completed)
    print('回执、原生指标和检查点所见最高步', state.evidence)
    print('可退回四卡完整检查点', state.rollback if state.rollback else '未核实')
    print('当前容器已识别的 27B 评测进程', state.evaluation)


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--status', action='store_true')
    action.add_argument('--stop-for-switch', action='store_true')
    parser.add_argument('--confirm')
    parser.add_argument('--confirm-27b-deferred', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    try:
        if args.status:
            state = snapshot()
            print_state(state)
            check_window(state)
            print('截止步和本容器评测检查通过')
            return 0
        if args.confirm != CONFIRM or not args.confirm_27b_deferred:
            raise SwitchRefused('需要明确确认切换和 27B 评测已延后')
        state = stop_for_switch()
        print_state(state)
        print('原正式训练已退出')
        return 0
    except (SwitchRefused, OSError) as exc:
        print(str(exc) if isinstance(exc, SwitchRefused) else '切换的本地系统调用失败')
        return 1


if __name__ == '__main__':
    sys.exit(main())
