"""Native Qwen3.5 forward/backward worker, executed in a single masked GPU process."""
from collections import Counter
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import json
import math
import os
import time

from compare_kernels import (
    CHECKPOINT, CompareFailure, SEED, SOAK_SECONDS, TOKENIZER, comparisons, cuda_map,
    load_rows, resources, round_trend, within_repeat,
)

MIB = 1024 ** 2


class Kernels:
    """Switch path per layer while sharing the exact same master weights."""
    def __init__(self, model, native):
        self.layers = [layer for layer in model.modules() if isinstance(layer, native.Qwen3_5GatedDeltaNet)]
        if not self.layers or not native.is_fast_path_available or native.FusedRMSNormGated is None:
            raise CompareFailure('原生 Qwen3.5 快路径不可用')
        self.counts = Counter()
        self.hooks = []
        self.orig = []
        for layer in self.layers:
            fast_conv, fast_chunk, fast_norm = layer.causal_conv1d_fn, layer.chunk_gated_delta_rule, layer.norm
            if (not callable(fast_conv) or not callable(fast_chunk)
                    or not isinstance(fast_norm, native.FusedRMSNormGated)
                    or getattr(fast_norm, 'bias', None) is not None
                    or not fast_conv.__module__.startswith('causal_conv1d')
                    or not fast_chunk.__module__.startswith('fla.')):
                raise CompareFailure('线性注意力未绑定预期第三方内核')
            slow_norm = native.Qwen3_5RMSNormGated(layer.head_v_dim, eps=layer.layer_norm_epsilon)
            slow_norm.weight = fast_norm.weight
            self.orig.append((layer, fast_conv, fast_chunk, fast_norm, slow_norm))
            self.hooks.append(layer.conv1d.register_forward_hook(self.hook('slow_conv')))
            self.hooks.append(fast_norm.register_forward_hook(self.hook('fast_norm')))
            self.hooks.append(slow_norm.register_forward_hook(self.hook('slow_norm')))
        self.slow_chunk = native.torch_chunk_gated_delta_rule

    def hook(self, name):
        def count(_module, _inputs, _result):
            self.counts[name] += 1
        return count

    def wrap(self, fn, name):
        def measured(*args, **kwargs):
            if name == 'fast_conv':
                # nn.Conv1d uses BF16 autocast in the slow branch. The external
                # op is not a torch autocast operator, so match its input dtype.
                kwargs['weight'] = kwargs['weight'].to(kwargs['x'].dtype)
            output = fn(*args, **kwargs)
            self.counts[name] += 1
            return output
        return measured

    def use(self, mode):
        for layer, fast_conv, fast_chunk, fast_norm, slow_norm in self.orig:
            layer.causal_conv1d_fn = self.wrap(fast_conv, 'fast_conv') if mode == 'fast' else None
            layer.chunk_gated_delta_rule = (self.wrap(fast_chunk, 'fast_chunk') if mode == 'fast'
                                            else self.wrap(self.slow_chunk, 'slow_chunk'))
            layer.norm = fast_norm if mode == 'fast' else slow_norm

    def verified(self, mode, trajectories):
        chosen = {f'{mode}_{suffix}' for suffix in ('conv', 'chunk', 'norm')}
        # At least one genuine call in each native layer per trajectory. Some
        # forwards are recomputed by gradient checkpointing during backward.
        return set(self.counts) == chosen and all(
            self.counts[name] >= len(self.layers) * trajectories for name in chosen)


def one_batch(torch, model, kernels, batch, mode, check, *, keep_values):
    from torch.utils.checkpoint import checkpoint

    def log_probs(hidden, targets):
        with torch.autocast(device_type='cuda', enabled=False):
            logits = model.lm_head(hidden.float())
            return -torch.nn.functional.cross_entropy(logits, targets, reduction='none')

    kernels.use(mode)
    kernels.counts.clear()
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    combined, samples = [], []
    tokens = sum(len(positions) for _, positions in batch)
    seconds = 0.0
    for ids, positions in batch:
        check()
        started = time.monotonic()
        with torch.autocast(device_type='cuda', dtype=torch.bfloat16):
            output = model.model.language_model(input_ids=ids, use_cache=False, return_dict=True)
        targets = ids[0, positions]
        effective = output.last_hidden_state[0, positions - 1]
        chunks = [checkpoint(log_probs, x, y, use_reentrant=False)
                  for x, y in zip(effective.split(256), targets.split(256))]
        values = torch.cat(chunks)
        loss = -values.sum() / tokens
        loss.backward()
        combined.append(loss.detach())
        if keep_values:
            samples.extend(values.detach().cpu().tolist())
        elif not bool(torch.isfinite(values.detach()).all().item()):
            raise CompareFailure('耐久阶段有效 token logprob 非有限')
        torch.cuda.synchronize()
        seconds += time.monotonic() - started
        del output, targets, effective, chunks, values, loss
    started = time.monotonic()
    grads = [torch.linalg.vector_norm(p.grad.detach().float()) for p in model.parameters() if p.grad is not None]
    if not grads:
        raise CompareFailure('模型未产生梯度')
    grad_norm = float(torch.linalg.vector_norm(torch.stack(grads)).item())
    loss = float(torch.stack(combined).sum().item())
    torch.cuda.synchronize()
    seconds += time.monotonic() - started
    if not math_positive(grad_norm) or not math_positive(loss):
        raise CompareFailure('实际损失或梯度不是有限正数')
    if not kernels.verified(mode, len(batch)):
        raise CompareFailure('实际慢或快路径函数调用与目标不符')
    row = {
        'mode': mode, 'values': samples, 'loss': loss, 'grad_norm': grad_norm,
        'seconds_per_token': seconds / tokens,
        'kernel_call_counts': dict(kernels.counts),
        'peak_alloc_mib': torch.cuda.max_memory_allocated() / MIB,
        'peak_reserved_mib': torch.cuda.max_memory_reserved() / MIB,
    }
    model.zero_grad(set_to_none=True)
    return row


def math_positive(value):
    return math.isfinite(value) and value > 0


def endurance(torch, model, kernels, batch, mode, check, report_dir):
    torch.cuda.empty_cache()
    started = time.monotonic()
    cycles = []
    peak_alloc = peak_reserved = 0.0
    with (report_dir / f'soak-{mode}-cycles.jsonl').open('x', encoding='utf-8') as stream:
        while time.monotonic() - started < SOAK_SECONDS[mode]:
            round_start = time.monotonic()
            current = one_batch(torch, model, kernels, batch, mode, check, keep_values=False)
            sample = {'round': len(cycles) + 1, 'round_seconds': time.monotonic() - round_start,
                      'ms_per_token': current['seconds_per_token'] * 1000,
                      'loadavg_1': os.getloadavg()[0]}
            stream.write(json.dumps(sample, allow_nan=False) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
            cycles.append(sample)
            peak_alloc = max(peak_alloc, current['peak_alloc_mib'])
            peak_reserved = max(peak_reserved, current['peak_reserved_mib'])
    return {'cycles': len(cycles), 'elapsed_seconds': time.monotonic() - started,
            'peak_alloc_mib': peak_alloc, 'peak_reserved_mib': peak_reserved,
            'seconds_per_token': math.fsum(sample['ms_per_token'] for sample in cycles) / len(cycles) / 1000,
            'round_trend': round_trend(cycles)}


def checkpoint_hash(check):
    digest = hashlib.sha256()
    for path in sorted((CHECKPOINT / 'config.json', *CHECKPOINT.glob('*.safetensors'))):
        if path.is_symlink():
            raise CompareFailure('C 合并权重文件是符号链接')
        digest.update(path.name.encode() + b'\x00')
        with path.open('rb') as stream:
            while chunk := stream.read(8 * MIB):
                check()
                digest.update(chunk)
    return digest.hexdigest()


def run_worker(index, uuid, deadline, report_dir):
    # Silence native output. The only response parent receives is numeric JSON.
    with open(os.devnull, 'w') as sink, redirect_stdout(sink), redirect_stderr(sink):
        import torch
        from transformers import AutoTokenizer
        from transformers.models.qwen3_5 import modeling_qwen3_5 as native
        return probe(torch, AutoTokenizer, native, index, uuid, deadline, report_dir)


def probe(torch, auto_tokenizer, native, index, uuid, deadline, report_dir):
    if torch.__version__.split('+', 1)[0] != '2.10.0' or torch.version.cuda != '12.8' or not torch.compiled_with_cxx11_abi():
        raise CompareFailure('快路径 Torch/CUDA/ABI 与冻结版本不符')
    if torch.cuda.device_count() != 1 or not torch.cuda.is_bf16_supported():
        raise CompareFailure('要求可见一张支持 BF16 的卡')
    properties = torch.cuda.get_device_properties(0)
    if ('A100' not in properties.name.upper() or properties.total_memory < 78000 * MIB
            or cuda_map.parse_gpu_uuid(str(properties.uuid)) != cuda_map.parse_gpu_uuid(uuid)):
        raise CompareFailure('运行环境中的单卡身份不符')
    torch.cuda.init()
    free, total = torch.cuda.mem_get_info(0)
    if free < total - 2 * 1024 * MIB:
        raise CompareFailure('CUDA 初始化后显卡已被占用')
    stage = resources.load_stage_a()

    def check(*, inspect_gpu=True):
        if time.monotonic() >= deadline:
            raise TimeoutError()
        if inspect_gpu:
            row = stage.snapshot().get(index)
            if (row is None or row['uuid'] != uuid or len(row['apps']) > 1
                    or row['free'] < 8192):
                raise CompareFailure('单卡独占或最低显存余量检查失败')

    identity = checkpoint_hash(lambda: check(inspect_gpu=False))
    check()
    tokenizer = auto_tokenizer.from_pretrained(TOKENIZER, local_files_only=True, trust_remote_code=False)
    selected, eligible = load_rows(tokenizer)
    check()
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model = native.Qwen3_5ForConditionalGeneration.from_pretrained(
        CHECKPOINT, local_files_only=True, trust_remote_code=False, dtype=torch.float32,
        attn_implementation='sdpa',
    ).to('cuda')
    if any(p.dtype != torch.float32 for p in model.parameters()):
        raise CompareFailure('FP32 主权重未核实')
    if not getattr(model.config, 'tie_word_embeddings', False):
        raise CompareFailure('Qwen3.5-4B 权重绑定与预期不同')
    model.train()
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
    model.zero_grad(set_to_none=True)
    batch = []
    for row in selected:
        ids = torch.tensor([row.ids], device='cuda', dtype=torch.long)
        positions = torch.tensor([i for i, mask in enumerate(row.mask) if mask],
                                 device='cuda', dtype=torch.long)
        if int(positions[0]) < 1:
            raise CompareFailure('首个有效 token 没有可用上下文')
        batch.append((ids, positions))
    kernels = Kernels(model, native)
    check()
    runs = []
    for mode, trials in (('slow', 2), ('fast', 1)):
        one_batch(torch, model, kernels, batch, mode, check, keep_values=False)
        for _ in range(trials):
            torch.cuda.empty_cache()
            runs.append(one_batch(torch, model, kernels, batch, mode, check, keep_values=True))
    equivalent = within_repeat(comparisons(runs))
    stability = {}
    if equivalent:
        stability = {mode: endurance(torch, model, kernels, batch, mode, check, report_dir)
                     for mode in ('slow', 'fast')}
    check()
    return {
        'fast_kernel_verified': True,
        'checkpoint_sha256': identity,
        'eligible_trajectories': eligible,
        'sequence_lengths': [len(row.ids) for row in selected],
        'teacher_tokens': [sum(row.mask) for row in selected],
        'runs': runs,
        'endurance': stability,
        'endurance_skipped': not equivalent,
    }
