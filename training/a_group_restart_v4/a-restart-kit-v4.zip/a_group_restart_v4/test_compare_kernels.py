from copy import deepcopy
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import compare_kernels as c


class Tokenizer:
    def encode(self, text, **kwargs):
        return list(map(ord, text))

    def apply_chat_template(self, messages, **kwargs):
        return {'input_ids': self.encode(' '.join(x['content'] for x in messages) + ' visible opener ')}


class CompareTest(unittest.TestCase):
    def example(self):
        row = {'sequence_lengths': [100, 500, 900], 'teacher_tokens': [1, 2, 1],
               'fast_kernel_verified': True, 'runs': [],
               'endurance': {mode: {'elapsed_seconds': delta + 0.1, 'cycles': 11,
                                    'seconds_per_token': 0.02, 'peak_alloc_mib': 40000,
                                    'peak_reserved_mib': 50000,
                                    'round_trend': c.round_trend([{'round_seconds': 1,
                                        'ms_per_token': 2, 'loadavg_1': 0.5}])} for mode, delta in c.SOAK_SECONDS.items()}}
        for mode, values, loss, grad in (
                ('slow', [-2, -3, -4, -5], 3.5, 2.0),
                ('slow', [-2.25, -3, -4, -5], 3.75, 2.25),
                ('fast', [-2, -3.125, -4, -5], 3.625, 2.125)):
            row['runs'].append(dict(mode=mode, values=values, loss=loss, grad_norm=grad,
                                    seconds_per_token=0.02, peak_alloc_mib=45000, peak_reserved_mib=47000))
        return row

    def test_mask_preserves_teacher_only_and_drops_tail(self):
        rows = [{'role': role, 'content': content}
                for role, content in zip(['system', 'user', 'assistant', 'user', 'assistant', 'user'],
                                         ['s', 'u', 'TA', 'intermediate unscored', 'TB', 'omitted tail'])]
        sequence = c.reconstruct(rows, Tokenizer(), b'fixture')
        self.assertEqual(''.join(chr(k) for k, mask in zip(sequence.ids, sequence.mask) if mask), 'TATB')
        self.assertIn('intermediate unscored', ''.join(map(chr, sequence.ids)))
        self.assertNotIn('omitted tail', ''.join(map(chr, sequence.ids)))
        rows[3]['role'] = 'system'
        self.assertIsNone(c.reconstruct(rows, Tokenizer(), b'fixture'))

    def test_same_cohort_spans_lengths_and_order_is_deterministic(self):
        seqs = [c.Sequence(tuple(range(length)), (), bytes([index]))
                for index, length in enumerate([1100, 500, 300, 900, 1900])]
        expected = [300, 900, 1900]
        self.assertEqual([len(row.ids) for row in c.select_mixed(seqs)], expected)
        self.assertEqual([len(row.ids) for row in c.select_mixed(list(reversed(seqs)))], expected)
        with self.assertRaisesRegex(c.CompareFailure, '不足'):
            c.select_mixed(seqs[:2])

    def test_tolerance_is_only_slow_repeat_and_drops_token_values(self):
        rows = self.example()
        self.assertTrue(c.score_result(rows))
        self.assertEqual(rows['comparisons']['logprob'], {'slow_repeat_abs_diff': 0.25, 'fast_slow_abs_diff': 0.125})
        self.assertTrue(all('values' not in item for item in rows['runs']))
        unequal = self.example()
        unequal['runs'][1] = deepcopy(unequal['runs'][0])
        self.assertFalse(c.score_result(unequal))
        self.assertEqual(unequal['comparisons']['logprob']['slow_repeat_abs_diff'], 0)

    def test_failed_soak_cannot_pass_and_bad_values_are_rejected(self):
        for key, value in [('elapsed_seconds', 1199), ('cycles', 0), ('peak_alloc_mib', float('nan'))]:
            result = self.example()
            result['endurance']['fast'][key] = value
            with self.assertRaises(c.CompareFailure):
                c.score_result(result)
        result = self.example()
        result['runs'][2]['values'][1] = float('nan')
        with self.assertRaises(c.CompareFailure):
            c.score_result(result)

    def test_early_numerical_rejection_keeps_numbers_without_endurance(self):
        result = self.example()
        result['runs'][1] = deepcopy(result['runs'][0])
        result.update(endurance={}, endurance_skipped=True)
        self.assertFalse(c.score_result(result))
        self.assertFalse(result['endurance'])
        self.assertGreater(result['comparisons']['logprob']['fast_slow_abs_diff'], 0)
        equivalent = self.example()
        equivalent.update(endurance={}, endurance_skipped=True)
        with self.assertRaisesRegex(c.CompareFailure, '提前停止'):
            c.score_result(equivalent)

    def test_first_and_last_third(self):
        trend = c.round_trend([{'round_seconds': x, 'ms_per_token': x * 5, 'loadavg_1': x * 10}
                               for x in range(1, 8)])
        self.assertEqual(trend['rounds_per_third'], 2)
        self.assertEqual(trend['first'], {'round_seconds': 1.5, 'ms_per_token': 7.5, 'loadavg_1': 15})
        self.assertEqual(trend['last'], {'round_seconds': 6.5, 'ms_per_token': 32.5, 'loadavg_1': 65})
        self.assertAlmostEqual(trend['last_to_first_wall'], 13 / 3)
        self.assertAlmostEqual(trend['last_to_first_ms_per_token'], 13 / 3)

    def test_receipt_is_write_once(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'receipt.json'
            c.promote_receipt(path, {'protocol': c.PROTOCOL})
            with self.assertRaises(FileExistsError):
                c.promote_receipt(path, {'protocol': 'invalid'})
            self.assertEqual(json.loads(path.read_text()), {'protocol': c.PROTOCOL})
            self.assertEqual(list(path.parent.iterdir()), [path])

    def test_waits_without_a_group_lock_then_rechecks_under_lock(self):
        binding = SimpleNamespace(index=3, uuid='GPU-x')
        elapsed = []
        with patch.object(c, 'select_card', side_effect=[None, binding, binding]):
            stage = Mock()
            stage.own_lock.side_effect = [BlockingIOError(), os.open('/dev/null', os.O_RDONLY)]
            stage.snapshot.return_value = {3: {'uuid': 'GPU-x'}}
            stage.eligible.return_value = True
            got, fd = c.claim_card(stage, None, True, sleep=elapsed.append, monotonic=lambda: 0)
            os.close(fd)
            self.assertEqual(got, binding)
            self.assertEqual(elapsed, [60, 60])
            self.assertEqual(stage.own_lock.call_count, 2)
            stage.snapshot.assert_called_once()

    def test_parent_timeout_kills_only_own_child_and_no_receipt(self):
        binding = SimpleNamespace(index=0, uuid='GPU-x')
        child = Mock()
        child.poll.return_value = None
        child.communicate.side_effect = subprocess.TimeoutExpired('fixture', 1)
        with patch.object(c.subprocess, 'Popen', return_value=child), \
                patch.object(c, 'promote_receipt') as save, \
                patch('sys.stdout', io.StringIO()), self.assertRaisesRegex(c.CompareFailure, '两小时'):
            c.perform_comparison(binding, 42, Path('/fixture'), Path('/fixture'))
        child.kill.assert_called_once()
        child.wait.assert_called_once()
        save.assert_not_called()

    def test_measured_difference_does_not_write_a_receipt(self):
        binding = SimpleNamespace(index=0, uuid='GPU-x')
        result = self.example()
        result['runs'][1] = deepcopy(result['runs'][0])
        child = Mock(returncode=0)
        child.poll.return_value = 0
        child.communicate.return_value = (json.dumps(result), None)
        with patch.object(c.subprocess, 'Popen', return_value=child), \
                patch.object(c, 'promote_receipt') as save, patch('sys.stdout', io.StringIO()) as output:
            self.assertEqual(c.perform_comparison(binding, 42, Path('/fixture'), Path('/fixture')), 1)
            self.assertIn('不等价', output.getvalue())
        self.assertEqual(save.call_count, 1)
        self.assertEqual(save.call_args.args[0].name, 'comparison-summary.json')
        self.assertFalse(save.call_args.args[1]['accepted'])


if __name__ == '__main__':
    unittest.main()
