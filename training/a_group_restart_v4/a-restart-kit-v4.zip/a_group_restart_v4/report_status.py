"""Render the recorded per-phase metrics without printing original logs."""
import json
import math
from pathlib import Path

from step_review_v4 import PHASES, TOKEN_KEY

GPU_FIELDS = ('util_pct', 'used_mib', 'sm_clock_mhz', 'temp_c', 'power_w')
HOST_FIELDS = ('load1', 'nproc', 'task_cpu_pct', 'mem_free_mib', 'mem_available_mib',
               'swap_total_mib', 'swap_used_mib')


def read(path):
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def number(value):
    return f'{value:.2f}' if type(value) in (int, float) and math.isfinite(value) else '—'


def table(headers, rows):
    print('| ' + ' | '.join(headers) + ' |')
    print('| ' + ' | '.join('---' for _ in headers) + ' |')
    for row in rows:
        print('| ' + ' | '.join(map(str, row)) + ' |')


def throttle(row):
    if not row.get('samples'):
        return '—'
    counts = row.get('by_bit', {})
    bits = ', '.join(f'{int(k, 16):#x}×{v}' for k, v in sorted(counts.items())
                     if isinstance(k, str) and k.startswith('0x') and type(v) is int)
    return f'{int(row["active_samples"])}/{int(row["samples"])}' + (f' ({bits})' if bits else '')


def show_step(row, cards):
    print('\n第', row['step'], '步 ｜总 token', number(row.get('metrics', {}).get(TOKEN_KEY)))
    data = row.get('telemetry', {})
    times = row.get('phase_timings', {})
    table(('阶段', '分钟', '毫秒/总token', '10秒样本数', '采样窗口秒'), [
        (phase, number(times.get(phase, {}).get('minutes')), number(times.get(phase, {}).get('ms_per_token')),
         data.get(phase, {}).get('samples', '—'), number(data.get(phase, {}).get('duration_s'))) for phase in PHASES])
    peaks = row.get('gpu_peaks', {})
    table(('Tutor GPU', '整卡显存峰值 MiB', '样本数'), [
        (card, number(peaks.get(str(card), {}).get('peak_mib')), peaks.get(str(card), {}).get('samples', '—'))
        for card in cards])
    gpu_rows = []
    for phase in PHASES:
        for gpu in cards:
            entry = data.get(phase, {}).get('gpus', {}).get(str(gpu), {})
            gpu_rows.append((phase, gpu, *(number(entry.get(field, {}).get('mean')) for field in GPU_FIELDS),
                             throttle(entry.get('throttle', {}))))
    table(('阶段', 'Tutor GPU', '平均利用率%', '平均已用MiB', '平均SM MHz', '平均温度°C', '平均功耗W',
           '活动时钟原因样本/总样本（位掩码计数）'), gpu_rows)
    table(('阶段', '平均1m负载', '平均nproc', '平均任务CPU%', '平均空闲内存MiB', '平均可用内存MiB',
           '平均swap总量MiB', '平均swap已用MiB'), [
        (phase, *(number(data.get(phase, {}).get('host', {}).get(key, {}).get('mean')) for key in HOST_FIELDS))
        for phase in PHASES])


def show(work: Path, chosen=None):
    state = read(work / 'orchestration.json')
    phase = state.get('phase')
    print('v4 阶段', phase if phase in ('准备', '配置预检', '凑卡', '训练中', '失败', '服务收尾', '完成') else '暂无')
    info = read(work / 'restore.json')
    print('恢复步／批位置', number(info.get('global_step')), '/', number(info.get('data_batches')))
    binding = state.get('bindings', {})
    cards = [card for card in binding.get('tutor', ()) if type(card) is int]
    for role in ('tutor', 'student', 'judge'):
        parts = [str(card) for card in binding.get(role, ()) if type(card) is int]
        print(role, ' '.join(parts) or '—')
    count = read(work / 'rollout-layout.json')
    print('rollout TP／副本数', number(count.get('tensor_parallel')), '/', number(count.get('replicas')))
    if type(state.get('protected_gpu')) is int:
        print('保护触发 GPU', state['protected_gpu'])
    first = read(work / 'restart-step2-comparison.json')
    if first:
        print('第2步每token检查', '通过' if first.get('passed') else '停止',
              '旧策略', number(first.get('ratios', {}).get('old_log_prob')),
              '更新', number(first.get('ratios', {}).get('update_actor')))
    # Keep the default display short. An older milestone can be read with --step.
    rows = work / 'step-statistics'
    saved = [int(path.stem) for path in rows.glob('*.json')
             if path.stem.isdigit() and int(path.stem) % 5 == 0]
    steps = [chosen] if chosen else sorted({1, 2, *([max(saved)] if saved else [])})
    for step in steps:
        row = read(rows / f'{step}.json')
        if row.get('step') == step:
            show_step(row, cards)
        else:
            print('第', step, '步', '暂无本次运行回执')
