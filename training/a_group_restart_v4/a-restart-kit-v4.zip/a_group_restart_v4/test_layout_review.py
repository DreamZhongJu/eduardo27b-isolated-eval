from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

import layout
from step_review_v4 import PHASES, compare_steps, per_token


class LayoutTest(unittest.TestCase):
    def test_six_preferred_and_four_used_for_five(self):
        self.assertEqual(layout.choose_cards(range(8)), (0, 1, 2, 3, 4, 5))
        self.assertEqual(layout.choose_cards((1, 2, 3, 5, 6)), (1, 2, 3, 5))
        self.assertEqual(layout.choose_cards(range(3)), ())
        with self.assertRaisesRegex(ValueError, '不可用'):
            layout.choose_cards(range(5), (0, 1, 2, 6))
        with self.assertRaisesRegex(ValueError, '不同'):
            layout.choose_cards(range(5), (0, 0, 2, 3))
        self.assertEqual(layout.roles((1, 2, 3, 5)), {'judge': (1,), 'tutor': (2, 3), 'student': (5,)})

    def test_memory_owner_resume_and_profile_proof_are_required(self):
        with TemporaryDirectory() as d:
            root = Path(d)
            name = 'a_restart_v4_4_20261120130000_abcdef'
            evidence = layout.kernel_receipt(root)
            evidence.parent.mkdir(parents=True)
            evidence.write_text('{}')
            path = layout.approval_file(root, name)
            path.parent.mkdir()
            path.write_text(json.dumps(dict(profile='restart_v4_four', step=25, optimizer_offload=True,
                kernel_receipt_sha256=sha256(b'{}').hexdigest(), gpus=[7, 5, 2, 3], **{'27b_deferred': True})))
            self.assertEqual(layout.read_approval(root, name, 'restart_v4_four', 25, True), (2, 3, 5, 7))
            for profile, step, offload in (('restart_v4_six', 25, True), ('restart_v4_four', 30, True),
                                          ('restart_v4_four', 25, False)):
                with self.assertRaises(ValueError):
                    layout.read_approval(root, name, profile, step, offload)
            evidence.write_text('changed')
            with self.assertRaises(ValueError):
                layout.read_approval(root, name, 'restart_v4_four', 25, True)

    def test_disk_budget_counts_rolling_and_milestone_holders(self):
        with TemporaryDirectory() as d:
            root = Path(d)
            self.assertEqual(layout.disk_required(root, 0), 220_000_000_000)
            for step in (25, 30):
                folder = root / 'checkpoints' / f'global_step_{step}'
                folder.mkdir(parents=True)
                receipt = root / 'verified' / f'step_{step}.json'
                receipt.parent.mkdir(exist_ok=True)
                receipt.touch()
            export = root / 'exports' / 'step_25' / 'config.json'
            export.parent.mkdir(parents=True)
            export.touch()
            self.assertEqual(layout.disk_required(root, 30), 98_000_000_000)

    def test_both_profiles_pin_layout_checkpoints_and_offload(self):
        here = Path(__file__).resolve().parent
        code = '''
import formal_config as c
from pathlib import Path
from checkpoints import VERSION
assert c.KERNEL_MODE == 'fast' and c.ROLLOUT_TP == 1
m = dict(x.split('=', 1) for x in c.overrides(Path('/tmp/work'), '/tmp/r', 'student', '/tmp/config', 25))
assert m['actor_rollout_ref.actor.checkpoint.load_contents'] == '[model,optimizer,extra]'
assert m['trainer.resume_from_path'].endswith(str(c.CKPT / 'global_step_25'))
assert m['trainer.save_freq'] == '5'
assert m['actor_rollout_ref.actor.fsdp_config.param_offload'] == 'false'
assert m['actor_rollout_ref.actor.fsdp_config.optimizer_offload'] == str(c.OPTIMIZER_OFFLOAD).lower()
assert c.OPTIMIZER_OFFLOAD == (c.TUTOR_COUNT == 2)
assert str(c.TUTOR_COUNT) == m['trainer.n_gpus_per_node'] == m['actor_rollout_ref.actor.fsdp_config.fsdp_size']
assert c.PROFILE.replace('_', '-') in VERSION
'''
        for profile, offload in (('restart_v4_four', 'true'), ('restart_v4_six', 'false')):
            env = dict(os.environ, EDU_FORMAL_PROFILE=profile, EDU_RESTART_OPTIMIZER_OFFLOAD=offload,
                       PYTHONPATH=os.pathsep.join(str(here.parent / name) for name in
                          ('a_group_formal_v1', 'a_group_c_v1', 'a_group_b_native_v1')))
            subprocess.run([sys.executable, '-B', '-c', code], env=env, check=True)


class StepReviewTest(unittest.TestCase):
    def row(self, tokens, gen, old, actor):
        metrics = {'perf/total_num_tokens': tokens}
        metrics.update((f'timing_s/{k}', v) for k, v in zip(PHASES, (gen, old, actor)))
        return {'metrics': metrics}

    def test_exact_threshold_and_token_normalization(self):
        first = self.row(1000, 20, 10, 20)
        equal = self.row(2000, 80, 26, 52)
        self.assertTrue(compare_steps(first, equal)['passed'])
        excess = self.row(2000, 10, 26.1, 52)
        self.assertFalse(compare_steps(first, excess)['passed'])
        self.assertEqual(per_token(excess['metrics'])['gen']['ms_per_token'], 5)
        with self.assertRaisesRegex(ValueError, 'token'):
            per_token(self.row(0, 1, 1, 1)['metrics'])
