"""Fixed card layouts, disk budgets and operator approval records."""
from hashlib import sha256
import json
from pathlib import Path
import re

LAYOUTS = {4: 'restart_v4_four', 6: 'restart_v4_six'}
SAVES_GB = 56
EXPORT_GB = 10
FRESH_GB = 220
NAME = re.compile(r'a_restart_v4_[46]_[0-9]{14}_[0-9a-f]{6}\Z')


def choose_cards(available, requested=None):
    available = tuple(sorted(set(available)))
    if requested is not None:
        if len(requested) not in LAYOUTS or len(set(requested)) != len(requested):
            raise ValueError('批准的卡号须是四张或六张不同整卡')
        if not set(requested) <= set(available):
            raise ValueError('获批卡号中有显卡已不可用')
        return tuple(sorted(requested))
    count = 6 if len(available) >= 6 else 4 if len(available) >= 4 else 0
    return available[:count]


def roles(cards):
    return {'judge': cards[:1], 'tutor': cards[1:-1], 'student': cards[-1:]}


def disk_required(series, step):
    """Bytes still needed on top of checkpoints/exports already in this series."""
    completed = [i for i in range(5, step + 1, 5)
                 if (series / 'checkpoints' / f'global_step_{i}').is_dir()
                 and (series / 'verified' / f'step_{i}.json').is_file()]
    exports = [i for i in (25, 50, 75, 100) if i <= step
               and (series / 'exports' / f'step_{i}' / 'config.json').is_file()]
    return max(72, FRESH_GB - SAVES_GB * min(len(completed), 2) - EXPORT_GB * len(exports)) * 10**9


def approval_file(root, name):
    if not NAME.fullmatch(name):
        raise ValueError('启动回执名称不合法')
    return root / 'a-restart-v4-approvals' / f'{name}.json'


def kernel_receipt(root):
    return root / 'envs' / 'env-a100-fast-v2' / 'kernel_equivalence.json'


def receipt_digest(root):
    path = kernel_receipt(root)
    if path.is_symlink():
        raise ValueError('快路径回执身份异常')
    return sha256(path.read_bytes()).hexdigest()


def read_approval(root, name, profile, step, offload):
    try:
        path = approval_file(root, name)
        if path.is_symlink():
            raise ValueError
        proof = json.loads(path.read_text())
        cards = proof['gpus']
        signature = (proof['profile'], proof['step'], proof['optimizer_offload'], proof['kernel_receipt_sha256'])
        if (not isinstance(cards, list) or not all(type(i) is int and i >= 0 for i in cards)
                or len(set(cards)) != len(cards) or LAYOUTS.get(len(cards)) != profile
                or signature != (profile, step, offload, receipt_digest(root))
                or proof.get('27b_deferred') is not True):
            raise ValueError
        return tuple(sorted(cards))
    except (OSError, KeyError, TypeError, ValueError, AttributeError):
        raise ValueError('启动批准回执无法核对') from None
