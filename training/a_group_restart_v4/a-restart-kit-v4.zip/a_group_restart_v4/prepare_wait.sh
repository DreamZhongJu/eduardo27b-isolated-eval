#!/usr/bin/env bash
set -eu
umask 077
here=$(cd -- "$(dirname -- "$0")" && pwd)
root=/workspace/A_group_repro_20261117
offline=/workspace/a100-fast-kernels-offline-v1
archive=${1:-/workspace/a100-fast-kernels-offline-v1.zip}
baseline="$root/envs/env-candidate-vllm0191/bin/python"
fast="$root/envs/env-a100-fast-v2/bin/python"

printf '%s  %s\n' '6bbcca19bcb4f686d6b454cd506a0628e852df56d1fbdf858e8a24213005e1e5' "$archive" | sha256sum -c
"$baseline" -I -B - "$archive" "$offline" "$root" <<'PY'
from pathlib import Path
import shutil
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

archive, target, root = map(Path, sys.argv[1:])
print('输出盘当前剩余 GB', round(shutil.disk_usage(root).free / 10**9, 2), flush=True)
with ZipFile(archive) as z:
    if target.is_symlink():
        raise SystemExit('离线包目录为符号链接')
    if target.exists():
        for name in ('prepare_env.sh', 'check_environment.py', 'SHA256SUMS', 'README.md'):
            if (target / name).is_symlink() or (target / name).read_bytes() != z.read(name):
                raise SystemExit('已有离线包代码版本不符')
    else:
        with TemporaryDirectory(dir=target.parent, prefix='.edu-fast-wheels-') as folder:
            content = Path(folder) / 'kit'
            z.extractall(content)
            content.rename(target)
PY
if [ -e "$root/envs/env-a100-fast-v2" ]; then
  (cd "$offline" && sha256sum -c SHA256SUMS)
  CUDA_VISIBLE_DEVICES='' "$fast" -I -B "$offline/check_environment.py" \
    "$root/envs/env-a100-fast-v2" --installed
else
  bash "$offline/prepare_env.sh" --prepare
fi
"$fast" -I -B "$here/verify_kernel_selection.py"
logdir="$root/kernel-compare-v4"
mkdir -p -m 700 "$logdir"
log=$(mktemp "$logdir/wait-XXXXXX.log")
nohup "$fast" -B "$here/compare_kernels.py" --run --wait >> "$log" 2>&1 < /dev/null &
printf '%s\n' '单卡对照已提交后台，等待空闲整卡' "$log"
