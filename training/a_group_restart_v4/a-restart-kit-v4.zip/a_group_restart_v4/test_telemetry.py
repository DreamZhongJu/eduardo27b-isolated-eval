import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import patch

import telemetry as t


class TelemetryTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.folder = Path(temp.name)

    def test_gpu_fields_and_legacy_driver_query(self):
        response = SimpleNamespace(returncode=0, stdout=(
            '0, 97, 40120, 1410, 0x0000000000000020, 42, 188.5\n'
            '1, 45, 20032, 1245, 0x0000000000000000, 52, 245\n'
            '7, [N/A], 0, [N/A], [N/A], [N/A], [N/A]\n'
        ))
        unsupported = SimpleNamespace(returncode=2, stdout='unsupported and private')
        query = t.GpuQuery()
        with patch.object(t.subprocess, 'run', side_effect=[unsupported, response, response]) as run:
            selected = query({1, 7})
            query({1, 7})
        self.assertEqual(set(selected), {'1', '7'})
        self.assertEqual(selected['1']['power_w'], 245)
        self.assertEqual(selected['1']['throttle_mask'], 0)
        self.assertIsNone(selected['7']['sm_clock_mhz'])
        self.assertIsNone(selected['7']['throttle_mask'])
        self.assertIn('clocks_event_reasons.active', run.call_args_list[0][0][0][1])
        self.assertIn('clocks_throttle_reasons.active', run.call_args_list[1][0][0][1])
        self.assertIn('clocks_throttle_reasons.active', run.call_args_list[2][0][0][1])
        self.assertEqual(t.parse_gpu('0, 12, 1385, 930, 35, 33', {0}, False)['0']['temp_c'], 35)

    def test_verified_tree_and_cpu_rate_ignore_unowned_processes(self):
        roots = {'tutor': [{'pid': 100, 'start': 1}], 'student': [{'pid': 200, 'start': 4}]}
        before = {100: (9, 1, 8), 200: (9, 4, 10), 201: (200, 6, 5),
                  110: (100, 2, 4), 111: (110, 3, 12), 112: (110, 100, 15),
                  113: (110, 1, 30), 160: (1, 9, 1000)}
        after = dict(before)
        after.update({100: (9, 1, 20), 110: (100, 2, 7), 111: (110, 3, 72),
                      112: (110, 101, 30), 160: (1, 9, 2000)})
        a = t.owned_processes(roots, before)
        b = t.owned_processes(roots, after)
        self.assertEqual(set(a), {(100, 1), (200, 4), (201, 6), (110, 2), (111, 3), (112, 100)})
        self.assertEqual(t.cpu_percent(a, b, 2, 100), 37.5)
        self.assertIsNone(t.owned_processes({(100, 2)}, after))

    def test_meminfo_exact_mib(self):
        (self.folder / 'meminfo').write_text(
            'MemFree: 3072 kB\nMemAvailable: 4096 kB\nSwapTotal: 2048 kB\nSwapFree: 1024 kB\n'
        )
        self.assertEqual(t.memory(self.folder), {'mem_free_mib': 3, 'mem_available_mib': 4,
                                                  'swap_total_mib': 2, 'swap_used_mib': 1})

    def test_aggregates_keep_real_phase_boundaries_and_cpu_intervals(self):
        path = self.folder / 'samples.jsonl'
        rows = []
        for wall, previous, util, mask in [(15, 5, 20, 0), (20, 15, 40, 2),
                                           (25, 20, 70, 4), (31, 25, 80, 6),
                                           (41, 31, 90, 0)]:
            rows.append({'time': wall, 'cpu_from': previous,
                         'gpus': {'1': {'util_pct': util, 'throttle_mask': mask,
                                        'raw': 'DO_NOT_EXPORT'}},
                         'host': {'task_cpu_pct': 200, 'mem_available_mib': 400,
                                  'raw': 'DO_NOT_EXPORT'}})
        path.write_text('BAD-TEXT\n' + '\n'.join(map(json.dumps, rows)) + '\n[PARTIAL')
        windows = {'gen': [(10, 21), (15, 25)], 'old_log_prob': (25, 30),
                   'update_actor': [[30, 40], [40, 50]], 'foreign': [(0, 100)]}
        summary = t.summarize(path, windows, gpu_indices=[1, 3])
        gen, old, update = (summary[phase] for phase in t.PHASES)
        self.assertEqual(gen['duration_s'], 15)
        self.assertEqual(gen['samples'], 2)
        self.assertEqual(gen['host']['task_cpu_pct']['samples'], 1)
        self.assertEqual(old['host']['task_cpu_pct']['samples'], 0)
        self.assertEqual(update['host']['task_cpu_pct']['samples'], 1)
        self.assertEqual(update['gpus']['1']['util_pct']['mean'], 85)
        self.assertEqual(update['gpus']['1']['throttle'], {
            'samples': 2, 'active_samples': 1, 'or_mask': 6, 'by_bit': {'0x2': 1, '0x4': 1}})
        self.assertIsNone(update['gpus']['3']['util_pct']['max'])
        self.assertEqual(gen['invalid_sample_rows'], 1)
        self.assertNotIn('DO_NOT_EXPORT', repr(summary))
        self.assertEqual(t.summarize(path, {'gen': None})['gen']['samples'], 0)
        self.assertFalse(t.summarize(path.with_suffix('.absent'), windows)['gen']['sample_file_readable'])

    def test_sampler_lifecycle_and_no_overwrite(self):
        destination = self.folder / 'samples.jsonl'
        sampler = t.Sampler(destination, lambda: [1], lambda: (), interval=0.01)
        saw_two_queries = threading.Event()
        calls = []

        def query(gpus):
            calls.append(gpus)
            if len(calls) == 2:
                saw_two_queries.set()
            return {}

        sampler.query = query
        sampler.start()
        try:
            self.assertTrue(saw_two_queries.wait(timeout=2))
        finally:
            self.assertTrue(sampler.stop())
        self.assertGreaterEqual(len(destination.read_text().splitlines()), 2)
        self.assertEqual(calls[0], {1})
        with self.assertRaises(FileExistsError):
            t.Sampler(destination, (), ()).start()


if __name__ == '__main__':
    unittest.main()
