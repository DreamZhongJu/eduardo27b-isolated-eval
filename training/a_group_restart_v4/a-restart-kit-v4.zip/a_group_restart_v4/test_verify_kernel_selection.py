import subprocess
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import verify_kernel_selection as verify


def fallback(*_):
    raise AssertionError('预检不得执行慢内核')


def fla_chunk(*_):
    raise AssertionError('预检不得执行 FLA 内核')


def causal_conv(*_):
    raise AssertionError('预检不得执行 causal-conv1d 内核')


class KernelSelectionTest(unittest.TestCase):
    def test_natural_mode_requires_real_fallback(self):
        model = SimpleNamespace(is_fast_path_available=False, chunk_gated_delta_rule=None,
                                causal_conv1d_fn=None, torch_chunk_gated_delta_rule=fallback)
        instance = SimpleNamespace(chunk_gated_delta_rule=fallback, causal_conv1d_fn=None)
        self.assertTrue(verify.check_bindings(model, instance, verify.NATURAL))
        instance.causal_conv1d_fn = causal_conv
        self.assertFalse(verify.check_bindings(model, instance, verify.NATURAL))

    def test_simulated_binding_requires_both_real_exports_on_the_instance(self):
        model = SimpleNamespace(is_fast_path_available=True, chunk_gated_delta_rule=fla_chunk,
                                causal_conv1d_fn=causal_conv)
        instance = SimpleNamespace(chunk_gated_delta_rule=fla_chunk, causal_conv1d_fn=causal_conv)
        providers = dict(fla_ops=SimpleNamespace(chunk_gated_delta_rule=fla_chunk),
                         causal=SimpleNamespace(causal_conv1d_fn=causal_conv))
        self.assertTrue(verify.check_bindings(model, instance, verify.SIMULATED, **providers))
        instance.chunk_gated_delta_rule = fallback
        self.assertFalse(verify.check_bindings(model, instance, verify.SIMULATED, **providers))
        instance.chunk_gated_delta_rule = fla_chunk
        providers['causal'].causal_conv1d_fn = fallback
        self.assertFalse(verify.check_bindings(model, instance, verify.SIMULATED, **providers))

    def test_child_error_prints_only_known_category(self):
        params = Path('/workspace/candidate')
        with patch.object(verify.subprocess, 'run', return_value=SimpleNamespace(
                returncode=1, stdout='raw diagnostic\n导入失败\n')):
            self.assertEqual(verify.run_worker(verify.SIMULATED, params), '导入失败')
        with patch.object(verify.subprocess, 'run', return_value=SimpleNamespace(
                returncode=1, stdout='raw diagnostic')):
            self.assertEqual(verify.run_worker(verify.SIMULATED, params), '子进程异常')
        with patch.object(verify.subprocess, 'run', side_effect=subprocess.TimeoutExpired([], 180)):
            self.assertEqual(verify.run_worker(verify.SIMULATED, params), '预检超时')


if __name__ == '__main__':
    unittest.main()
