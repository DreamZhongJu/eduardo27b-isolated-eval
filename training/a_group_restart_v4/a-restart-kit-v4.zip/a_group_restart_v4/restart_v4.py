"""Plan or explicitly launch an approved fast-kernel training layout."""
import argparse
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
for module in ('a_group_formal_v1', 'a_group_speed_v2', 'a_group_restart_v3', 'a_group_b_native_v1'):
    sys.path.insert(0, str(HERE.parent / module))

from layout import LAYOUTS, NAME, approval_file, choose_cards, disk_required, kernel_receipt, receipt_digest, roles
import memory_budget as memory
import restart_control as idle
import resources
import switch

ROOT = idle.ROOT
ENTRY = HERE.parent / 'a_group_formal_v1' / 'formal_stage.py'
APPROVAL = 'START_A_V4'
MILESTONES = (25, 50, 75, 100)


def available_cards():
    stage_a = resources.load_stage_a()
    first = stage_a.snapshot()
    time.sleep(5)
    second = stage_a.snapshot()
    matches = resources.choose_candidates(stage_a, 'judge', first, second, set())
    return {match.index: second[match.index] for match in matches}


def display_plan(cards, offload, disk, needed):
    print('当前盘可用 GB', round(disk / 10**9, 2), '需预留 GB', round(needed / 10**9, 2))
    print('完整滚动检查点约 54.6 GB/份，独立里程碑 BF16 权重约 9.32 GB/份')
    print('布局', len(cards), 'GPU')
    for role, selected in roles(cards).items():
        print(role, ' '.join(map(str, selected)))
    print('优化器 CPU 卸载', '开' if offload else '关')


def configure(cards, available):
    capacity = min(available[gpu]['total'] for gpu in cards) / 1024
    if len(cards) == 6:
        offload = memory.choose_optimizer_offload(capacity)
        memory.print_budget(capacity, offload)
    else:
        offload = True
        weights = memory.MODEL_PARAMETERS * 4 / (2 * memory.GIB)
        rollout = weights + memory.TUTOR_FRACTION * capacity + memory.UNMEASURED_ALLOWANCE
        print('四卡每张 Tutor 的 rollout 估算 GiB', round(rollout, 2),
              '参考先前实测更新 reserved 峰值 GiB', 60.44)
    os.environ.update(EDU_FORMAL_PROFILE=LAYOUTS[len(cards)],
                      EDU_RESTART_OPTIMIZER_OFFLOAD=str(offload).lower(),
                      EDU_RESTART_PROFILE_STEP2='0')
    return offload


def verify_kernel_test():
    import speed_checks
    proof = switch.read_object(kernel_receipt(ROOT))
    endurance = proof.get('endurance')
    runs = proof.get('runs')
    if (not isinstance(endurance, dict) or not isinstance(runs, list) or len(runs) != 3
            or not all(isinstance(row, dict) for row in runs)
            or [row.get('mode') for row in runs] != ['slow', 'slow', 'fast']
            or not all(isinstance(endurance.get(mode), dict)
                       and type(endurance[mode].get('elapsed_seconds')) in (int, float)
                       and math.isfinite(endurance[mode]['elapsed_seconds'])
                       and endurance[mode]['elapsed_seconds'] >= seconds
                       and type(endurance[mode].get('cycles')) is int and endurance[mode]['cycles'] > 0
                       for mode, seconds in (('slow', 2400), ('fast', 1200)))):
        raise switch.SwitchRefused('缺少 v4 单卡数值和耐久测试回执')
    speed_checks.verify_fast_environment()
    return receipt_digest(ROOT)


def protected_run_is_idle():
    idle.processes_idle(ROOT, idle.PROC, idle.OLD_KIT)
    idle.ports_idle()


def verify_config(cfg, work, step):
    from speed_checks import PROFILE_KEYS
    student = 'Llama-3.1-8B-Instruct-' + (os.environ.get('USER') or 'root')
    interaction = work / 'interaction_b.yaml'
    raytmp = ROOT / 'r000000'
    flags = (cfg.overrides(work, raytmp, student, interaction, speed=False, restart=False),
             cfg.overrides(work, raytmp, student, interaction, step or None))
    before, after = (cfg.compose(ENTRY.with_name('formal_trainer.py'), work, group) for group in flags)
    cfg.pin_composed(after, work, student, interaction, step or None)
    expected = set(PROFILE_KEYS)
    if cfg.TUTOR_COUNT == 2:
        expected -= {'trainer.n_gpus_per_node', 'actor_rollout_ref.actor.fsdp_config.fsdp_size',
                     'actor_rollout_ref.rollout.n_gpus_per_node'}
    if not cfg.OPTIMIZER_OFFLOAD:
        expected.add('actor_rollout_ref.actor.fsdp_config.optimizer_offload')
    if step:
        expected.update(('trainer.resume_mode', 'trainer.resume_from_path'))
    if {key for key, _, _ in cfg.diff(before, after)} != expected:
        raise switch.SwitchRefused('冻结配方比较出现计划以外差异')
    print('Hydra 冻结配方核对通过，预期差异字段', len(expected))


def validate_series(cfg, step):
    from checkpoints import Store
    store = Store()
    if cfg.SERIES.exists():
        store.check_existing()
        accepted = store.accepted()
        if step:
            if not accepted or accepted[-1] != step:
                raise switch.SwitchRefused('须以同布局最新已验收检查点继续')
            store.input(step)
        elif accepted or any(store.receipts.iterdir()):
            raise switch.SwitchRefused('已有检查点，须指定同布局续训')
    elif step:
        raise switch.SwitchRefused('指定布局暂无可续训检查点')


def execute(args):
    if args.start and (args.confirm != APPROVAL or not args.confirm_27b_deferred or not args.gpus):
        raise switch.SwitchRefused('启动需要批准、具体卡号与27B评测延期确认')
    protected_run_is_idle()
    disk = shutil.disk_usage(ROOT).free
    print('输出盘当前剩余 GB', round(disk / 10**9, 2), flush=True)
    available = available_cards()
    print('连续两次核验的空闲整卡数', len(available), '卡号', ' '.join(map(str, sorted(available))) or '无')
    cards = choose_cards(available, args.gpus)
    if not cards:
        raise switch.SwitchRefused('需要至少四张空闲整卡，等待卡位')
    offload = configure(cards, available)
    import formal_config as cfg
    step = args.resume or 0
    validate_series(cfg, step)
    needed = disk_required(cfg.SERIES, step)
    display_plan(cards, offload, disk, needed)
    if disk < needed:
        raise switch.SwitchRefused('输出盘剩余空间不足，保留旧数据')
    proof = verify_kernel_test()
    name = f'a_restart_v4_{len(cards)}_{time.strftime("%Y%m%d%H%M%S")}_{secrets.token_hex(3)}'
    work = ROOT / 'pilots' / name
    verify_config(cfg, work, step)
    gpus = ' '.join(map(str, cards))
    if not args.start:
        command = f'{cfg.c.PYTHON} -B {Path(__file__).resolve()} --start --confirm {APPROVAL} --confirm-27b-deferred --gpus {gpus}'
        print('批准后启动命令')
        print(command + (f' --resume {step}' if step else ''))
        return
    protected_run_is_idle()
    receipt = approval_file(ROOT, name)
    receipt.parent.mkdir(mode=0o700, exist_ok=True)
    with receipt.open('x') as stream:
        json.dump({'profile': cfg.PROFILE, 'step': step, 'gpus': cards, 'optimizer_offload': offload,
                   '27b_deferred': True, 'kernel_receipt_sha256': proof}, stream)
        stream.flush()
        os.fsync(stream.fileno())
    command = [str(cfg.c.PYTHON), '-B', str(ENTRY), '--run', '--name', name]
    if step:
        command.extend(('--resume', str(step)))
    with work.with_name(f'{name}-launch.log').open('xb') as log:
        subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                         start_new_session=True)
    print('已提交批准布局', name)
    print('状态命令', f'{cfg.c.PYTHON} -B {Path(__file__).resolve()} --status --name {name}')


def status(name, step):
    if name is None:
        runs = sorted((p for p in (ROOT / 'pilots').glob('a_restart_v4_*') if NAME.fullmatch(p.name)),
                      key=lambda p: p.stat().st_mtime)
        if not runs:
            print('暂无 v4 正式训练')
            return
        name = runs[-1].name
    if not NAME.fullmatch(name):
        raise ValueError('运行名不符')
    from report_status import show
    show(ROOT / 'pilots' / name, step)


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    for option in ('--check', '--start', '--status'):
        action.add_argument(option, action='store_true')
    parser.add_argument('--gpus', nargs='+', type=int)
    parser.add_argument('--resume', type=int, choices=range(5, 100, 5))
    parser.add_argument('--name')
    parser.add_argument('--step', type=int, choices=range(1, 101))
    parser.add_argument('--confirm')
    parser.add_argument('--confirm-27b-deferred', action='store_true')
    args = parser.parse_args()
    if args.resume and not args.gpus:
        parser.error('续训练须给出对应布局的整卡卡号')
    os.umask(0o077)
    try:
        if args.status:
            status(args.name, args.step)
        else:
            execute(args)
        return 0
    except switch.SwitchRefused as error:
        print('v4 未提交', error)
    except Exception as error:
        print('v4 检查失败', type(error).__name__)
    return 1


if __name__ == '__main__':
    sys.exit(main())
