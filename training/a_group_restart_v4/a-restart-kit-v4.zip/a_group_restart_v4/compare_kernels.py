"""Bounded one-A100 Qwen3.5 fast/slow training-kernel comparison."""
from __future__ import annotations

import argparse
from collections.abc import Mapping
from dataclasses import dataclass
import fcntl
import hashlib
from importlib import metadata
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE.parent / 'a_group_b_native_v1'), str(HERE.parent / 'a_group_c_v1')]
import cuda_map
import resources

ROOT = resources.ROOT
FAST = ROOT / 'envs/env-a100-fast-v2'
C_WORK = ROOT / 'pilots/c_paper_v1'
CHECKPOINT = C_WORK / 'eval_checkpoints/c-paper-one-step/step_1'
TOKENIZER = ROOT / 'models/Qwen3.5-4B'
RECEIPT = FAST / 'kernel_equivalence.json'
REPORTS = ROOT / 'kernel-compare-v4'
PROTOCOL = 'qwen35_one_card_fixed_batch_v1'
HARD_SECONDS = 7200
SOAK_SECONDS = {'slow': 40 * 60, 'fast': 20 * 60}
LIMIT = 10240
RECONSTRUCTIONS = 3
KEYS = ('logprob', 'loss', 'grad_norm')
SEED = 42
MODE_PACKAGES = {
    'transformers': '5.7.0',
    'flash-linear-attention': '0.5.2',
    'fla-core': '0.5.2',
    'causal-conv1d': '1.6.2.post1',
}


class CompareFailure(RuntimeError):
    """A diagnostic label safe for the terminal."""


@dataclass(frozen=True)
class Sequence:
    ids: tuple[int, ...]
    mask: tuple[bool, ...]
    ordinal: bytes


def checked_setup():
    if Path(sys.prefix).resolve() != FAST.resolve() or sys.version_info[:2] != (3, 12):
        raise CompareFailure('请使用独立快路径环境的 Python 3.12')
    if RECEIPT.exists() or RECEIPT.is_symlink():
        raise CompareFailure('快路径通过回执已存在，保留原记录')
    for name, expected in MODE_PACKAGES.items():
        if metadata.version(name).split('+', 1)[0] != expected:
            raise CompareFailure('快路径依赖版本不符')
    result = json.loads((C_WORK / 'c_acceptance.json').read_text())
    if (result.get('merge_verified') is not True or result.get('merge_shards') != 1
            or result.get('merge_keys') != 724):
        raise CompareFailure('C 合并检查点缺少验收回执')
    if (CHECKPOINT.is_symlink() or not (CHECKPOINT / 'config.json').is_file()
            or len(list(CHECKPOINT.glob('*.safetensors'))) != 1 or not TOKENIZER.is_dir()):
        raise CompareFailure('C 检查点或基座 tokenizer 未找到')


def checked_ids(ids):
    if isinstance(ids, Mapping):
        ids = ids.get('input_ids')
    if not isinstance(ids, (tuple, list)) or any(type(x) is not int or x < 0 for x in ids):
        raise CompareFailure('对话重分词格式异常')
    return list(ids)


def reconstruct(messages, tokenizer, identity):
    """Use the native opener and preserve saved teacher text as prediction targets."""
    if (not isinstance(messages, list) or len(messages) < 3
            or any(not isinstance(row, dict) or not isinstance(row.get('content'), str)
                   for row in messages)
            or [row.get('role') for row in messages[:2]] != ['system', 'user']):
        return None
    ids = checked_ids(tokenizer.apply_chat_template(messages[:2], tokenize=True,
                                                    add_generation_prompt=True, enable_thinking=True))
    if not ids or len(ids) > 2048:
        return None
    mask = [False] * len(ids)
    separator = checked_ids(tokenizer.encode('<|im_end|>\n', add_special_tokens=False))
    turns = 0
    for index, row in enumerate(messages[2:], start=2):
        role = 'assistant' if index % 2 == 0 else 'user'
        if row.get('role') != role:
            return None
        if role == 'assistant':
            text = row['content']
            current = checked_ids(tokenizer.encode(text, add_special_tokens=False))
            ids.extend(current)
            mask.extend([True] * len(current))
            turns += bool(current)
            ids.extend(separator)
            mask.extend([False] * len(separator))
        else:
            if index == len(messages) - 1:
                # Saved last user turn has no subsequent teacher target.
                break
            current = checked_ids(tokenizer.apply_chat_template(
                [row], tokenize=True, add_generation_prompt=True, enable_thinking=True))
            ids.extend(current)
            mask.extend([False] * len(current))
    if turns == 0 or len(ids) > LIMIT:
        return None
    return Sequence(tuple(ids), tuple(mask), identity)


def select_mixed(candidates):
    ordered = sorted(candidates, key=lambda row: (len(row.ids), row.ordinal))
    if len(ordered) < RECONSTRUCTIONS:
        raise CompareFailure('C 已保存训练轨迹不足以组建混合批次')
    medium = ordered[(len(ordered) - 1) // 2]
    first, last = ordered[0], ordered[-1]
    if len(last.ids) - len(first.ids) < 512:
        raise CompareFailure('C 轨迹的长短差不足 512 token')
    return [first, medium, last]


def load_rows(tokenizer):
    # C stores train and validation together. Match author prompts to the frozen
    # parquets as the C acceptance program does; never infer split by file order.
    from c_metrics import load_splits, source_hash

    splits = load_splits(ROOT / 'data/author_prepared')
    rows, seen, train_count = [], set(), 0
    for source in sorted((C_WORK / 'eduardo_conversations').glob('conversations_*.jsonl')):
        if source.is_symlink():
            raise CompareFailure('轨迹文件身份异常')
        with source.open(encoding='utf-8') as stream:
            for line in stream:
                if not line.endswith('\n'):
                    raise CompareFailure('C 轨迹记录未写完整')
                row = json.loads(line)
                uid = row['uuid']
                if not isinstance(uid, str) or not uid or uid in seen:
                    raise CompareFailure('C 轨迹身份异常')
                seen.add(uid)
                split = splits.get(source_hash(row['problem']))
                if split is None:
                    raise CompareFailure('C 轨迹未绑定冻结题单')
                if split != 'train':
                    continue
                train_count += 1
                if row.get('note') == 'ok':
                    key = hashlib.sha256(uid.encode()).digest()
                    rebuilt = reconstruct(row['messages'], tokenizer, key)
                    if rebuilt is not None:
                        rows.append(rebuilt)
    if train_count != 256 or len(seen) != 356:
        raise CompareFailure('C 轨迹来源总数和验收不一致')
    return select_mixed(rows), len(rows)


def promote_receipt(path, result):
    # Link a completely written same-filesystem file exclusively. A failed
    # marker write, or a concurrent passed run, cannot overwrite a receipt.
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.kernel-equivalence-', delete=False) as stream:
            temp = Path(stream.name)
            stream.write((json.dumps(result, ensure_ascii=False, allow_nan=False) + '\n').encode())
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temp, path, follow_symlinks=False)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def comparisons(rows):
    base, repeat, fast = rows
    if not base['values'] or len({len(item['values']) for item in rows}) != 1:
        raise CompareFailure('有效 token 的对齐长度不一致')
    result = {}
    for key in KEYS:
        if key == 'logprob':
            values = [r['values'] for r in rows]
            distances = [max(abs(a - b) for a, b in zip(values[0], target)) for target in values[1:]]
        else:
            distances = [abs(base[key] - target[key]) for target in (repeat, fast)]
        if any(not math.isfinite(value) or value < 0 for value in distances):
            raise CompareFailure('内核对照出现非有限值')
        result[key] = {'slow_repeat_abs_diff': distances[0], 'fast_slow_abs_diff': distances[1]}
    return result


def within_repeat(distances):
    return all(value['fast_slow_abs_diff'] <= value['slow_repeat_abs_diff']
               for value in distances.values())


def round_trend(cycles):
    count = len(cycles)
    if not count:
        raise CompareFailure('没有耐久轮次')
    third = max(1, count // 3)
    first, last = cycles[:third], cycles[-third:]
    keys = ('round_seconds', 'ms_per_token', 'loadavg_1')

    def averages(group):
        return {key: math.fsum(row[key] for row in group) / third for key in keys}

    a, b = averages(first), averages(last)
    return {'rounds_per_third': third, 'first': a, 'last': b,
            'last_to_first_wall': b['round_seconds'] / a['round_seconds'],
            'last_to_first_ms_per_token': b['ms_per_token'] / a['ms_per_token']}


def score_result(result):
    if not isinstance(result, dict) or result.get('fast_kernel_verified') is not True:
        raise CompareFailure('实际内核调用未核实')
    result_rows = result['runs']
    if len(result_rows) != 3 or [row.get('mode') for row in result_rows] != ['slow', 'slow', 'fast']:
        raise CompareFailure('内核试验顺序或测量次数异常')
    expected_tokens = sum(result['teacher_tokens'])
    if len(result['sequence_lengths']) != RECONSTRUCTIONS or expected_tokens < 1:
        raise CompareFailure('长短混合批次测量不完整')
    for row in result_rows:
        if (len(row.get('values', ())) != expected_tokens or
                any(type(x) not in (int, float) or not math.isfinite(x) for x in row['values']) or
                any(type(row.get(k)) not in (int, float) or not math.isfinite(row[k]) or row[k] <= 0
                    for k in ('loss', 'grad_norm', 'seconds_per_token'))):
            raise CompareFailure('有效 token、损失、梯度或计时数值异常')
        for alias in ('peak_alloc_mib', 'peak_reserved_mib'):
            if type(row.get(alias)) not in (int, float) or not 0 < row[alias] < 81920:
                raise CompareFailure('显存峰值数值异常')
    distances = comparisons(result_rows)
    equivalent = within_repeat(distances)
    soak = result['endurance']
    stopped_early = result.get('endurance_skipped') is True
    if stopped_early:
        if soak or equivalent:
            raise CompareFailure('耐久提前停止与数值对照不一致')
    elif set(soak) != set(SOAK_SECONDS) or any(
        type(soak[mode].get('elapsed_seconds')) not in (int, float)
        or not math.isfinite(soak[mode]['elapsed_seconds'])
        or soak[mode]['elapsed_seconds'] < duration
        or type(soak[mode].get('cycles')) is not int or soak[mode]['cycles'] < 1
        or type(soak[mode].get('seconds_per_token')) not in (int, float)
        or not math.isfinite(soak[mode]['seconds_per_token'])
        or soak[mode]['seconds_per_token'] <= 0
        or type(soak[mode].get('peak_alloc_mib')) not in (int, float)
        or not 0 < soak[mode]['peak_alloc_mib'] < 81920
        or type(soak[mode].get('peak_reserved_mib')) not in (int, float)
        or not 0 < soak[mode]['peak_reserved_mib'] < 81920
        for mode, duration in SOAK_SECONDS.items()
    ):
        raise CompareFailure('慢 40 分钟及快 20 分钟耐久对照未完成')
    for row in result_rows:
        values = row.pop('values')
        row['logprob_mean'] = math.fsum(values) / len(values)
    result['comparisons'] = distances
    return equivalent


def select_card(stage, gpu):
    first = stage.snapshot()
    time.sleep(5)
    second = stage.snapshot()
    candidates = resources.choose_candidates(stage, 'tutor_1', first, second, set())
    return next((item for item in candidates if gpu is None or item.index == gpu), None)


def display(result, passed):
    print('对照结果', '通过' if passed else '不等价')
    print('实测有效长度', *result['sequence_lengths'])
    print('目标教师 token', *result['teacher_tokens'])
    print('| 指标 | 慢路径重复绝对差 | 快慢绝对差 |')
    print('|---|---:|---:|')
    for key, row in result['comparisons'].items():
        print(f"| {key} | {row['slow_repeat_abs_diff']:.9g} | {row['fast_slow_abs_diff']:.9g} |")
    print('| 阶段 | 平均 logprob | NLL | 梯度范数 | 秒/有效 token | 显存峰值 MiB（allocated / reserved） |')
    print('|---|---:|---:|---:|---:|---:|')
    for index, row in enumerate(result['runs'], 1):
        print(f"| {row['mode']} {index} | {row['logprob_mean']:.8g} | {row['loss']:.8g} | "
              f"{row['grad_norm']:.8g} | {row['seconds_per_token']:.6g} | "
              f"{row['peak_alloc_mib']:.0f} / {row['peak_reserved_mib']:.0f} |")
    for mode, row in result['endurance'].items():
        print(f"| {mode} 耐久 {row['elapsed_seconds']:.0f}s / {row['cycles']} 轮 | — | — | — | "
              f"{row['seconds_per_token']:.6g} | {row['peak_alloc_mib']:.0f} / "
              f"{row['peak_reserved_mib']:.0f} |")


    if result.get('endurance_skipped'):
        print('数值不等价，耐久未开始')
    if result['endurance']:
        print('| 耐久 | 每端轮数 | 首段/末段整轮秒数 | 末/首用时 | 首段/末段 ms/token | 末/首 ms/token | 首段/末段主机负载（1 分钟） |')
        print('|---|---:|---:|---:|---:|---:|---:|')
        for mode, row in result['endurance'].items():
            trend = row['round_trend']
            first, last = trend['first'], trend['last']
            print(f"| {mode} | {trend['rounds_per_third']} | {first['round_seconds']:.2f} / "
                  f"{last['round_seconds']:.2f} | {trend['last_to_first_wall']:.3f} | "
                  f"{first['ms_per_token']:.3f} / {last['ms_per_token']:.3f} | "
                  f"{trend['last_to_first_ms_per_token']:.3f} | "
                  f"{first['loadavg_1']:.2f} / {last['loadavg_1']:.2f} |")


def claim_card(stage, gpu, wait, *, sleep=time.sleep, monotonic=time.monotonic):
    """Wait without the A-group or GPU lock; seal admission under the task lock."""
    while True:
        tried = monotonic()
        binding = select_card(stage, gpu)
        if binding is not None:
            try:
                fd = stage.own_lock()
            except BlockingIOError:
                fd = None
            if fd is not None:
                keep = False
                try:
                    row = stage.snapshot().get(binding.index)
                    if row and row['uuid'] == binding.uuid and stage.eligible(row):
                        keep = True
                        return binding, fd
                finally:
                    if not keep:
                        os.close(fd)
        if not wait:
            raise CompareFailure('未找到可领取的空闲 A100 整卡或 A 组锁正被持有')
        sleep(max(0, 60 - (monotonic() - tried)))


def perform_comparison(binding, deadline, scratch, report_dir):
    print('单卡对照使用 GPU', binding.index, flush=True)
    print('本轮数字记录目录', report_dir, flush=True)
    env = {k: v for k, v in os.environ.items()
           if not k.upper().endswith(('_KEY', '_TOKEN', '_SECRET', '_PASSWORD'))}
    env.update(CUDA_VISIBLE_DEVICES=binding.uuid, CUDA_DEVICE_ORDER='PCI_BUS_ID',
               HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
               HF_HUB_DISABLE_TELEMETRY='1', HF_HUB_DISABLE_PROGRESS_BARS='1',
               TOKENIZERS_PARALLELISM='false', PYTHONDONTWRITEBYTECODE='1',
               TRITON_CACHE_DIR=str(scratch / 'triton'), XDG_CACHE_HOME=str(scratch / 'cache'))
    cmd = [sys.executable, '-B', str(Path(__file__).resolve()), '--worker',
           str(os.getpid()), str(binding.index), binding.uuid, str(deadline), str(report_dir)]
    child = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, start_new_session=True)
    try:
        output, _ = child.communicate(timeout=max(0, deadline - time.monotonic()))
    except subprocess.TimeoutExpired:
        raise CompareFailure('两小时硬上限已到，单卡对照已停止') from None
    finally:
        if child.poll() is None:
            child.kill()
            child.wait(timeout=10)
    if child.returncode in (124, -signal.SIGALRM):
        raise CompareFailure('两小时硬上限已到，单卡对照已停止')
    if child.returncode:
        label = output.strip()
        if label.startswith('COMPARE_FAILURE: ') and label.count('\n') == 0:
            raise CompareFailure(label.removeprefix('COMPARE_FAILURE: '))
        raise CompareFailure('单卡训练内核子进程退出异常')
    result = json.loads(output)
    passed = score_result(result)
    result.update(protocol=PROTOCOL, environment=str(FAST), gpu_index=binding.index, accepted=passed)
    promote_receipt(report_dir / 'comparison-summary.json', result)
    display(result, passed)
    if passed:
        promote_receipt(RECEIPT, result)
        print('等价回执已落盘')
    return int(not passed)


def run(gpu, wait):
    checked_setup()
    if 'CUDA_VISIBLE_DEVICES' in os.environ:
        raise CompareFailure('已带 CUDA_VISIBLE_DEVICES 限制，不能重新解释选卡')
    stage = resources.load_stage_a()
    # One waiter for this experiment. It does not exclude any training job.
    waiter = os.open(ROOT / '.kernel-compare-v4.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(waiter, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise CompareFailure('已有单卡对照进程或等待器') from None
        if RECEIPT.exists() or RECEIPT.is_symlink():
            raise CompareFailure('快路径通过回执已存在，保留原记录')
        if wait:
            print('单卡对照每 60 秒检查空闲卡；领取前不占卡', flush=True)
        binding, fd = claim_card(stage, gpu, wait)
        try:
            deadline = time.monotonic() + HARD_SECONDS
            REPORTS.mkdir(mode=0o700, exist_ok=True)
            if REPORTS.is_symlink():
                raise CompareFailure('数字记录目录不能是链接')
            report_dir = Path(tempfile.mkdtemp(dir=REPORTS, prefix='run-'))
            with tempfile.TemporaryDirectory(prefix='edu-kernel-compare-') as temp:
                return perform_comparison(binding, deadline, Path(temp), report_dir)
        finally:
            os.close(fd)
    finally:
        os.close(waiter)


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--run', action='store_true')
    action.add_argument('--worker', nargs=5, help=argparse.SUPPRESS)
    parser.add_argument('--wait', action='store_true', help='每60秒等待一张空闲整卡')
    parser.add_argument('--gpu', type=int, help='可选物理卡号；仍要求空闲整卡')
    args = parser.parse_args()
    os.umask(0o077)
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    try:
        if args.worker:
            pid, index, uuid, deadline, report_dir = args.worker
            parent, deadline = int(pid), float(deadline)
            resources.load_stage_a().parent_death(parent)
            remaining = deadline - time.monotonic()
            if not math.isfinite(remaining) or remaining <= 0 or remaining > HARD_SECONDS:
                raise TimeoutError()
            # The worker's own watchdog also bounds it if the controller dies.
            signal.signal(signal.SIGALRM, signal.SIG_DFL)
            signal.setitimer(signal.ITIMER_REAL, remaining)
            sys.modules['compare_kernels'] = sys.modules[__name__]
            from compare_training import run_worker
            result = run_worker(int(index), uuid, deadline, Path(report_dir))
            print(json.dumps(result, allow_nan=False))
            return 0
        return run(args.gpu, args.wait)
    except (Exception, KeyboardInterrupt) as exc:
        detail = str(exc) if isinstance(exc, CompareFailure) else type(exc).__name__
        print(('COMPARE_FAILURE: ' if args.worker else '单卡对照未通过 ') + detail)
        return 124 if isinstance(exc, TimeoutError) else 1


if __name__ == '__main__':
    sys.exit(main())
