from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from monitor import MonitoringFailure, RunMonitor, excess_parse_failures


PARSE = b'WARNING:eduardo.metrics.judge_quality:Failed to parse judge response, defaulting to REJECT: synthetic\n'
RECOVERY = b'WARNING:eduardo.metrics.judge_quality:Judge JSON malformed, recovered decision via regex: OK\n'
FALLBACK = b'ERROR:eduardo.utils:[judge] non-retriable 400 (http_400); using fallback to keep training alive.\n'
EXHAUST = b'ERROR:eduardo.utils:[judge] gave up after 3 retries, using fallback.\n'
HARD = b'EduardoInteraction: student call failed hard\n'
HTTP = b'(APIServer pid=41) [C_HTTP 1781903302.123456] "POST /v1/chat/completions HTTP/1.1" 200 OK\n'


class RunMonitorTests(unittest.TestCase):
    def setUp(self):
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        self.work = root / 'pilot'
        self.work.mkdir()
        ray = root / 'ray'
        worker_logs = ray / 'session_abc' / 'logs'
        worker_logs.mkdir(parents=True)
        (ray / 'session_latest').symlink_to(worker_logs.parent)
        self.worker = worker_logs / 'worker-abc-123.err'
        self.worker.write_bytes(b'initialization\n')
        self.judge = self.work / 'judge.log'
        self.judge.touch()
        self.trainer = self.work / 'trainer.log'
        self.trainer.touch()
        self.monitor = RunMonitor(self.work, ray)

    @staticmethod
    def append(path, data):
        with path.open('ab') as out:
            out.write(data)

    def test_parse_counts_and_continues_below_threshold(self):
        phase = self.monitor.begin()
        self.append(self.worker, PARSE)
        self.append(self.trainer, PARSE)
        self.append(self.judge, HTTP * 101)
        self.monitor.poll()
        self.assertEqual(self.monitor.end(phase), {'requests': 101, 'parse': 1, 'recovery': 0})
        self.monitor.finish()

    def test_regex_recovery_counts_and_continues(self):
        phase = self.monitor.begin()
        self.append(self.worker, RECOVERY)
        self.append(self.judge, HTTP)
        self.monitor.poll()
        self.assertEqual(self.monitor.end(phase), {'requests': 1, 'parse': 0, 'recovery': 1})
        self.monitor.finish()

    def test_judge_excerpt_does_not_override_parse_classification(self):
        phase = self.monitor.begin()
        self.append(self.worker, PARSE.rstrip(b'\n') + b' ' + EXHAUST)
        self.append(self.judge, HTTP * 100)
        self.monitor.poll()
        self.assertEqual(self.monitor.end(phase), {'requests': 100, 'parse': 1, 'recovery': 0})

    def test_fallback_is_terminal_live_and_for_phase(self):
        phase = self.monitor.begin()
        self.append(self.worker, FALLBACK)
        with self.assertRaisesRegex(MonitoringFailure, '请求回退'):
            self.monitor.poll()
        with self.assertRaisesRegex(MonitoringFailure, '请求回退'):
            self.monitor.end(phase)

    def test_other_terminal_markers(self):
        for line, label in ((EXHAUST, '重试耗尽'), (HARD, '学生交互硬失败')):
            with self.subTest(label=label):
                self.trainer.write_bytes(line)
                monitor = RunMonitor(self.work, self.monitor.raytmp)
                with self.assertRaisesRegex(MonitoringFailure, label):
                    monitor.poll()

    def test_exact_threshold_and_validation_scope(self):
        self.assertFalse(excess_parse_failures(15, 1536))
        self.assertTrue(excess_parse_failures(16, 1536))
        self.assertFalse(excess_parse_failures(1, 100))
        self.assertTrue(excess_parse_failures(1, 99))
        phase = self.monitor.begin()
        self.append(self.worker, PARSE * 16)
        self.append(self.judge, HTTP * 1536)
        self.assertEqual(self.monitor.end(phase, enforce=False)['parse'], 16)
        with self.assertRaisesRegex(MonitoringFailure, '超过请求的 1%') as exc:
            self.monitor.end(phase)
        self.assertEqual(exc.exception.counts, {'requests': 1536, 'parse': 16, 'recovery': 0})

    def test_rotated_log_counts_once_excluding_preceding_batch(self):
        self.append(self.worker, PARSE)
        self.append(self.judge, HTTP)
        self.monitor.poll()
        phase = self.monitor.begin()
        self.append(self.worker, RECOVERY)
        self.worker.rename(self.worker.with_name(self.worker.name + '.1'))
        self.worker.write_bytes(PARSE)
        self.append(self.judge, HTTP * 200)
        self.monitor.poll()
        self.assertEqual(self.monitor.end(phase), {'requests': 200, 'parse': 1, 'recovery': 1})

    def test_live_scan_retains_split_line(self):
        self.append(self.worker, FALLBACK[:57])
        self.monitor.poll()
        self.append(self.worker, FALLBACK[57:])
        with self.assertRaisesRegex(MonitoringFailure, '请求回退'):
            self.monitor.poll()

    def test_fails_on_unavailable_log_segment(self):
        phase = self.monitor.begin()
        self.worker.unlink()
        with self.assertRaisesRegex(MonitoringFailure, '轮转覆盖不完整'):
            self.monitor.end(phase)


if __name__ == '__main__':
    unittest.main()
