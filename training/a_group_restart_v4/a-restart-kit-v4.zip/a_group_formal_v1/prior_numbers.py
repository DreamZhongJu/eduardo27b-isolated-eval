"""Read only the finished B and C runs. Print numeric evidence without raw records."""

import argparse
from collections import defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import subprocess


ROOT = Path('/workspace/A_group_repro_20261117')
MIN_FREE_BYTES = 150_000_000_000
UNKNOWN = '未知'
ACTOR_KEYS = ('actor/grad_norm', 'actor/pg_loss', 'actor/lr')
PROBABILITY_KEYS = (
    'training/rollout_probs_diff_mean',
    'training/rollout_probs_diff_max',
    'training/rollout_probs_diff_std',
    'training/rollout_actor_probs_pearson_corr',
    'training/rollout_probs_diff_valid',
)
TIMING_KEYS = (
    'timing_s/step', 'timing_s/gen', 'timing_s/reward', 'timing_s/update_actor',
    'timing_s/save_checkpoint', 'timing_s/update_weights', 'timing_s/testing',
)
HEADER = re.compile(r'(?<!\S)step:(\d+)\s+-\s')
GLOBAL = re.compile(r'(?:^|\s-\s)training/global_step:([0-9]+)(?=\s|$)')
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
SCALAR = r'[+-]?(?:(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|inf(?:inity)?|nan)'
VALUE = re.compile(
    r'(?:^|\s-\s)(' + '|'.join(re.escape(key) for key in (*ACTOR_KEYS, *PROBABILITY_KEYS, *TIMING_KEYS))
    + rf'):(?:(?:np|numpy)\.float(?:16|32|64)\(({SCALAR})\)|({SCALAR}))(?=\s|$)', re.I,
)


def read_metrics(path, step):
    """Accept only genuine step rows and unambiguous metrics, including copied Ray lines."""
    values = defaultdict(set)
    try:
        with Path(path).open(encoding='utf-8', errors='replace') as stream:
            for line in stream:
                text = ANSI.sub('', line)
                headers = HEADER.findall(text)
                global_steps = GLOBAL.findall(text)
                if headers != [str(step)] or global_steps != headers:
                    continue
                for key, wrapped, bare in VALUE.findall(text):
                    value = float(wrapped or bare)
                    values[key.lower()].add(value if math.isfinite(value) else str(value))
    except OSError:
        return {}
    return {key: next(iter(items)) for key, items in values.items() if len(items) == 1}


def count_c_score_groups(work, checkpoint_dir):
    """Use author's recorded score and veRL's float32 reward precision."""
    groups = defaultdict(list)
    validation, seen = set(), set()
    marker = checkpoint_dir / 'latest_checkpointed_iteration.txt'
    try:
        if marker.is_symlink() or marker.read_text().strip() != '1':
            return None
        boundary = marker.stat().st_mtime_ns / 1e9
        for path in (work / 'eduardo_conversations').glob('conversations_*.jsonl'):
            with path.open(encoding='utf-8') as stream:
                for line in stream:
                    row = json.loads(line)
                    uid, problem, transfer = (row[key] for key in ('uuid', 'problem', 'transfer_problem'))
                    ts, score = row['ts'], row['score']
                    if (not isinstance(uid, str) or not uid or uid in seen
                            or not isinstance(problem, str) or not problem.strip()
                            or not isinstance(transfer, str)
                            or type(ts) not in (int, float) or not math.isfinite(ts)
                            or ts <= 0 or ts == boundary
                            or type(score) not in (int, float) or not math.isfinite(score)):
                        return None
                    seen.add(uid)
                    source = hashlib.sha256(problem.encode('utf-8')).digest()
                    transfer_id = hashlib.sha256(transfer.encode('utf-8')).digest()
                    if ts > boundary:
                        if source in validation:
                            return None
                        validation.add(source)
                        continue
                    reward, = struct.unpack('f', struct.pack('f', score))
                    if not math.isfinite(reward):
                        return None
                    groups[source].append((transfer_id, reward))
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, OverflowError, struct.error):
        return None
    if len(validation) != 100 or len(groups) != 16 or validation.intersection(groups):
        return None
    if any(len(group) != 16 or len({transfer for transfer, _ in group}) != 1 for group in groups.values()):
        return None
    return sum(len({reward for _, reward in group}) > 1 for group in groups.values())


def command(args):
    """Suppress stderr because coreutils diagnostics may include local paths."""
    try:
        proc = subprocess.run(args, capture_output=True, text=True, env=dict(os.environ, LC_ALL='C'),
                              timeout=120, check=False)
        return proc.stdout.splitlines() if proc.returncode == 0 else []
    except (OSError, subprocess.TimeoutExpired):
        return []


def disk_free_bytes(workspace):
    rows = command(['df', '-B1', '--output=avail', '--', str(workspace)])
    value = rows[-1].strip() if len(rows) == 2 else ''
    return int(value) if value.isdecimal() else None


def disk_size(path):
    rows = command(['du', '-B1', '-s', '--', str(path)])
    number, sep, _ = rows[0].partition('\t') if len(rows) == 1 else ('', '', '')
    return int(number) if sep and number.isdecimal() else None


def size_gib(value):
    return f'{value / 2**30:.2f}' if value is not None else UNKNOWN


def print_disk(workspace, folders):
    rows = command(['df', '-h', '--output=size,used,avail,pcent', '--', str(workspace)])
    print('df -h（总量 已用 可用 占比）', ' '.join(rows[-1].split()) if len(rows) == 2 else UNKNOWN)
    free = disk_free_bytes(workspace)
    print('可用字节', free if free is not None else UNKNOWN)
    print('可用空间低于 150 GB', int(free < MIN_FREE_BYTES) if free is not None else UNKNOWN)
    print('\n| 已占用磁盘块 | GiB |\n| --- | ---: |')
    for label, folder in folders:
        print(f'| {label} | {size_gib(disk_size(folder))} |')
    usage = command(['du', '-B1', '-s', '-c', '--', *(str(path) for _, path in folders)])
    number, sep, label = usage[-1].partition('\t') if usage else ('', '', '')
    total = int(number) if sep and label == 'total' and number.isdecimal() else None
    print(f'| 合计（硬链接去重） | {size_gib(total)} |')


def display(value):
    if value is None:
        return UNKNOWN
    return value if isinstance(value, str) else f'{value:.12g}'


def report(root):
    b_work = root / 'pilots/b_native_b09d2fb'
    c_work = root / 'pilots/c_paper_v1'
    b_ckpt = b_work / 'verl_ckpts/b-functional'
    c_ckpt = c_work / 'verl_ckpts/c-paper-one-step'
    b_exports = root / 'b-accept-b09d2fb-v1/checkpoints'
    c_exports = c_work / 'eval_checkpoints/c-paper-one-step'

    b_metrics = read_metrics(b_work / 'trainer.log', 1)
    c_metrics = read_metrics(c_work / 'trainer.log', 1)
    print('| 指标 | B 第 1 步 | C 第 1 步 |\n| --- | ---: | ---: |')
    for key in (*ACTOR_KEYS, *PROBABILITY_KEYS):
        print(f'| `{key}` | {display(b_metrics.get(key))} | {display(c_metrics.get(key))} |')
    groups = count_c_score_groups(c_work, c_ckpt)
    print(f'| 组内奖励不全相同 | — | {f"{groups}/16" if groups is not None else UNKNOWN} |')
    print()
    print_disk(root.parent, [
        ('B 第 1 步检查点', b_ckpt / 'global_step_1'),
        ('B 第 2 步检查点', b_ckpt / 'global_step_2'),
        ('C 第 1 步检查点', c_ckpt / 'global_step_1'),
        ('B 第 1 步导出权重', b_exports / 'step_1'),
        ('B 第 2 步导出权重', b_exports / 'step_2'),
        ('C 第 1 步导出权重', c_exports / 'step_1'),
    ])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    report(parser.parse_args().root)
