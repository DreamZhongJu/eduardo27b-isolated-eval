#!/usr/bin/env bash
set -eu
umask 077
pkg=$(cd "$(dirname "$0")" && pwd)
root=/workspace/A_group_repro_20261117
py="$root/envs/env-candidate-vllm0191/bin/python"
name=a_formal_v1
resume=()
if [[ $# -eq 2 && $1 == --resume && $2 =~ ^([5]|[1-9][05])$ ]]; then
  name="a_formal_r${2}_$(date +%Y%m%d%H%M%S)"
  resume=(--resume "$2")
elif [[ $# -eq 1 && $1 == --restart-before-checkpoint ]]; then
  name="a_formal_r0_$(date +%Y%m%d%H%M%S)"
elif [[ $# -ne 0 ]]; then
  echo '启动参数无效'
  exit 1
fi
if [[ -e "$root/pilots/$name" || -e "$root/pilots/$name-launch.log" ]]; then
  "$py" -B "$pkg/formal_status.py" --name "$name"
  exit 1
fi
if [[ $name == a_formal_v1 && -e "$root/formal_a_v1" ]]; then
  echo '正式训练已有记录'
  exit 1
fi
mkdir -p "$root/pilots"
# The established reservation lock protects all A-group GPU starts.
"$py" -B "$pkg/../a_group_b_native_v1/stop_old_waiter.py"
set -o noclobber
exec 3>"$root/pilots/$name-launch.log"
nohup "$py" -B "$pkg/formal_stage.py" --run --name "$name" "${resume[@]}" < /dev/null >&3 2>&1 &
echo "正式训练后台已提交。运行名 $name"
echo "查看状态：$py -B $pkg/formal_status.py --name $name"
