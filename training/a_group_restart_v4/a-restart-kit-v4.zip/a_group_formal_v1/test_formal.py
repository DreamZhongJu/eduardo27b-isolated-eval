import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

import checkpoints
import formal_config
import formal_trainer
import trajectories


class FormalTest(unittest.TestCase):
    def test_native_configuration_limits(self):
        args = formal_config.overrides(Path('/tmp/run'), '/tmp/r', 'student', '/tmp/i')
        args = dict(x.split('=', 1) for x in args)
        self.assertEqual(args['trainer.total_training_steps'], '100')
        self.assertEqual(args['trainer.save_freq'], '5')
        self.assertEqual(args['trainer.resume_mode'], 'disable')
        self.assertEqual(args['actor_rollout_ref.rollout.n'], '16')
        self.assertEqual(args['actor_rollout_ref.actor.checkpoint.load_contents'], '[model,optimizer,extra]')
        resume = formal_config.overrides(Path('/tmp/run'), '/tmp/r', 'student', '/tmp/i', 25)
        self.assertIn('trainer.resume_mode=resume_path', resume)
        self.assertTrue(any(x.endswith('/global_step_25') for x in resume))

    def test_real_loader_state_shapes(self):
        self.assertEqual(checkpoints.position({'_num_yielded': 5}), 5)
        self.assertEqual(checkpoints.position({'_snapshot': {'_snapshot_step': 5},
                                               '_steps_since_snapshot': 2}), 7)
        with self.assertRaises(checkpoints.CheckpointFailure):
            checkpoints.position({'_snapshot': {'_snapshot_step': 4}})

    def test_identity_binding_checks_correct_answer_and_uuid(self):
        with tempfile.TemporaryDirectory() as temp:
            home = Path(temp)
            folder = home / 'eduardo_conversations'
            folder.mkdir()
            file = folder / 'conversations_1.jsonl'
            row = dict(uuid='r1', problem='A', ground_truth='B', transfer_problem='C', transfer_answer='D',
                       gated=0, judge_pass=1, note='ok', messages=[{'role': 'assistant', 'content': 'hint'}])
            batch = SimpleNamespace(non_tensor_batch={'extra_info': [
                {'split': 'train', 'problem': 'A', 'transfer_problem': 'C', 'transfer_answer': 'D'}],
                'reward_model': [{'ground_truth': 'B'}]})
            wanted = trajectories.expected(batch, 1, 'train')
            file.write_text(json.dumps(row) + '\n')
            auditor = trajectories.Rows(home)
            view = auditor.completed_phase(wanted, str)
            self.assertEqual((view['passed'], view['invisible'], view['judgeable']), (1, 0, 1))
            with file.open('a') as f:
                f.write(json.dumps(row) + '\n')
            with self.assertRaises(trajectories.IdentityFailure):
                auditor.completed_phase(wanted)
            file.write_text(json.dumps(dict(row, transfer_answer='different')) + '\n')
            with self.assertRaises(trajectories.IdentityFailure):
                trajectories.Rows(home).completed_phase(wanted)

    def test_keep_two_completed_and_keep_all_exports(self):
        with tempfile.TemporaryDirectory() as temp, mock.patch.object(checkpoints.verification, 'inspect_input',
                                                                        return_value=({}, 5)):
            root = Path(temp)
            store = checkpoints.Store(root / 'series')
            work = root / 'work'
            work.mkdir()
            store.prepare(None, work)
            def merger(path, target, source_config):
                target.mkdir()
                (target / 'config.json').write_text('{}')
                return {'merge_shards': 1}
            pointer = store.checkpoints / 'latest_checkpointed_iteration.txt'
            for step in range(5, 101, 5):
                store.checkpoint(step).mkdir()
                pointer.write_text(str(step))
                store.verified(step, step, {}, merger)
            self.assertEqual(store.accepted(), [95, 100])
            self.assertEqual(sorted(x.name for x in store.exports.iterdir()),
                             ['step_100', 'step_25', 'step_50', 'step_75'])

    def test_resume_quarantines_incomplete_checkpoint(self):
        with tempfile.TemporaryDirectory() as temp, mock.patch.object(checkpoints.verification, 'inspect_input',
                                                                        return_value=({}, 5)):
            root = Path(temp)
            store = checkpoints.Store(root / 'series')
            work = root / 'work'
            work.mkdir()
            store.prepare(None, work)
            pointer = store.checkpoints / 'latest_checkpointed_iteration.txt'
            store.checkpoint(5).mkdir()
            pointer.write_text('5')
            store.verified(5, 5, {}, None)
            store.checkpoint(10).mkdir()
            pointer.write_text('10')
            store.prepare(5, work)
            self.assertEqual(pointer.read_text(), '5')
            self.assertTrue((work / 'uncommitted' / 'checkpoints-global_step_10').is_dir())

    def test_insufficient_http_coverage_is_fatal(self):
        with self.assertRaises(formal_trainer.MonitoringFailure):
            formal_trainer.verify_judge_coverage({'requests': 5}, {'judgeable': 1})
        formal_trainer.verify_judge_coverage({'requests': 6}, {'judgeable': 1})


if __name__ == '__main__':
    unittest.main()
