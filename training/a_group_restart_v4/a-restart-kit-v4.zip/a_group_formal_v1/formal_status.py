"""Display only numeric and fixed-label receipts from inside the container."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'a_group_b_native_v1'))
import status as base

import formal_config as cfg
from checkpoints import Store
from prior_numbers import ACTOR_KEYS, PROBABILITY_KEYS, TIMING_KEYS
from formal_trainer import diagnostics_row


def controller(work, state):
    pid = state.get('controller_pid')
    if type(pid) is not int or pid < 1:
        return '未发现'
    try:
        args = (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0')
        script = os.fsencode(HERE / 'formal_stage.py')
        if script in args and b'--name' in args and args[args.index(b'--name') + 1] == os.fsencode(work.name):
            return '运行中'
    except (OSError, IndexError):
        pass
    return '未发现'


def report(name):
    work = cfg.c.ROOT / 'pilots' / name
    state = base.read_obj(work / 'orchestration.json')
    stage = state.get('phase', '未开始')
    if stage == '凑卡':
        stage = base.read_obj(work / 'resources.json').get('phase', '凑卡')
    restore = base.read_obj(work / 'restore.json')
    base.table(('项目', '状态'), [
        ('阶段', stage),
        ('原因类别', state.get('reason') or '—'),
        ('控制器', controller(work, state)),
        ('恢复全局步', restore.get('global_step', '未知')),
        ('恢复数据批位置', restore.get('data_batches', '未知')),
        ('已交接角色', state.get('bindings', {})),
    ])
    failure = base.read_obj(work / 'failure.json')
    if failure:
        counts = failure.get('counts', {})
        print('训练器失败类别', failure['reason'])
        if counts:
            base.table(('触发步', '裁判请求', '解析失败', '正则恢复'),
                       [(failure.get('step'), counts.get('requests'), counts.get('parse'), counts.get('recovery'))])
    latest = base.read_obj(work / 'latest-step.json')
    stats = base.read_obj(work / 'step-2.json')
    if stats:
        print('\n第 2 步')
        step_stats(stats)
    if latest and latest.get('step') != 2:
        print('\n最近完成步')
        step_stats(latest)
    milestone = base.read_obj(Store().receipt(25))
    if milestone.get('merge_shards'):
        base.table(('第 25 步合并', '数值'), [
            ('分片', milestone['merge_shards']), ('张量键', milestone.get('merge_keys', '未知')),
            ('CPU 合并秒数', milestone.get('merge_seconds', '未知')),
        ])


def step_stats(row):
    base.table(('步', '放行', '全程无可见发言', '约达上限回合', '裁判请求', '解析失败', '正则恢复',
                'grad_norm', 'pg_loss', 'step 秒', '剩余 GB'), [diagnostics_row(row)])
    keys = ACTOR_KEYS + PROBABILITY_KEYS + TIMING_KEYS
    base.table(('步指标', '数值'), [('数据批位置', row['data_batches'])]
               + [(key, row['metrics'].get(key, '未知')) for key in keys])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='a_formal_v1')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,39}', args.name):
        parser.error('运行名格式异常')
    report(args.name)
