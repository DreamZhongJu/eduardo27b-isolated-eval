"""Store only audited native checkpoint states. Old B/C runs are outside this store."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

import formal_config as cfg

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'a_group_b_native_v1'))
import verify_checkpoints as verification

VERSION = cfg.PROFILE.replace('_', '-') if cfg.V4 else {
    'four': 'formal-a-v1', 'six_v2': 'formal-a-speed-v2', 'restart_v3': 'formal-a-restart-v3',
}[cfg.PROFILE]
VERSION += '/full-optimizer/100'
if cfg.V4:
    VERSION += f'/optimizer-offload-{int(cfg.OPTIMIZER_OFFLOAD)}'
# One C checkpoint was about 54.6 GB. Leave room for background writes while saving.
NEXT_SAVE_BYTES = 60_000_000_000
MERGE_BYTES = 12_000_000_000


class CheckpointFailure(RuntimeError):
    pass


def write_json(path, data):
    fd, name = tempfile.mkstemp(dir=path.parent, prefix='.state-')
    temp = Path(name)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def position(state):
    # torchdata's single-process and multi-worker iterator formats differ.
    if isinstance(state, dict):
        number = state.get('_num_yielded')
        if type(number) is int and number >= 0:
            return number
        snapshot = state.get('_snapshot')
        if isinstance(snapshot, dict):
            parts = snapshot.get('_snapshot_step'), state.get('_steps_since_snapshot')
            if all(type(part) is int and part >= 0 for part in parts):
                return sum(parts)
    raise CheckpointFailure('原生数据加载位置不可核对')


class Store:
    def __init__(self, root=cfg.SERIES):
        self.root = Path(root)
        self.checkpoints = self.root / 'checkpoints'
        self.exports = self.root / 'exports'
        self.receipts = self.root / 'verified'
        self.owner = self.root / 'format.json'

    def checkpoint(self, step):
        return self.checkpoints / f'global_step_{step}'

    def artifact(self, step):
        return self.exports / f'step_{step}'

    def receipt(self, step):
        return self.receipts / f'step_{step}.json'

    def record(self, step):
        try:
            path = self.receipt(step)
            if path.is_symlink():
                raise ValueError
            receipt = json.loads(path.read_text())
            if receipt.get('step') == step and receipt.get('data_batches') == step:
                return receipt
        except (OSError, ValueError, AttributeError):
            pass
        raise CheckpointFailure('缺少完整检查点验收回执')

    def input(self, step):
        target = self.checkpoint(step)
        try:
            if target.is_symlink() or not target.is_dir() or any(p.is_symlink() for p in target.rglob('*')):
                raise ValueError
            source, count = verification.inspect_input(target, world_size=cfg.TUTOR_COUNT)
            if count == 2 * cfg.TUTOR_COUNT + 1:
                return source
        except (OSError, ValueError, TypeError):
            pass
        raise CheckpointFailure('完整检查点缺少模型、优化器或数据位置')

    def check_existing(self):
        if (any(p.is_symlink() or not p.is_dir()
                for p in (self.root, self.checkpoints, self.exports, self.receipts))
                or self.owner.is_symlink()
                or json.loads(self.owner.read_text()) != {'format': VERSION}):
            raise CheckpointFailure('正式检查点目录与协议不一致')

    def accepted(self):
        steps = []
        for path in self.checkpoints.glob('global_step_*'):
            tail = path.name[len('global_step_'):]
            if tail.isascii() and tail.isdigit():
                step = int(tail)
                if path == self.checkpoint(step) and self.receipt(step).is_file():
                    self.record(step)
                    steps.append(step)
        return sorted(steps)

    def prepare(self, resume, work):
        """Called under the existing single-controller lock before starting the trainer."""
        if resume is None:
            if self.root.exists():
                self.check_existing()
                if any(self.receipts.iterdir()):
                    raise CheckpointFailure('已有完整检查点，须显式续跑')
                self.quarantine_uncommitted(0, work)
                (self.checkpoints / 'latest_checkpointed_iteration.txt').unlink(missing_ok=True)
            else:
                self.root.mkdir(mode=0o700)
                for path in (self.checkpoints, self.exports, self.receipts):
                    path.mkdir(mode=0o700)
                write_json(self.owner, {'format': VERSION})
            return
        self.check_existing()
        steps = self.accepted()
        if not steps or steps[-1] != resume or resume >= cfg.TOTAL:
            raise CheckpointFailure('只能从最近一个已验收的正式检查点续跑')
        self.input(resume)
        self.quarantine_uncommitted(resume, work)
        pointer = self.checkpoints / 'latest_checkpointed_iteration.txt'
        if pointer.is_symlink():
            raise CheckpointFailure('检查点指针格式异常')
        temp = work / 'checkpoint-pointer.tmp'
        with temp.open('x') as stream:
            stream.write(str(resume))
        temp.replace(pointer)
        self.prune()

    def quarantine_uncommitted(self, resume, work):
        quarantine = work / 'uncommitted'
        for root, prefix in ((self.checkpoints, 'global_step_'), (self.exports, 'step_')):
            for path in root.glob(prefix + '*'):
                tail = path.name[len(prefix):]
                if tail.isascii() and tail.isdigit() and int(tail) > resume:
                    if self.receipt(int(tail)).exists():
                        raise CheckpointFailure('存在更新的已验收结果')
                    quarantine.mkdir(mode=0o700, exist_ok=True)
                    path.rename(quarantine / (root.name + '-' + path.name))

    def before_save(self, step):
        target = self.checkpoint(step)
        if target.exists() or target.is_symlink():
            raise CheckpointFailure('目标检查点目录已存在')
        minimum = NEXT_SAVE_BYTES + (MERGE_BYTES if step in cfg.MILESTONES else 0)
        if shutil.disk_usage(self.root).free < minimum:
            raise CheckpointFailure('剩余磁盘不足以安全写入下一检查点')

    def verified(self, step, data_batches, report, merge):
        if data_batches != step:
            raise CheckpointFailure('检查点的训练数据位置异常')
        if (self.checkpoints / 'latest_checkpointed_iteration.txt').read_text().strip() != str(step):
            raise CheckpointFailure('原生检查点步号不一致')
        source = self.input(step)
        if self.receipt(step).exists() or self.receipt(step).is_symlink():
            raise CheckpointFailure('正式检查点回执已存在')
        if step in cfg.MILESTONES:
            report.update(merge(self.checkpoint(step), self.artifact(step), source))
        report.update(step=step, data_batches=data_batches,
                      disk_free_gb=round(shutil.disk_usage(self.root).free / 1e9, 2))
        write_json(self.receipt(step), report)
        self.prune()

    def prune(self):
        for corpse in self.checkpoints.glob('.retired-global_step_*'):
            suffix = corpse.name[len('.retired-global_step_'):]
            if not suffix.isascii() or not suffix.isdigit() or not self.receipt(int(suffix)).is_file() or corpse.is_symlink():
                raise CheckpointFailure('等待清理的旧检查点身份异常')
            shutil.rmtree(corpse)
        for step in self.accepted()[:-2]:
            self.input(step)
            if step in cfg.MILESTONES and not (self.artifact(step) / 'config.json').is_file():
                raise CheckpointFailure('里程碑导出未保存，保留完整检查点')
            owned = self.checkpoint(step)
            retired = owned.with_name('.retired-' + owned.name)
            owned.rename(retired)
            shutil.rmtree(retired)


def cpu_merge(work, source, target, source_config):
    """Isolate CPU merge output until the author merger and safetensor audit pass."""
    if target.exists() or target.is_symlink():
        raise CheckpointFailure('里程碑导出已存在')
    work = Path(work)
    staging = work / f'{target.name}-unverified'
    with (work / f'{target.name}-cpu-merge.log').open('xb') as log:
        started = time.monotonic()
        result = subprocess.run([sys.executable, '-B', '-m', 'verl.model_merger', 'merge',
                                 '--backend', 'fsdp', '--local_dir', str(source / 'actor'),
                                 '--target_dir', str(staging)], cwd=work,
                                env=dict(os.environ, CUDA_VISIBLE_DEVICES='', WANDB_MODE='disabled',
                                         HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1'),
                                stdout=log, stderr=subprocess.STDOUT)
    if result.returncode != 0:
        raise CheckpointFailure('CPU 合并子进程非零退出')
    shards, keys = verification.inspect_export(staging, source_config)
    staging.rename(target)
    return {'merge_shards': shards, 'merge_keys': keys,
            'merge_seconds': round(time.monotonic() - started, 2)}
