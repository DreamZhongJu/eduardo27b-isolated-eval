import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest

import prior_numbers as numbers


class PriorNumbersTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name) / 'work'
        self.b = self.root / 'pilots/b_native_b09d2fb'
        self.c = self.root / 'pilots/c_paper_v1'
        self.ckpt = self.c / 'verl_ckpts/c-paper-one-step'
        self.ckpt.mkdir(parents=True)
        self.b.mkdir(parents=True)

    def test_metrics_require_the_same_real_step_and_one_value(self):
        log = self.c / 'trainer.log'
        row = ('\x1b[36m(TaskRunner pid=7)\x1b[0m step:1 - actor/grad_norm:0.125 - '
               'actor/pg_loss:-1.5e-3 - actor/lr:numpy.float64(1e-6) - '
               'training/rollout_probs_diff_mean:np.float32(0.004) - '
               'training/rollout_probs_diff_valid:1 - training/global_step:1\n')
        log.write_text(row * 2 + 'step:2 - training/global_step:1 - actor/lr:100\n'
                       'ordinary training/global_step:1 - actor/lr:100\n'
                       'step:1 - training/global_step:1 - actor/pg_loss:-1.6e-3\n', encoding='utf-8')
        self.assertEqual(numbers.read_metrics(log, 1), {
            'actor/grad_norm': 0.125, 'actor/lr': 1e-6, 'training/rollout_probs_diff_mean': 0.004,
            'training/rollout_probs_diff_valid': 1,
        })

    def test_score_groups_are_phase_bound_use_float32_and_detect_duplicate_ids(self):
        marker = self.ckpt / 'latest_checkpointed_iteration.txt'
        marker.write_text('1', encoding='utf-8')
        os.utime(marker, (100, 100))
        directory = self.c / 'eduardo_conversations'
        directory.mkdir()
        log = directory / 'conversations_1.jsonl'
        rows = [dict(uuid=f'{group}-{i}', problem=f'private problem {group}', transfer_problem='private variant',
                     ts=99.0, score=(1.0 + 0.001 * i if group < 7 else 1.0 + 1e-10 * i))
                for group in range(16) for i in range(16)]
        rows += [dict(uuid=f'v{i}', problem=f'private val {i}', transfer_problem='private variant', ts=101.0,
                      score=2.0) for i in range(100)]
        log.write_text(''.join(f'{json.dumps(row)}\n' for row in rows), encoding='utf-8')
        self.assertEqual(numbers.count_c_score_groups(self.c, self.ckpt), 7)
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            numbers.report(self.root)
        self.assertIn('7/16', out.getvalue())
        self.assertNotIn('private', out.getvalue())
        self.assertNotIn(str(self.root), out.getvalue())
        with log.open('a', encoding='utf-8') as stream:
            stream.write(f'{json.dumps(rows[0])}\n')
        self.assertIsNone(numbers.count_c_score_groups(self.c, self.ckpt))


if __name__ == '__main__':
    unittest.main()
