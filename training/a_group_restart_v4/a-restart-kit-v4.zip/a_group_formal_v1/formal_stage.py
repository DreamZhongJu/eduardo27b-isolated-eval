"""Single-controller A group run. Start only on explicit operator invocation."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'a_group_b_native_v1'))
sys.path.insert(0, str(HERE.parent / 'a_group_c_v1'))

import b_stage as pilot
import c_stage as c
import formal_config as cfg
from checkpoints import CheckpointFailure, Store
from monitor import MonitoringFailure, RunMonitor
from trajectories import IdentityFailure

SPEED_DIR = HERE.parent / 'a_group_speed_v2'
RESTART_DIR = HERE.parent / 'a_group_restart_v3'
V4_DIR = HERE.parent / 'a_group_restart_v4'
if cfg.RESTART:
    sys.path.insert(0, str(RESTART_DIR))
    from gpu_guard import GPUGuard, GPUProtection
    from memory_budget import JUDGE_FRACTION
    import gpu_process_monitor
    from restart_control import CANDIDATE_RUN, RECEIPT
    from host_profile import start_if_due

if cfg.V4:
    sys.path.insert(0, str(V4_DIR))
    from telemetry import Sampler

deviations = (V4_DIR if cfg.V4 else RESTART_DIR if cfg.RESTART else SPEED_DIR if cfg.SPEED else HERE) / 'deviations.md'
student_full = cfg.RESTART
require_full_set = cfg.RESTART
legacy_gpu_sampler = not cfg.V4
scanner_type = RunMonitor
TUTOR_COUNT = cfg.TUTOR_COUNT
selected_gpus = ()


def resume_step():
    return int(os.environ['FORMAL_START']) or None


def preflight_config(work, raytmp, student_name, interaction):
    import pyarrow.parquet as pq
    from omegaconf import OmegaConf
    import json

    data = cfg.c.DATA
    manifest = json.loads((data / 'materialization_manifest.json').read_text())
    cfg.c.check_pool(manifest, {name: pq.ParquetFile(data / name).metadata.num_rows
                                for name in cfg.c.SPLIT_ROWS})
    entries = OmegaConf.to_container(OmegaConf.load(interaction), resolve=True)['interaction']
    if len(entries) != 1 or entries[0]['name'] != 'eduardo':
        raise ValueError('正式学生交互配置异常')
    cfg.c._expect(entries[0]['config'], {'student_model': student_name, 'student_api_base': cfg.c.STUDENT_API_BASE,
                                        'student_api_key_env': 'SERVING_API_KEY', 'student_concurrency': 16})
    minimum = cfg.SPACE_FLOOR
    if cfg.V4:
        from layout import disk_required
        minimum = disk_required(cfg.SERIES, resume_step() or 0)
    if shutil.disk_usage(cfg.c.ROOT).free < minimum:
        raise CheckpointFailure('可用磁盘未达到本次检查点预留需求')
    cfg.compose(HERE / 'formal_trainer.py', work,
                cfg.overrides(work, raytmp, student_name, interaction, resume_step()), check_only=True)


class Callbacks(c.Callbacks):
    trainer_entry = HERE / 'formal_trainer.py'
    tutor_count = TUTOR_COUNT

    def __init__(self, *args):
        super().__init__(*args)
        if cfg.RESTART:
            self.protection = GPUGuard(self.snapshot, self.work, self.bindings,
                                       proc_snapshot=gpu_process_monitor.read_proc,
                                       roots=self.live_roots)
            self.profile_run = None
        if cfg.V4:
            self.telemetry = Sampler(self.work / 'tutor-telemetry.jsonl',
                                     lambda: self.bindings.get('tutor', ()), self.live_roots)
            self.telemetry_started = False

    def live_roots(self):
        processes = gpu_process_monitor.read_proc()
        return tuple((p.pid, processes[p.pid]['start']) for p in self.process_by_role.values()
                     if p.poll() is None and p.pid in processes)

    def student_guard(self):
        if not cfg.RESTART:
            return super().student_guard()
        try:
            self.protection.check()
        except GPUProtection as exc:
            self.protected_gpu = exc.gpu
            raise

    @staticmethod
    def overrides(work, raytmp, student_name, interaction):
        return cfg.overrides(work, raytmp, student_name, interaction, resume_step())

    def launch_tutor(self, tutors):
        Store().prepare(resume_step(), self.work)
        proc = super().launch_tutor(tutors)
        if cfg.V4:
            self.telemetry.start()
            self.telemetry_started = True
        return proc

    def stop_started(self):
        try:
            if cfg.V4 and self.telemetry_started:
                self.telemetry.stop()
                self.telemetry_started = False
        finally:
            super().stop_started()

    def spawn(self, name, args, env):
        if cfg.RESTART and name == 'judge':
            args = list(args)
            args[args.index('--gpu-memory-utilization') + 1] = str(JUDGE_FRACTION)
        if name == 'trainer':
            paths = [cfg.c.REPO, HERE, HERE.parent / 'a_group_b_native_v1',
                     HERE.parent / 'a_group_c_v1', HERE.parent / 'deep_stage0']
            if cfg.SPEED:
                (self.work / 'queue-metrics').mkdir(mode=0o700, exist_ok=False)
                paths.append(SPEED_DIR)
                if cfg.RESTART:
                    paths.append(RESTART_DIR)
                if cfg.V4:
                    paths.append(V4_DIR)
                args = [str(cfg.TRAINER_PYTHON), *args[1:]]
            env = dict(env, PYTHONPATH=os.pathsep.join(map(str, paths)))
        return super().spawn(name, args, env)


def watch_training(cb, scanner):
    while True:
        codes = cb.exit_codes()
        scanner.poll()
        if codes['trainer'] not in (None, 0):
            raise MonitoringFailure('训练器子进程非零退出')
        if codes['student'] is not None or codes['judge'] is not None:
            raise MonitoringFailure('学生或裁判服务提前退出')
        if codes['trainer'] == 0:
            return
        cb.student_guard()
        if cfg.RESTART and not cfg.V4 and os.environ.get('EDU_RESTART_PROFILE_STEP2') == '1' and cb.profile_run is None:
            cb.profile_run = start_if_due(cb.work, cb.bindings.get('tutor', ()))
        time.sleep(10)


def finish(cb, scanner, update):
    update('服务收尾')
    cb.stop_started()
    scanner.finish()
    for role in ('trainer', 'student', 'judge'):
        receipt = c.c_status.base.read_obj(cb.work / f'exit-{role}.json')
        if (type(receipt.get('exit_code')) is not int or receipt['exit_code'] != 0 or
                receipt.get('requested') is not (role != 'trainer')):
            raise MonitoringFailure('子进程退出回执异常或非零退出')
    store = Store()
    store.record(cfg.TOTAL)
    if store.accepted() != [95, 100]:
        raise CheckpointFailure('终点完整检查点保留规则未满足')
    for step in cfg.MILESTONES:
        if not store.record(step).get('merge_shards') or not (store.artifact(step) / 'config.json').is_file():
            raise CheckpointFailure('里程碑权重导出未完成')
    update('完成', '100步与四个里程碑导出均已完成')


def reason(exc):
    if cfg.RESTART and isinstance(exc, GPUProtection):
        return str(exc)
    if cfg.RESTART and str(exc) in ('批准布局的空闲整卡未同时到位', '批准布局的整卡预留发生竞争'):
        return str(exc)
    if isinstance(exc, (MonitoringFailure, CheckpointFailure, IdentityFailure)):
        return str(exc)
    return pilot.safe_reason(exc)


def main():
    global selected_gpus
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', required=True)
    parser.add_argument('--run', required=True, action='store_true')
    parser.add_argument('--resume', type=int)
    args = parser.parse_args()
    if args.resume is not None and (args.resume not in range(cfg.SAVE, cfg.TOTAL, cfg.SAVE)):
        parser.error('只接受 5 到 95 的已验收正式检查点步号')
    os.umask(0o077)
    if cfg.V4:
        from layout import read_approval
        try:
            selected_gpus = read_approval(cfg.c.ROOT, args.name, cfg.PROFILE,
                                          args.resume or 0, cfg.OPTIMIZER_OFFLOAD)
        except ValueError:
            parser.error('四卡或六卡启动参数与批准回执不符')
    elif cfg.RESTART:
        from switch import read_object, SwitchRefused
        try:
            approved = read_object(cfg.c.ROOT / RECEIPT)
        except SwitchRefused:
            parser.error('缺少专用重启批准回执')
        if (args.resume is not None or args.name != CANDIDATE_RUN
                or approved.get('kind') != '终止态六卡重启'
                or approved.get('27b_deferred_confirmed') is not True
                or approved.get('optimizer_offload') is not cfg.OPTIMIZER_OFFLOAD
                or approved.get('kernel') != cfg.KERNEL_MODE
                or approved.get('profile_step2') is not (os.environ.get('EDU_RESTART_PROFILE_STEP2') == '1')):
            parser.error('六卡重启参数与批准回执不符')
    os.environ['FORMAL_START'] = str(args.resume or 0)
    try:
        pilot.run(args.name, sys.modules[__name__])
    except BaseException as exc:
        print('正式训练退出', reason(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
