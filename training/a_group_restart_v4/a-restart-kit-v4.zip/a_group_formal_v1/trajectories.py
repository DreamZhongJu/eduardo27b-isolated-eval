"""Inspect only complete, newly written author trajectory rows in this attempt."""
from collections import Counter
import hashlib
import json
from pathlib import Path


class IdentityFailure(RuntimeError):
    pass


def key(problem, ground_truth, transfer, answer):
    if not isinstance(problem, str) or not problem or not all(isinstance(v, str) for v in
                                                               (ground_truth, transfer, answer)):
        raise IdentityFailure('轨迹来源字段异常')
    return tuple(hashlib.sha256(text.encode()).digest() for text in (problem, ground_truth, transfer, answer))


def expected(batch, count, split):
    keys = Counter()
    entries = batch.non_tensor_batch
    info, refs = entries['extra_info'], entries['reward_model']
    if len(info) != len(refs):
        raise IdentityFailure('训练批次身份字段数量不一致')
    for row, reward in zip(info, refs):
        if row.get('split') != split:
            raise IdentityFailure('训练批次的冻结划分异常')
        keys[key(row['problem'], reward['ground_truth'], row.get('transfer_problem') or '',
                 row.get('transfer_answer') or '')] += count
    return keys


class Rows:
    def __init__(self, work):
        self.folder = Path(work) / 'eduardo_conversations'
        self.offset = {}
        self.seen = set()

    def completed_phase(self, wanted, strip=None, tokenizer=None, deferred_visibility=None):
        counts = Counter()
        actual = Counter()
        empty = Counter()
        for path in self.folder.glob('conversations_*.jsonl'):
            with path.open('rb') as stream:
                st = path.stat()
                file_id = (st.st_dev, st.st_ino)
                offset = self.offset.get(file_id, 0)
                if offset > st.st_size:
                    raise IdentityFailure('轨迹文件截断')
                stream.seek(offset)
                for line in stream:
                    if not line.endswith(b'\n'):
                        raise IdentityFailure('批次结束后轨迹仍未写全')
                    uid, identity, row = self.checked_row(line)
                    if uid in self.seen:
                        raise IdentityFailure('轨迹 UUID 重复')
                    self.seen.add(uid)
                    if row.get('note') == 'empty_transcript':
                        empty[identity[:2]] += 1
                    else:
                        actual[identity] += 1
                        counts['judgeable'] += 1
                    counts['rows'] += 1
                    if row.get('gated') not in (0, 1) or row.get('judge_pass') not in (0, 1):
                        raise IdentityFailure('门槛判定字段异常')
                    counts['passed'] += int(row['judge_pass'])
                    if deferred_visibility is not None:
                        deferred_visibility.append(row)
                    elif strip is not None:
                        self.visibility(row, counts, strip, tokenizer)
                self.offset[file_id] = stream.tell()
        if actual - wanted or Counter({k: v for k, v in empty.items() if v}) != self.sources(wanted - actual):
            raise IdentityFailure('轨迹与冻结批次的来源或迁移题不一致')
        return counts

    @staticmethod
    def sources(rows):
        counts = Counter()
        for identity, count in rows.items():
            counts[identity[:2]] += count
        return counts

    @staticmethod
    def checked_row(line):
        try:
            row = json.loads(line)
            uid, problem, transfer = row['uuid'], row['problem'], row['transfer_problem']
            if not isinstance(uid, str) or not uid:
                raise ValueError
            return uid, key(problem, row['ground_truth'], transfer, row['transfer_answer']), row
        except (KeyError, TypeError, ValueError, UnicodeError) as exc:
            raise IdentityFailure('轨迹 UUID 或身份记录无效') from exc

    @staticmethod
    def visibility(row, counts, strip, tokenizer):
        texts = [m.get('content') for m in row['messages'] if m.get('role') == 'assistant']
        if not all(isinstance(text, str) for text in texts):
            raise IdentityFailure('教师消息结构异常')
        counts['invisible'] += int(not any(strip(text).strip() for text in texts))
        if tokenizer is not None:
            for text in texts:
                length = len(tokenizer.encode(text, add_special_tokens=False))
                counts['retokenized'] += 1
                counts['at_cap'] += int(length >= 662)
