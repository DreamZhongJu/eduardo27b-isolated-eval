# A 组 RTX PRO 5000 移植偏离清单（T-017）

1. **硬件平台替换**：由原论文 GH200（及此前重试包 v4 的共享 A100 80GB）改为 `8 × NVIDIA RTX PRO 5000 72GB Blackwell`（每卡 `73,415 MiB`，`sm_120`，卡间仅 PCIe 互联，GPU 0–3 在 NUMA 0、GPU 4–7 在 NUMA 1）。
2. **`sm_120` 源码编译**：`flash-attn 2.8.3` 与 `causal-conv1d 1.6.2.post1` 在独立 conda CUDA 12.8（`nvcc 12.8.93`、`g++ 12.4.0`）环境下按 `TORCH_CUDA_ARCH_LIST="12.0"` / `FLASH_ATTN_CUDA_ARCHS="120"` 从源码编译安装；其余 Python 包与 A100 `env-candidate-vllm0191` 对齐（`wheel 0.48.0`、`triton 3.6.0` 为本环境配套版本）。
3. **运行时环境与选卡参数**：子进程需将独立环境 `lib/` 置顶到 `LD_LIBRARY_PATH`（确保 `libicui18n.so.79` 加载 conda 的 `CXXABI_1.3.15` `libstdc++.so.6`），且 `vllm 0.19.1` 需在 `CUDA_DEVICE_ORDER=PCI_BUS_ID` 下使用整数卡号（不能使用 `GPU-<uuid>`）。
4. **单卡对照样本与判据**：按 T-017 使用基座 `Qwen3.5-4B` 与作者公开训练集分两组随机种子构造 6 条长中短多轮对话代替 C 阶段检查点与站内轨迹；按阶段 1 审核采用无 autocast/关 TF32 的真 FP32 前向作为参考，核验快路径 BF16 相对 FP32 的 `p99`/`p99.9`（≤ 慢路径 2 倍）、最大值（≤ `max(1.0, 2×慢路径最大值)`）、有限值与均量相对差（a–d）。
5. **裁判 `Qwen3.6-27B` 改为 `TP=2`（与作者一致）**：实测 `73,415 MiB` 单卡在作者 `launch_judge_server.sh` 默认 `max_model_len=32768, max_num_seqs=256` 下无法完成初始化；`TP=2`（`0.90`）实测可提供 `33.72 GiB`/卡 KV 与 `29.35x` 并发，与作者本身采用 2 卡一组部署裁判的并行结构一致。
6. **检查点与磁盘策略**：为适配 `/data` 有限空间，检查点仅保存 `[model, extra]`（不含优化器，回齐作者默认 `load_contents=[model,extra]`）并在阶段 3 只保留最新 1 份，日志只留指标不落盘 rollout 明细（`EDUARDO_CONV_DIR=/dev/null`）；系统盘 `/` 仅余 `7.8G`，所有缓存与临时目录强制落到 `~/bzhang/a_group_pro5000/`。因同盘 `/data` 剩余一度降至 `41.63 GB`，经批准将公开权重 `Qwen3.6-27B` 与 `Meta-Llama-3.1-8B-Instruct` 移至内存盘 `/dev/shm/zhujie_a_group/`（`0700`）并在原 `models/` 路径建软链接（逐文件核对 SHA-256；训练检查点仍在 `/data`；按审核决定训练结束后暂留 `/dev/shm/zhujie_a_group/` 供 A 组评测使用，评测完成并经审核确认后再删除）。
7. **学生 2 个副本与裁判并发调整，只影响速度**：在 8 卡布局下于 GPU 4 与 GPU 6 各起一个 `Meta-Llama-3.1-8B-Instruct` 单卡副本，通过本机 `serving_proxy.py` 按最少在途请求分担学生对话与后测请求；学生模型、采样参数与提示词完全不变（配置客户端并发上限为 `student_concurrency=32` / worker）。裁判并发在阶段 2 试跑用 `judge_concurrency=16` / worker（共 32）；阶段 3 曾按审核先以 `judge_concurrency=64`（共 128）测试第 1 步，虽耗时降至 `1020.24s`，但因 `utils.py` 默认单请求超时 `300s` 下服务端 `p95` 升至 `144.46s` 触发 `attempt_errors=8`，未过第 1 步闸门而自动停机；随即按预案改回 **`judge_concurrency=16`**（共 32）从第 0 步重新完成正式 100 步（全 100 步客户端 `attempt_errors=0`）。
8. **补齐作者同版 `qwen-vl-utils==0.0.14`**：`Qwen3.5-4B` 自带 `AutoProcessor`，veRL `ToolAgentLoop` 在 rollout 时调用 `qwen_vl_utils.process_vision_info`；按作者 `eduardo/scripts/train_slurm.sh` 用 `--no-deps` 装入 `qwen-vl-utils==0.0.14`，其余 Stage 1 核心包版本保持不变。

## 路线 A 训练偏离清单（T-026，相对 A 组 T-017）

1. **训练数据替换**：由作者公开 `train.parquet`（4,712 题）替换为 T-023 Pro 5000 重测包 `routeA_stage2_measured.jsonl`（SHA-256 `9ff8449b781906290f9b671bc5be1982ca31e5401ebfba485474d475a60752ce`）的 `split=train` 切片。
2. **去掉天花板组**：从 `split=train` 中剔除“所有变体的 `n_correct_hybrid` 均 ≥ 15”的原题组（无提分空间与正区分度信号），保留地板层与窄跨度层；每行将梯子信息（各变体题面、参考答案、`b`、`ladder_rank`、`p_new`、`n_correct_hybrid`）写入 `extra_info.variants`，不修改作者或 veRL 数据加载器。
3. **验证集替换**：由作者 `val.parquet` 替换为 T-023 重测包的 `split=dev`（100 道原题，保留全部变体结构，未做天花板剔除）。
4. **奖励函数替换为 `ladder_rasch`**：训练入口 `pro5000_trainer_entry.py` 放开绑定 `pkg://training.routeA_reward.reward_function:route_a_reward_func`（`reward.mode=ladder_rasch`），每段合规对话在 `k=8` 次独立爬梯子后测下用混合判法（`math-verify==0.8.0` 规则 + 本机 `Qwen3.6-27B` 兜底，`hybrid_grader.py` SHA-256 `7d2a5f46619218e92ed11efc4e7e07f190027ac0f1cca9336905c090ff62709a`）与牛顿法 Rasch MAP 估计能力增益 `θ̂`，继续沿用作者公式 (5) 的教师长度衰减与 `-0.2` 硬门控惩罚；其余 DPPO、超参、教师每轮 `150+512=662` token 预算等配方项完全保持与 T-017 一致。
5. **增益尺度对齐（`G = θ̂ / 4`）**：按 T-024 阶段 2 发现，直接用未缩放 `θ̂` 会导致约 44% 合规对话得分低于 `-0.2` 门控惩罚而产生“故意违规拿 `-0.2`”的作弊风险；新增配置项 `theta_scale = 0.25`（默认 `0.25`），将进入公式 (5) 的能力增益缩为 `G = θ̂ * 0.25`，与 `-0.2` 门控惩罚量级对齐。
6. **混合判法与门禁共用 27B vLLM 服务**：在 8 卡布局中 GPU 5、7 的 `Qwen3.6-27B`（`TP=2`、`max_num_seqs=256`）同时承接门禁裁判（`judge_concurrency=16`/worker，2 workers 共 `32`，与 T-017 正式运行一致）与混合判法兜底（独立信号量 `grader_max_concurrency=32`/worker，2 workers 共 `64`，加 AIMD 拥塞窗口 `1..32`），两项合计并发上限 `96 ≤ 256`（避免 T-017 第 1 步门禁 `64`/worker 时的 `300s` 超时问题）。

## 路线 C 训练偏离清单（T-034，相对路线 A T-026）

1. **按原题难度路由（`τ = 0.4, m = 1.0`）**：基于 T-031 实测原题前测 `p_原`（`b_原 = ln((1 − p_原)/p_原)`）与 T-023 实测变体 `b_变体`（`Δb = b_变体 − b_原`），将 T-026 同题池同顺序样本分为三支：
   - **简单支（`p_原 ≥ 0.4` 且存在 `Δb ≥ 1.0`）**：Tutor 仍教原题，后测梯子仅保留 `Δb > −1.0` 的变体（去掉明显更简单的变体）。
   - **难题支（`p_原 < 0.4` 且存在 `Δb ≤ −1.0`）**：Tutor 改教 `Δb ≤ −1.0` 中 `b` 最大的变体（最接近原题，平局取编号小），门禁裁判按该教题及答案判分；原题仅进入后测梯子（与其余未教变体按实测 `b` 从易到难排列），只考不教。
   - **兜底支（`fallback`）**：其余原题保持与 T-026 逐字段一致（教原题、全变体后测）。
2. **新增分支与门禁类型纯数字日志**：在不改动奖励公式与 `hybrid_grader.py` 的前提下，在 `reward_function.py` 与 `pro5000_trainer_entry.py` 中新增按支（`easy`/`hard`/`fallback`）与按门禁类型（`teaching_only`/`leak_only`/`both`/`pass`）的纯数字统计与落盘，以及合规对话 `G` 中位数。
