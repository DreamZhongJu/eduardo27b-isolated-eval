#!/usr/bin/env python3
import argparse,hashlib,json,re
from pathlib import Path
import numpy as np
import pyarrow.parquet as pq
from datasets import Dataset

def norm(s):return re.sub(r'\s+',' ',s.strip())
def digest(s):return hashlib.sha256(s.encode('utf8')).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):
 with p.open(encoding='utf8') as f:return [json.loads(l) for l in f]
ap=argparse.ArgumentParser();ap.add_argument('--train',type=Path,required=True);ap.add_argument('--test',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
m=json.loads((a.out/'manifest.json').read_text());train=read(a.out/'training_pool.jsonl');val=read(a.out/'validation.jsonl');rows=pq.read_table(a.train).to_pylist();test=pq.read_table(a.test,columns=['problem']).to_pylist()
assert filehash(a.train)==m['source_train_sha256'] and filehash(a.test)==m['source_test_sha256']
assert all(filehash(a.out/f)==m['output_sha256'][f] for f in ('training_pool.jsonl','validation.jsonl'))
assert len(train)==m['training_rows']==4712 and len(val)==m['validation_unique_sources']==100
blocked={norm(r['problem']) for r in test};v_ids={x['official_train_row_index'] for x in val};t_ids={x['official_train_row_index'] for x in train}
assert len(v_ids)==100 and len(t_ids)==4712 and not (v_ids&t_ids)
vq={norm(rows[i]['problem']) for i in v_ids};tq={norm(rows[i]['problem']) for i in t_ids}
assert len(vq)==100 and len(tq)==4615 and not (vq&tq) and not ((vq|tq)&blocked)
for x in train+val:
 r=rows[x['official_train_row_index']]
 assert digest(r['problem'])==x['source_question_sha256'] and digest(r['transfer_problem'])==x['transfer_question_sha256']
 assert digest(str(r['answer']).strip())==x['source_answer_sha256'] and digest(str(r['transfer_answer']).strip())==x['transfer_answer_sha256']
 assert x['pre_solve_rate']==r['pre_solve_rate'] and x['pre_solve_rate_transfer_problem']==r['pre_solve_rate_transfer_problem']
 assert bool(r['transfer_problem']) and .02<=r['pre_solve_rate']<=.65 and .02<=r['pre_solve_rate_transfer_problem']<=.65
filtered=[i for i,r in enumerate(rows) if r.get('transfer_problem') and all(type(r.get(k)) in (float,int) and .02<=r[k]<=.65 for k in ('pre_solve_rate','pre_solve_rate_transfer_problem'))]
clean=[i for i in filtered if norm(rows[i]['problem']) not in blocked]
assert len(filtered)==4830 and len(clean)==4816
shuffled=list(Dataset.from_dict({'row':clean}).shuffle(seed=42)['row'])
expected_val=[];groups=set()
for i in shuffled:
 q=norm(rows[i]['problem'])
 if q not in groups:
  expected_val.append(i);groups.add(q)
  if len(expected_val)==100:break
expected_train=[i for i in shuffled if norm(rows[i]['problem']) not in groups]
assert [x['official_train_row_index'] for x in val]==expected_val
assert [x['official_train_row_index'] for x in train]==expected_train
print('独立核验通过：作者筛选4830，排除测试14，验证100原题，训练4712行/4615原题；dataset shuffle与身份映射一致。')
