#!/usr/bin/env python3
"""Freeze an author-only train/validation split; output hashes, never text."""
import argparse,hashlib,json,math,os,re,sys
from pathlib import Path
import numpy as np
import pyarrow.parquet as pq

REV='5d7529f06359f31b692c92634f5cc11c8b7953af'
TRAIN_SHA='5171c9891b502f9792b14ac2b15684ce85b8ceb2593689ed3e88b9f349b25d61'
TEST_SHA='109b45cf350cb70414a294ff999d4f545b06e9df91e02ec1a0a3b30783c46ec0'

def digest_file(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def digest(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def normalize(s):return re.sub(r'\s+',' ',s.strip())
def valid(row):
 rates=(row.get('pre_solve_rate'),row.get('pre_solve_rate_transfer_problem'))
 return bool(row.get('transfer_problem')) and all(type(v) in (float,int) and math.isfinite(v) and .02<=v<=.65 for v in rates)
def identity(i,row,order):
 q=row['problem'];tp=row['transfer_problem']
 return {'order':order,'official_train_row_index':i,'source_question_sha256':digest(q),
   'source_normalized_question_sha256':digest(normalize(q)),
   'source_answer_sha256':digest(str(row.get('answer','')).strip()),
   'transfer_question_sha256':digest(tp),
   'transfer_answer_sha256':digest(str(row.get('transfer_answer','')).strip()),
   'pre_solve_rate':row.get('pre_solve_rate'),
   'pre_solve_rate_n_scored':row.get('pre_solve_rate_n_scored'),
   'pre_solve_rate_transfer_problem':row.get('pre_solve_rate_transfer_problem'),
   'pre_solve_rate_transfer_n_scored':row.get('pre_solve_rate_transfer_n_scored')}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--train',type=Path,required=True);ap.add_argument('--test',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args();tr=a.train.resolve(strict=True);te=a.test.resolve(strict=True)
 if digest_file(tr)!=TRAIN_SHA or digest_file(te)!=TEST_SHA:raise ValueError('official parquet SHA-256 mismatch')
 rows=pq.read_table(tr).to_pylist();test=pq.read_table(te,columns=['problem']).to_pylist()
 if len(rows)!=10000 or len(test)!=500:raise ValueError('official row count mismatch')
 if not all(isinstance(x.get('problem'),str) and x['problem'].strip() for x in rows+test):raise ValueError('missing source problem')
 test_q={normalize(r['problem']) for r in test}
 filtered=[i for i,r in enumerate(rows) if valid(r)]
 clean=[i for i in filtered if normalize(rows[i]['problem']) not in test_q]
 if len(filtered)!=4830:raise ValueError('unexpected official filter result')
 if sum(not rows[i].get('transfer_answer') for i in clean):raise ValueError('missing transfer answer')
 # Datasets .shuffle(seed=42) uses default_rng(seed).permutation on the row list.
 order=np.random.default_rng(42).permutation(len(clean))
 shuffled=[clean[int(i)] for i in order]
 val=[];val_groups=set()
 for i in shuffled:
  q=normalize(rows[i]['problem'])
  if q not in val_groups:
   val.append(i);val_groups.add(q)
   if len(val)==100:break
 if len(val)!=100:raise ValueError('insufficient distinct validation sources')
 # Exclude every matching duplicate author row from training, even if not selected for val.
 pool=[i for i in shuffled if normalize(rows[i]['problem']) not in val_groups]
 if not pool or {normalize(rows[i]['problem']) for i in pool}&val_groups:raise ValueError('train validation overlap')
 if any(normalize(rows[i]['problem']) in test_q for i in pool+val):raise ValueError('train test overlap')
 if not a.out.is_absolute():raise ValueError('output path must be absolute')
 os.umask(0o077);a.out.mkdir(mode=0o700,parents=False,exist_ok=False)
 for filename,selected in [('training_pool.jsonl',pool),('validation.jsonl',val)]:
  with (a.out/filename).open('x',encoding='utf-8') as f:
   for order,i in enumerate(selected):f.write(json.dumps(identity(i,rows[i],order),ensure_ascii=False,separators=(',',':'))+'\n')
 manifest={'source_dataset':'dmacjam/eduardoRL-transfer-dataset','source_revision':REV,'source_train_sha256':TRAIN_SHA,'source_test_sha256':TEST_SHA,
  'author_filter':'transfer_problem is nonempty and both pre rates in [0.02,0.65]',
  'filter_rows':len(filtered),'excluded_test_rows':len(filtered)-len(clean),'after_test_rows':len(clean),
  'validation_unique_sources':len(val),'excluded_other_rows_of_validation_sources':len(clean)-len(pool)-len(val),
  'training_rows':len(pool),'training_unique_sources':len({normalize(rows[i]['problem']) for i in pool}),
  'seed':42,'shuffle':'numpy.random.default_rng(42).permutation on original-order filtered rows; validation selects first 100 distinct normalized sources',
  'numpy_version':np.__version__,'train_validation_and_test_identity':'whitespace-normalized original problem',
  'all_test_excluded':False,'intentional_changes':'test exclusion, grouping duplicate source questions across train/validation; no preselection of 1600',
  'train_order':'shuffled source pool order only; actual training sampler order must be logged',
  'output_sha256':{name:digest_file(a.out/name) for name in ('training_pool.jsonl','validation.jsonl')}}
 with (a.out/'manifest.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps(manifest,ensure_ascii=False,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print('未完成：'+type(e).__name__+'；'+str(e),file=sys.stderr);sys.exit(1)
