#!/usr/bin/env python3
"""Materialize frozen author indices using the author's unmodified _row function."""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq

def digest_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def digest(s):return hashlib.sha256(s.encode('utf8')).hexdigest()
def read_jsonl(p):
 with p.open(encoding='utf8') as f:return [json.loads(l) for l in f]
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--repo-commit',required=True);p.add_argument('--author-train',type=Path,required=True);p.add_argument('--selection',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 repo=a.repo.resolve(strict=True);author=a.author_train.resolve(strict=True);selection=a.selection.resolve(strict=True)
 git=lambda *v:subprocess.run(['git','-C',str(repo),*v],capture_output=True,text=True,timeout=20,check=True).stdout.strip()
 commit=git('rev-parse','HEAD')
 if commit!=a.repo_commit or len(commit)!=40 or git('status','--porcelain','--untracked-files=no'):raise ValueError('author repository commit/cleanliness mismatch')
 manifest=json.loads((selection/'manifest.json').read_text())
 if digest_file(author)!=manifest['source_train_sha256']:raise ValueError('author train parquet hash mismatch')
 pairs=[('train','training_pool.jsonl','train.parquet',manifest['training_rows']),('val','validation.jsonl','val.parquet',manifest['validation_unique_sources'])]
 for _,name,_,_ in pairs:
  if digest_file(selection/name)!=manifest['output_sha256'][name]:raise ValueError('selection hash mismatch')
 records=pq.read_table(author).to_pylist()
 if len(records)!=10000:raise ValueError('author train row count mismatch')
 sys.dont_write_bytecode=True;sys.path.insert(0,str(repo))
 from eduardo.process_dataset import _row
 if Path(sys.modules[_row.__module__].__file__).resolve()!=(repo/'eduardo/process_dataset.py').resolve():raise ValueError('imported module path mismatch')
 if not a.out.is_absolute():raise ValueError('output must be absolute')
 os.umask(0o077);a.out.mkdir(mode=0o700,parents=False,exist_ok=False)
 output={}
 for split,name,filename,expected in pairs:
  selected=read_jsonl(selection/name)
  if len(selected)!=expected:raise ValueError('selection count mismatch')
  formatted=[]
  for seq,rec in enumerate(selected):
   i=rec['official_train_row_index']
   if rec['order']!=seq or type(i) is not int or not 0<=i<len(records):raise ValueError('invalid index/order')
   r=records[i]
   if digest(r['problem'])!=rec['source_question_sha256'] or digest(str(r['answer']).strip())!=rec['source_answer_sha256'] or digest(r['transfer_problem'])!=rec['transfer_question_sha256'] or digest(str(r['transfer_answer']).strip())!=rec['transfer_answer_sha256'] or r['pre_solve_rate']!=rec['pre_solve_rate'] or r['pre_solve_rate_transfer_problem']!=rec['pre_solve_rate_transfer_problem']:
    raise ValueError('author row does not match selection')
   formatted.append(_row(r['problem'],r['answer'],r['pre_solve_rate'],r['transfer_problem'],r['transfer_answer'],r['pre_solve_rate_transfer_problem'],split))
  pd.DataFrame(formatted).to_parquet(a.out/filename,index=False)
  if pq.ParquetFile(a.out/filename).metadata.num_rows!=expected:raise ValueError('output row count mismatch')
  output[filename]={'rows':expected,'sha256':digest_file(a.out/filename)}
 info={'author_repository_commit':commit,'source_revision':manifest['source_revision'],'source_train_sha256':manifest['source_train_sha256'],'selection_sha256':manifest['output_sha256'],'output':output,'actual_training_order':'not started; log separately'}
 with (a.out/'materialization_manifest.json').open('x',encoding='utf8') as f:json.dump(info,f,ensure_ascii=False,indent=2);f.write('\n')
 print('作者原 _row 数据准备完成：训练',output['train.parquet']['rows'],'验证',output['val.parquet']['rows'],'；已保存哈希与代码版本。')
if __name__=='__main__':
 try:main()
 except Exception as e:print('未完成：'+type(e).__name__+'；'+str(e),file=sys.stderr);sys.exit(1)
