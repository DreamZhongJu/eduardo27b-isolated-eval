# A 组作者官方训练题池

本包只含官方训练行号、题目和答案哈希、作者预存前测、数据版本及脚本；不含题目或答案正文。依据官方原始 train/test 固定修订，采用作者公开默认筛选条件：迁移题存在，原题与迁移题前测正确率均在 [0.02, 0.65]。为避免测试题泄漏，按空白规范化题面排除作者 test；种子 42 随机选100个不同原题作验证，与验证原题相同的其他行也不用于训练。剩余合格作者训练行全部保留，不预选1,600题。

固定数据 SHA-256：
- 官方 train parquet：`5171c9891b502f9792b14ac2b15684ce85b8ceb2593689ed3e88b9f349b25d61`
- 官方 test parquet：`109b45cf350cb70414a294ff999d4f545b06e9df91e02ec1a0a3b30783c46ec0`

## 从题单还原作者训练格式

安装所需 Python 环境并准备好固定版本的原作者仓库与官方原始 train parquet 后，在包所在目录执行；下方路径为示例，换成实际路径。目标目录必须不存在，父目录必须已经存在。只在目标目录写入新文件，不修改原仓库或原始 parquet。

```bash
python -B scripts/materialize_paper_parquet.py \
  --repo /path/to/author/EduardoRL \
  --repo-commit e8c89b7293e65e632149571b16a1c2d4e33c77fe \
  --author-train /path/to/official/train-00000-of-00001.parquet \
  --selection "$PWD/selection" \
  --out /path/to/new-workdir/data/eduardo
```

脚本会验证 repo commit 和干净状态、数据和题单 SHA-256、每行作者题目/答案/迁移题/答案的哈希以及两个 pre rate，调用作者未修改的 `eduardo.process_dataset._row` 来生成 `train.parquet` 和 `val.parquet`（含题目，请留在受控服务器）与 `materialization_manifest.json`。这些数据文件仅定义题池和顺序，不会启动训练。作者预处理 shuffle 使用随机种子 42；训练时实际采样次序取决于训练器，需独立记录。

可用 `scripts/prepare_paper_pool.py` 对官方固定 train/test 重新生成清单，运行 `--help` 查看参数；`scripts/verify_paper_pool.py` 提供独立核验。作者 repo 和原始 parquet 未包含在本包。
